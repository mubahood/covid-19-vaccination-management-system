<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FormSr6 extends Model
{
    use HasFactory;

    function __construct() {
 
    }

    protected $casts = [
        //'premises_location ' =>'json',
    ];



}

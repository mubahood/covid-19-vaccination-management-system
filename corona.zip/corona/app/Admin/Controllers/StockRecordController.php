<?php

namespace App\Admin\Controllers;

use App\Models\District;
use App\Models\Lab;
use App\Models\StockRecord;
use Encore\Admin\Auth\Database\Administrator;
use Encore\Admin\Controllers\AdminController;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;
use Illuminate\Support\Facades\Auth;

class StockRecordController extends AdminController
{
    /**
     * Title for current resource.
     *
     * @var string
     */
    protected $title = 'StockRecord';

    /**
     * Make a grid builder.
     *
     * @return Grid
     */
    protected function grid()
    {
        $grid = new Grid(new StockRecord());

        $grid->column('id', __('Id'));
        $grid->column('administrator_id', __('Added by'))->display(function ($userId) {
            $u = Administrator::find($userId);
            if (!$u)
                return "No one";
            return $u->name;
        })->sortable();
        $grid->column('lab_id', __('Lab'))->display(function ($userId) {
            $u = Lab::find($userId);
            if (!$u)
                return "No one";
            return $u->name;
        })->sortable();
        $grid->column('name', __('Vaccine Name'));
        $grid->column('type', __('Type'));
        $grid->column('amount', __('Amount'));

        return $grid;
    }

    /**
     * Make a show builder.
     *
     * @param mixed $id
     * @return Show
     */
    protected function detail($id)
    {
        $show = new Show(StockRecord::findOrFail($id));

        $show->field('id', __('Id'));
        $show->field('created_at', __('Created at'));
        $show->field('updated_at', __('Updated at'));
        $show->field('administrator_id', __('Administrator id'));
        $show->field('lab_id', __('Lab id'));
        $show->field('name', __('Name'));
        $show->field('type', __('Type'));
        $show->field('amount', __('Amount'));

        return $show;
    }

    /**
     * Make a form builder.
     *
     * @return Form
     */
    protected function form()
    {
        $form = new Form(new StockRecord());

        $form->hidden('administrator_id', __('Administrator id'))->value(Auth::user()->id);

        $items = Lab::all();
        $_items = [];
        foreach ($items as $key => $item) {
            $_items[$item->id] = $item->name . " - ID: " . $item->id;
        }
        $form->select('lab_id', __('Lab'))
            ->options($_items)
            ->required();
        $form->text('name', __('Vaccine Name'))->required();
        $form->select('type', __('Dose Type'))
            ->options([
                'First dose' => 'First dose',
                'Second dose' => 'Second dose'
            ])
            ->required();
        $form->number('amount', __('Amount'))->required();

        return $form;
    }
}

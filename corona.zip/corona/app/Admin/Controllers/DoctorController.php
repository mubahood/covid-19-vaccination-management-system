<?php

namespace App\Admin\Controllers;

use App\Models\Doctor;
use App\Models\Lab;
use Encore\Admin\Auth\Database\Administrator;
use Encore\Admin\Controllers\AdminController;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;

class DoctorController extends AdminController
{
    /**
     * Title for current resource.
     *
     * @var string
     */
    protected $title = 'Doctor';

    /**
     * Make a grid builder.
     *
     * @return Grid
     */
    protected function grid()
    {
        $grid = new Grid(new Doctor());

        $grid->column('id', __('Id')); 
        $grid->column('administrator_id', __('Administrator id'))->display(function ($userId) {
            $u = Administrator::find($userId);
            if (!$u)
                return "No one";
            return $u->name;
        })->sortable();
        $grid->column('lab_id', __('Lab'))->display(function ($userId) {
            $u = Lab::find($userId);
            if (!$u)
                return "No one";
            return $u->name;
        })->sortable();
        $grid->column('gender', __('Gender'));
        $grid->column('phone_number', __('Phone number'));

        return $grid;
    }

    /**
     * Make a show builder.
     *
     * @param mixed $id
     * @return Show
     */
    protected function detail($id)
    {
        $show = new Show(Doctor::findOrFail($id));

        $show->field('id', __('Id')); 
        $show->field('administrator_id', __('Administrator id'))->display(function ($userId) {
            $u = Administrator::find($userId);
            if (!$u)
                return "No one";
            return $u->name;
        })->sortable();
        $show->field('lab_id', __('Lab id'));
        $show->field('full_name', __('Full name'));
        $show->field('age', __('Age'));
        $show->field('gender', __('Gender'));
        $show->field('address', __('Address'));
        $show->field('phone_number', __('Phone number'));
        $show->field('photo', __('Photo'));
        $show->field('nin_number', __('Nin number'));

        return $show;
    }

    /**
     * Make a form builder.
     *
     * @return Form
     */
    protected function form()
    {
        $form = new Form(new Doctor());

        $items = Administrator::all();
        $_items = [];
        foreach ($items as $key => $item) { 
            $_items[$item->id] = $item->name . " - ID: " . $item->id;
        }
        $form->select('administrator_id', __('Doctor\'s account'))
            ->options($_items)
            ->rules('required');
         
        
        $items = Lab::all();
        $_items = [];
        foreach ($items as $key => $item) { 
            $_items[$item->id] = $item->name . " - ID: " . $item->id;
        }
        $form->select('lab_id', __('Add to lab'))
            ->options($_items)
            ->rules('required');
         
        $form->text('age', __('Age'))->attribute(['type' => 'number'])->rules('required');
        $form->select('gender', __('Gender'))
        ->options([
            'Male' => 'Male',
            'Female' => 'Female'
        ])->rules('required');
        $form->text('phone_number', __('Phone number'))->rules('required');
        $form->text('address', __('Address'));

        $form->file('photo', __('Photo'));
        $form->text('nin_number', __('Nin number'));

        return $form;
    }
}

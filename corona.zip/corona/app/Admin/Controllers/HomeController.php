<?php

namespace App\Admin\Controllers;

use App\Http\Controllers\Controller;
use App\Models\District;
use App\Models\Lab;
use App\Models\VaccinationRecord;
use Encore\Admin\Auth\Database\Administrator;
use Encore\Admin\Controllers\Dashboard;
use Encore\Admin\Layout\Column;
use Encore\Admin\Layout\Content;
use Encore\Admin\Layout\Row;
use Encore\Admin\Widgets\InfoBox;

class HomeController extends Controller
{
    public function index(Content $content)
    {

        return $content
            //->title('Dashboard')
            //->description('Description...')
            //->row(Dashboard::title())
            ->row(function (Row $row) {

                $row->column(4, function (Column $column) {
                    $infoBox = new InfoBox('All doctors', 'user-md', 'blue', url('admin/auth/users'), count(Administrator::all()));
                    $column->append($infoBox);
                });

                $row->column(4, function (Column $column) {
                    $infoBox = new InfoBox('All districts', 'building', 'blue', url('admin/districts'), count(District::all()));
                    $column->append($infoBox);
                });

                $row->column(4, function (Column $column) {
                    $infoBox = new InfoBox('All labs', 'gitlab', 'blue', url('admin/labs'), count(Lab::all()));
                    $column->append($infoBox);
                });

                $row->column(4, function (Column $column) {
                    $dis = District::all();
                    $pop = 0;
                    foreach ($dis as $key => $p) {
                        $pop += ((int)($p->population));
                    }
                    $infoBox = new InfoBox('Total population', 'users', 'red', url('admin/districts'), number_format($pop));
                    $column->append($infoBox);
                });
 

                $row->column(4, function (Column $column) {
                    $dis = VaccinationRecord::all();
                    $pop = 0;
                    foreach ($dis as $key => $p) {
                        if($p->type == "First dose"){
                            $pop++;
                        }
                    }
                    $infoBox = new InfoBox('Vaccinated - 1st Dose', 'ambulance', 'yellow', url('admin/vaccination-records'), number_format($pop));
                    $column->append($infoBox);
                });

                $row->column(4, function (Column $column) {
                    $dis = VaccinationRecord::all();
                    $pop = 0;
                    foreach ($dis as $key => $p) {
                        if($p->type == "Second dose"){
                            $pop++;
                        }
                    }
                    $infoBox = new InfoBox('Vaccinated - 2nd Dose', 'check', 'green', url('admin/vaccination-records-2'), number_format($pop));
                    $column->append($infoBox);
                });
 

           

                $row->column(4, function (Column $column) {
                    //$column->append(Dashboard::extensions());
                });

                $row->column(4, function (Column $column) {
                    //$column->append(Dashboard::dependencies());
                });
            });
    }
}

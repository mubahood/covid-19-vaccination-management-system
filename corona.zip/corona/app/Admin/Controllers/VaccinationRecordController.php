<?php

namespace App\Admin\Controllers;

use App\Models\Doctor;
use App\Models\Lab;
use App\Models\VaccinationRecord;
use Carbon\Carbon;
use Encore\Admin\Auth\Database\Administrator;
use Encore\Admin\Controllers\AdminController;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;
use Illuminate\Support\Facades\Auth;

class VaccinationRecordController extends AdminController
{
    
    /**
     * Title for current resource.
     *
     * @var string
     */
    protected $title = 'Vaccination Records - 1st dose';

    /**
     * Make a grid builder.
     *
     * @return Grid
     */
    protected function grid()
    {
        $grid = new Grid(new VaccinationRecord());
        $grid->model()->where('type', '=', 'First dose');       
        $grid->header(function ($query) {
            return 'Vaccination Records - 1st Dose';
        });
        
        $grid->actions(function ($actions) {
            $actions->disableDelete();
            $actions->disableEdit();
        });
        $grid->column('id', __('Id'));
        $grid->column('created_at', __('Created at'))->display(function ($item) {
            return Carbon::parse($item)->diffForHumans();
        })->sortable();
        $grid->column('administrator_id', __('Vaccinated by'))->display(function ($userId) {
            $u = Administrator::find($userId);
            if (!$u)
                return "Not assigned";
            return $u->name;
        })->sortable();
        $grid->column('lab_id', __('Lab'))->display(function ($userId) {
            $u = Lab::find($userId);
            if (!$u)
                return "Not assigned";
            return $u->name;
        })->sortable();
        $grid->column('full_name', __('Candidate name'));
        $grid->column('type', __('Type'));
        $grid->column('next_vaccination', __('Next vaccination'))->display(function ($item) {
            return Carbon::parse($item)->diffForHumans();
        })->sortable();
        return $grid;
    }

    /**
     * Make a show builder.
     *
     * @param mixed $id
     * @return Show
     */
    protected function detail($id)
    {
        $show = new Show(VaccinationRecord::findOrFail($id));

        $show->field('id', __('Id'));
        $show->field('created_at', __('Created at'));
        $show->field('updated_at', __('Updated at'));
        $show->field('administrator_id', __('Administrator id'));
        $show->field('lab_id', __('Lab id'));
        $show->field('full_name', __('Full name'));
        $show->field('age', __('Age'));
        $show->field('gender', __('Gender'));
        $show->field('address', __('Address'));
        $show->field('phone_number', __('Phone number'));
        $show->field('photo', __('Photo'));
        $show->field('nin_number', __('Nin number'));
        $show->field('type', __('Type'));
        $show->field('next_vaccination', __('Next vaccination'));

        return $show;
    }

    /**
     * Make a form builder.
     *
     * @return Form
     */
    protected function form()
    {
        $form = new Form(new VaccinationRecord());

        $user = Auth::user();
        $doctor = Doctor::firstWhere('administrator_id', $user->id);
        if (!$doctor) {
            admin_error(
                "Unauthorized access!",
                "This is account not a doctor account. Only doctors can add vaccince records."
            );
            return redirect()->back();
        }

        $items = Administrator::all();
        $_items = [];
        foreach ($items as $key => $item) {
            $_items[$item->id] = $item->name . " - ID: " . $item->id;
        }

        $form->html('<h3>Lab information</h3>');
        $form->select('administrator_id', __('Doctor'))
            ->options($_items)
            ->rules('required')
            ->value($user->id)
            ->readonly();
        $items = Lab::all();
        $_items = [];
        foreach ($items as $key => $item) {
            $_items[$item->id] = $item->name . " - ID: " . $item->id;
        }
        $form->select('lab_id', __('Laboratory'))
            ->options($_items)
            ->rules('required')
            ->value($doctor->lab_id)
            ->readonly();

        $form->divider();
        $form->html('<h3>Vaccination candidate information</h3>');
        $form->text('full_name', __('Candidate Full name'))->required();
        $form->number('age', __('Age'))->required();
        $form->select('gender', __('Gender'))
            ->options([
                'Male' => 'Male',
                'Female' => 'Female'
            ])->rules('required');
        $form->text('address', __('Address'))->required();
        $form->text('phone_number', __('Phone number'))->required();
        $form->image('photo', __('Photo'))->required();
        $form->text('nin_number', __('Nin number'))->required();
        $form->select('type', __('Dosage'))
            ->options([
                'First dose' => 'First dose',
                'Second dose' => 'Second dose'
            ])
            ->required()
            ->value('First dose')
            ->readonly();
        $form->datetime('next_vaccination', __('Next vaccination'))
            ->default(date('Y-m-d H:i:s'))
            ->help("Please select next dosage date.")
            ->required();



        return $form;
    }
}

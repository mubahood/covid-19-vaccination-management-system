<?php

namespace App\Admin\Controllers;

use App\Models\District;
use App\Models\Lab;
use Encore\Admin\Auth\Database\Administrator;
use Encore\Admin\Controllers\AdminController;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;

class LabController extends AdminController
{
    /**
     * Title for current resource.
     *
     * @var string
     */
    protected $title = 'Lab';

    /**
     * Make a grid builder.
     *
     * @return Grid
     */
    protected function grid()
    {
        $grid = new Grid(new Lab());

        $grid->column('id', __('Id'));
        $grid->column('name', __('Name'));
        $grid->column('administrator_id', __('Inspector'))->display(function ($userId) {
            $u = Administrator::find($userId);
            if (!$u)
                return "Not assigned";
            return $u->name;
        })->sortable();
        $grid->column('district_id', __('District id'))->display(function ($id) {
            $u = District::find($id);
            if (!$u)
                return "No district";
            return $u->name;
        })->sortable();
        
        $grid->column('address', __('Address'));
        $grid->column('latitude', __('Stock'));
        $grid->column('latitude', __('Vaccinated'));

        return $grid;
    }

    /**
     * Make a show builder.
     *
     * @param mixed $id
     * @return Show
     */
    protected function detail($id)
    {
        $show = new Show(Lab::findOrFail($id));

        $show->field('id', __('Id'));
        $show->field('created_at', __('Created at'));
        $show->field('updated_at', __('Updated at'));
        $show->field('administrator_id', __('Administrator id'));
        $show->field('district_id', __('District id'));
        $show->field('name', __('Name'));
        $show->field('longitude', __('Longitude'));
        $show->field('latitude', __('Latitude'));
        $show->field('address', __('Address'));
        $show->field('image', __('Image'));
        $show->field('details', __('Details'));

        return $show;
    }

    /**
     * Make a form builder.
     *
     * @return Form
     */
    protected function form()
    {
        $form = new Form(new Lab());

        $form->text('name', __('Lab Name'))->required();

        $items = District::all();
        $_items = [];
        foreach ($items as $key => $item) {
            $_items[$item->id] = $item->name . " - ID: " . $item->id;
        }
        $form->select('district_id', __('District'))
            ->options($_items)
            ->help('Please select district')
            ->required();

        $items = Administrator::all();
        $_items = [];
        foreach ($items as $key => $item) {
            $_items[$item->id] = $item->name . " - ID: " . $item->id;
        }
        $form->select('administrator_id', __('Lab Inspector'))
            ->options($_items)
            ->help('Please select inspector')
            ->required();

        $form->text('address', __('Lab full address'))->required();
        $form->image('image', __('Lab Image'))->required();
        $form->textarea('details', __('Lab Details'))->required();

        $form->latlong('latitude', 'longitude', 'Lab position on map')->default(['lat' => 0.3130291, 'lng' => 32.5290854])->required();

        return $form;
    }
}

<?php

use Encore\Admin\Facades\Admin;
use Illuminate\Routing\Router;


Admin::routes();

Route::group([
    'prefix'        => config('admin.route.prefix'),
    'namespace'     => config('admin.route.namespace'),
    'middleware'    => config('admin.route.middleware'),
    'as'            => config('admin.route.prefix') . '.',
], function (Router $router) {

    $router->get('/', 'HomeController@index')->name('home');
    $router->resource('countries', CountryController::class);
    $router->resource('cities', CityController::class);
    $router->resource('users', UserController::class);
    $router->resource('products', ProductController::class);
    $router->resource('categories', CategoryController::class);
    $router->resource('attributes', AttributeController::class);
    $router->resource('profiles', ProfileController::class);
    $router->resource('form-sr4s', FormSr4Controller::class);
    $router->resource('form-sr6s', FormSr6Controller::class);
    
    
    // new routes
    $router->resource('districts', DistrictController::class);
    $router->resource('labs', LabController::class);
    $router->resource('stock-records', StockRecordController::class);
    $router->resource('vaccination-records', VaccinationRecordController::class);
    $router->resource('doctors', DoctorController::class);
    $router->resource('vaccination-records-2', VaccinationRecordController2::class);
    
});

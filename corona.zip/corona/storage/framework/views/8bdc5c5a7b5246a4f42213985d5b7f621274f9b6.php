<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('/assets/css/custom/ad-post.css'), false); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
use App\Models\category;
use App\Models\Profile;
$user_id = ((int) request()->segment(2));
if ($user_id < 0) { die('User not found.'); } 
    
    $prof=Profile::where("user_id",$user_id)->First();
    if(!$prof){
    $new_prof = new Profile(['user_id' => $user_id]);
    $new_prof->save();
    $prof = Profile::where("user_id",$user_id)->First();
    }
    if(!$prof){
    dd("Profile not found");
    }
    ?>
    <!-- id created_at updated_at user_id first_name last_name
    company_name email phone_number location about services longitude latitude division opening_hours profile_photo
    cover_photo facebook twitter whatsapp youtube instagram last_seen -->

    <section class="adpost-part">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <?php echo e(Form::open(array('url' => 'profile-edit/'.$user_id,'files' => true) ), false); ?>


                    <?php
                    Form::model($prof);
 
                    ?>

                    
                    <?php echo csrf_field(); ?>
                    <input type="text" name="user_id" id="user_id" value="<?php echo e($user_id, false); ?>" hidden>
                    <div class="adpost-card">
                        <div class="adpost-title">
                            <h3>Updaing Profile</h3>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('first_name', 'First name',['class' => "form-label", 'required' => 'required']), false); ?>

                                    <?php echo e(Form::text('first_name', null,['class' => "form-control"]), false); ?>

                                    <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('last_name', 'Last name',['class' => "form-label", 'required' => 'required']), false); ?>

                                    <?php echo e(Form::text('last_name', null,['class' => "form-control"]), false); ?>

                                    <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">

                                    <?php echo e(Form::label('company_name', 'Company name',['class' => "form-label"]), false); ?>

                                    <?php echo e(Form::text('company_name', null,['class' => "form-control", 'required' => 'required']), false); ?>


                                    <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">

                                    <?php echo e(Form::label('username', 'Company username',['class' => "form-label"]), false); ?>

                                    <?php echo e(Form::text('username', null,['class' => "form-control", 'required' => 'required']), false); ?>


                                    <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">

                                    <?php echo e(Form::label('email', 'Email address',['class' => "form-label", 'required' => 'required']), false); ?>

                                    <?php echo e(Form::text('email', null,['class' => "form-control"]), false); ?>



                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">

                                    <?php echo e(Form::label('phone_number', 'Phone number',['class' => "form-label", 'required' => 'required']), false); ?>

                                    <?php echo e(Form::text('phone_number', null,['class' => "form-control"]), false); ?>


                                    <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">

                                    <?php echo e(Form::label('location', 'Location address',['class' => "form-label", 'required' => 'required']), false); ?>

                                    <?php echo e(Form::text('location', null,['class' => "form-control"]), false); ?>


                                    <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">


                                    <?php echo e(Form::label('about', 'About Company',['class' => "form-label", 'required' => 'required']), false); ?>

                                    <?php echo e(Form::textarea('about', null,['class' => "form-control"]), false); ?>


                                    <?php $__errorArgs = ['about'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">


                                    <?php echo e(Form::label('services', 'Company services',['class' => "form-label", 'required' => 'required']), false); ?>

                                    <?php echo e(Form::text('services', null,['class' => "form-control"]), false); ?>

                                    <small>Seperated with commas</small>


                                    <?php $__errorArgs = ['services'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    
                                    <?php echo e(Form::label('longitude', 'National ID Number or Passport Number',['class' => "form-label", 'required' => 'required']), false); ?>

                                    <?php echo e(Form::text('longitude', null,['class' => "form-control"]), false); ?>

                                      
                                    <?php $__errorArgs = ['longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <input type="text" hidden value="<?php echo e(old('latitude'), false); ?>" id="latitude" name="latitude" />
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="profile_photo" class="form-label">Profile
                                        photo</label>
                                    <input type="file" accept=".png,.jpg,.jpeg,.gif" value="<?php echo e(old('profile_photo'), false); ?>"
                                        name="profile_photo[]" id="profile_photo" class="form-control">
                                    <?php $__errorArgs = ['profile_photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group"><label for="cover_photo" class="form-label">Cover
                                        photo</label>
                                    <input type="file" accept=".png,.jpg,.jpeg,.gif" value="<?php echo e(old('cover_photo'), false); ?>"
                                        name="cover_photo[]" id="cover_photo" class="form-control">
                                    <?php $__errorArgs = ['cover_photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group"><label for="facebook" class="form-label">Facebook</label>
                                    <input type="url" value="<?php echo e(old('facebook',$prof->facebook), false); ?>" name="facebook" id="facebook"
                                        class="form-control">
                                    <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group"><label for="twitter" class="form-label">twitter</label>
                                    <input type="url" value="<?php echo e(old('twitter',$prof->twitter), false); ?>" name="twitter" id="twitter"
                                        class="form-control">
                                    <?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group"><label for="division" class="form-label">District</label>,
                                    <input type="text" value="<?php echo e(old('division',$prof->division), false); ?>" name="division" id="division"
                                        class="form-control">
                                    <?php $__errorArgs = ['division'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group"><label for="whatsapp" class="form-label">whatsapp</label>
                                    <input type="url" value="<?php echo e(old('whatsapp',$prof->whatsapp), false); ?>" name="whatsapp" id="whatsapp"
                                        class="form-control">
                                    <?php $__errorArgs = ['whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group"><label for="youtube" class="form-label">youtube</label>
                                    <input type="url" value="<?php echo e(old('youtube',$prof->youtube), false); ?>" name="youtube" id="youtube"
                                        class="form-control">
                                    <?php $__errorArgs = ['youtube'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group"><label for="instagram" class="form-label">instagram</label>
                                    <input type="url" value="<?php echo e(old('instagram',$prof->instagram), false); ?>" name="instagram" id="instagram"
                                        class="form-control">
                                    <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group"><label for="linkedin" class="form-label">Linkedin</label>
                                    <input type="url" value="<?php echo e(old('linkedin',$prof->linkedin), false); ?>" name="linkedin" id="linkedin"
                                        class="form-control">
                                    <?php $__errorArgs = ['linkedin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>



                    </div>


                    <div class="adpost-card pb-2">
                        <div class="adpost-agree">
                            <div class="form-group"><input type="checkbox" class="form-check"></div>
                            <p>Send me Trade Email/SMS Alerts for people looking to buy mobile handsets in www By
                                clicking "Post", you agree to our <a href="#">Terms of Use</a>and <a href="#">Privacy
                                    Policy</a>and acknowledge that you are the rightful owner of
                                this item and using Trade to find a genuine buyer.</p>
                        </div>
                        <div class="form-group text-right"><button class="btn btn-inline"><i
                                    class="fas fa-check-circle"></i><span>UPDATE PROFILE</span></button></div>
                    </div>
                    
                    <?php echo e(Form::close(), false); ?>


                </div>
                <div class="col-lg-4">
                    <div class="account-card alert fade show">
                        <div class="account-title">
                            <h3>Safety Tips</h3><button data-dismiss="alert">close</button>
                        </div>
                        <ul class="account-card-text">
                            <li>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit debitis odio perferendis
                                    placeat at aperiam.</p>
                            </li>
                            <li>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit debitis odio perferendis
                                    placeat at aperiam.</p>
                            </li>
                            <li>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit debitis odio perferendis
                                    placeat at aperiam.</p>
                            </li>
                            <li>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit debitis odio perferendis
                                    placeat at aperiam.</p>
                            </li>
                            <li>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit debitis odio perferendis
                                    placeat at aperiam.</p>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac/Desktop/Github/buy-and-sell/resources/views/dashboard/profile-edit.blade.php ENDPATH**/ ?>
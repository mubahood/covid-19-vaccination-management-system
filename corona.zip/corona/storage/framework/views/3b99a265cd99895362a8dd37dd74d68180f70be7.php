<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->

<head>
    <link rel="stylesheet" href="<?php echo e(URL::asset('assets/css/vendor/bootstrap.min.css'), false); ?>">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="author" content="Mironcoder">
    <meta name="email" content="mironcoder@gmail.com">
    <meta name="profile" content="https://themeforest.net/user/mironcoder">
    <meta name="name" content="Classicads">
    <meta name="type" content="Classified Advertising">
    <meta name="title" content="Classicads - Classified Ads HTML Template">
    <meta name="keywords"
        content="classicads, classified, ads, classified ads, listing, business, directory, jobs, marketing, portal, advertising, local, posting, ad listing, ad posting,">
    <title>Home - Classicads</title>
    <link rel="icon" href="images/favicon.png">
    <link rel="stylesheet" href="<?php echo e(URL::asset('/assets/fonts/flaticon/flaticon.css'), false); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('/assets/fonts/font-awesome/fontawesome.css'), false); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('/assets/css/vendor/slick.min.css'), false); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('/assets/css/vendor/bootstrap.min.css'), false); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('/assets/css/custom/main.css'), false); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('/assets/css/custom/index.css'), false); ?>">
    <?php echo $__env->yieldContent('head'); ?>
</head>

<body>
    <?php echo $__env->yieldContent('content'); ?>
    <script src="<?php echo e(URL::asset('/assets/js/vendor/jquery-1.12.4.min.js'), false); ?>"></script>
    <script src="<?php echo e(URL::asset('/assets/js/vendor/popper.min.js'), false); ?>"></script>
    <script src="<?php echo e(URL::asset('/assets/js/vendor/bootstrap.min.js'), false); ?>"></script>
    <script src="<?php echo e(URL::asset('/assets/js/vendor/slick.min.js'), false); ?> "></script>
    <script src="<?php echo e(URL::asset('/assets/js/custom/slick.js'), false); ?>"></script>
    <script src="<?php echo e(URL::asset('/assets/js/custom/main.js'), false); ?> "></script>
</body>

</html>
<?php /**PATH /Users/mac/Desktop/Github/buy-and-sell/resources/views/layouts/layout1.blade.php ENDPATH**/ ?>
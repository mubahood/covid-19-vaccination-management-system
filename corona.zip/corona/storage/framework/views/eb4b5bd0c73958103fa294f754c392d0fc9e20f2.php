<div class="feature-card "><a href="<?php echo e(url($item->slug), false); ?>" class="feature-img"><img src="<?php echo e($item->get_thumbnail(), false); ?>"
            alt="feature"></a>
    <div class="feature-content p-2 pl-3 pr-3">
        <ol class="breadcrumb feature-category mb-0 mt-0">

            <li class="breadcrumb-item"><a href="<?php echo e(url($item->category->slug), false); ?>"><?php echo e($item->category->name, false); ?></a></li>
        </ol>
        <h3 class="feature-title h5 mb-0 mt-0"><a href="<?php echo e(url($item->slug), false); ?>"><?php echo e($item->name, false); ?></a></h3>
        <div class="feature-meta"><span class="feature-price">UGX.
                <?php echo e(number_format($item->price), false); ?><small>/Negotiable</small></span><span class="feature-time"><i
                    class="fas fa-clock"></i><?php echo e($item->created_at->diffForHumans(), false); ?></span>
        </div>
    </div>
</div><?php /**PATH /Users/mac/Desktop/Github/buy-and-sell/resources/views/components/product-featured.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <link rel="shortcut icon" href="images/favicon.png">
    <title>THE Uganda Covid-19 - portal</title>
    <link rel="stylesheet" href="assets/css/bundle0ad1.css?ver=111">
    <link rel="stylesheet" href="assets/css/styles0ad1.css?ver=111">
</head>

<body class="nk-body">
    <div class="nk-wrap">
        <header class="nk-header bg-light has-overlay" id="home">
                <div class="w-100 bg-dark mt-3" style="height: 5px"></div>
                <div class="w-100 bg-warning " style="height: 5px"></div>
                <div class="w-100 bg-danger " style="height: 5px"></div>
        </header>
        <main class="nk-pages">
            <section class="section section-l bg-white section-about" id="about">
                <div class="container">
                    <div class="section-content">
                        <h1 class="heading text-dark"> <span >UGDANDA</span> <span class="heading-sm"> <span
                            class="sup text-warning" style="font-size: 2.2rem;">COVID-19</span> <span class="sub text-danger">PORTAL</span> </span></h1>
                        <div class="row g-gs justify-content-between">
                            <div class="col-lg-7">
                                <div class="text-block">
                                    <h5 class="subtitle">About the disease</h5>
                                    <h2 class="title">Coronavirus <br class="d-sm-none">(COVID-19)</h2>
                                    <p class="lead"><strong>COVID-19 is a new illness that can affect your lungs and
                                            airways.</strong> It's caused by a virus called coronavirus. It was
                                        discovered in December 2019 in Wuhan, Hubei, China.</p>
                                    <p>Common signs of infection include respiratory symptoms, fever, cough, shortness
                                        of breath and breathing difficulties. In more severe cases, infection can cause
                                        pneumonia, severe acute respiratory syndrome, kidney failure and even death.</p>
                                    <p>Standard recommendations to prevent infection spread include regular hand
                                        washing, covering mouth and nose when coughing and sneezing, thoroughly cooking
                                        meat and eggs. Avoid close contact with anyone showing symptoms of respiratory
                                        illness such as coughing and sneezing.</p>
                                        <a class="btn btn-primary" href="<?php echo e(url("/"), false); ?>">BACK TO HOME</a>
                                </div>
                            </div>
                            <div class="col-lg-5 col-xl-4">
                                <div class="wgs wgs-card mt-sm-2 mt-md-4 mt-lg-0 ml-lg-4 ml-xl-0">
                                    <div class="wgs-head">
                                        <h4>What you need to want?</h4>
                                    </div>
                                    <ul class="wgs-list">
                                        <li><a class="scrollto" href="<?php echo e(url('near-me'), false); ?>">Vaccination Labs near me</a>
                                        </li>
                                        <li><a class="scrollto" href="<?php echo e(url("verification"), false); ?>">My Next Vaccination
                                                Details</a></li>
                                        <li><a class="scrollto" href="<?php echo e(url("verification"), false); ?>">Validate
                                                vaccination</a></li>
                                        <li><a class="scrollto" href="#faq">Covid-19 Updates</a></li>
                                        <li><a class="scrollto" href="#faq">Covid-19 statistics</a></li>
                                        <li><a class="scrollto" href="<?php echo e(url("/"), false); ?>">BACK TO HOME</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </main>

    </div>
    <script src="assets/js/bundle0ad1.js?ver=111"></script>
    <script src="assets/js/scripts0ad1.js?ver=111"></script>
</body>

</html><?php /**PATH /Applications/MAMP/htdocs/corona/resources/views/main/vaccinate.blade.php ENDPATH**/ ?>
<?php

$id = Auth::id();
$seg = request()->segment(1);

use Illuminate\Support\Facades\Auth;
$user = Auth::user();

?>
<section class="dash-header-part mt-4">
    <div class="container">
        <div class="dash-header-card pt-0 ">
            <div class="row ">
                <div class="col-lg-12 ">
                    <div class="dash-menu-list pt-0 mt-0 ">
                        <ul>
                            <li><a <?php if($seg=='dashboard'  ): ?> class="active" <?php endif; ?>
                                    href="<?php echo e(route('dashboard'), false); ?>">dashboard</a></li>

                            <li><a <?php if($seg=='post-ad' || $seg== "complete-profile-request"): ?> class="active" <?php endif; ?> href="<?php echo e(route('post-ad'), false); ?>">Post
                                    ad</a></li>

                            <li><a <?php if($seg=='messages' ): ?> class="active" <?php endif; ?>
                                    href="<?php echo e(url('messages'), false); ?>">Messages</a></li>

                            <li><a <?php if($seg=='membership' ): ?> class="active" <?php endif; ?>
                                    href="<?php echo e(route('membership'), false); ?>">Membership</a></li>
                            <li><a <?php if($seg=='profile-edit' ): ?> class="active" <?php endif; ?>
                                    href="<?php echo e(url('profile-edit'), false); ?>/<?php echo e($id, false); ?>">My Profile</a></li>
                            <li><a <?php if($seg=='post-ad' ): ?> class="active" <?php endif; ?>
                                    href="<?php echo e(url('profile-edit'), false); ?>/<?php echo e($id, false); ?>">Settings</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /Users/mac/Desktop/Github/buy-and-sell/resources/views/layouts/dashboard-header.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('/assets/css/custom/ad-post.css'), false); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
use App\Models\category;
use App\Models\Country;
use App\Models\City;
$seg = request()->segment(2);
$cats = category::where('slug', $seg)->firstOrFail();
$countries = Country::all();
$cities = City::all();
?>
<section class="adpost-part pt-0">
    <div class="container">
        <div class="row">
            <div class="colwqq-lg-10">
                <form method="POST" action="<?php echo e(url('post-ad'), false); ?>" enctype="multipart/form-data" class="adpost-form">
                    <?php echo csrf_field(); ?>
                    <input type="text" name="category_id" id="category_id" value="<?php echo e($cats->id, false); ?>" hidden>
                    <div class="adpost-card">
                        <div class="row border-bottom pb-3 mb-3">
                            <div class="col-md-6">
                                <div class="">
                                    <h4>Fill in the details</h4>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class=" text-right text-dark">
                                    <img width="20" src="<?php echo e(URL::asset('storage')."/".$cats->image, false); ?>"> <?php echo e($cats->name, false); ?>

                                </div>
                            </div>
                        </div>

                        <div class="row " style="margin-top: 2rem">
                            <div class="col-md-2"></div>
                            <div class="col-md-8">

                                <?php $__currentLoopData = $cats->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <div class="col-lg-12">

                                        <?php if($item->type == "checkbox"): ?>
                                        <div class="form-group"><label class="form-label" for="<?php echo e($item->name, false); ?>">
                                                <?php if($item->is_required): ?>
                                                <span class="text-danger">*</span>
                                                <?php endif; ?> </label>
                                            <?php echo e($item->name, false); ?>

                                            <?php
                                            $_options = (explode(",",$item->options));
                                            ?>
                                            <div class="row">
                                                <?php for($i = 0; $i < count($_options); $i++): ?> <div class="col-md-4">
                                                    <small class="d-block">
                                                        <input type="checkbox" value="<?php echo e($_options[$i], false); ?>"
                                                            id="<?php echo e($_options[$i], false); ?>" name="<?php echo e("__".$item->id."[]", false); ?>" 
                                                            <?php if($item->is_required): ?>
                                                        required
                                                        <?php endif; ?> >
                                                        <label for="<?php echo e($_options[$i], false); ?>"><?php echo e($_options[$i], false); ?></label>
                                                    </small>
                                            </div>
                                            <?php endfor; ?>
                                        </div>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <?php endif; ?>

                                    <?php if($item->type == "radio"): ?>
                                    <div class="form-group"><label class="form-label" for="<?php echo e($item->name, false); ?>">
                                            <?php if($item->is_required): ?>
                                            <span class="text-danger">*</span>
                                            <?php endif; ?> </label>
                                        <?php echo e($item->name, false); ?>

                                        <?php
                                        $_options = (explode(",",$item->options));
                                        ?>
                                        <?php for($i = 0; $i < count($_options); $i++): ?> <small class="d-block">
                                            <input type="radio" value="<?php echo e($_options[$i], false); ?>"
                                                id="<?php echo e($_options[$i], false); ?>" name="<?php echo e("__".$item->id, false); ?>" 
                                                <?php if($item->is_required): ?>
                                            required
                                            <?php endif; ?> >
                                            <label for="<?php echo e($_options[$i], false); ?>"><?php echo e($_options[$i], false); ?></label>
                                            </small>
                                            <?php endfor; ?>
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <?php endif; ?>


                                    <?php if($item->type == "select"): ?>
                                    <div class="form-group"><label class="form-label" for="<?php echo e($item->name, false); ?>">
                                            <?php if($item->is_required): ?>
                                            <span class="text-danger">*</span>
                                            <?php endif; ?> </label>
                                        <?php echo e($item->name, false); ?>


                                        <select value="<?php echo e(old("__".$item->id ), false); ?>" id="<?php echo e($item->name, false); ?>"
                                            name="<?php echo e("__".$item->id, false); ?>" <?php if($item->is_required): ?>
                                            required
                                            <?php
                                            $_options = (explode(",",$item->options));
                                            ?>
                                            <?php endif; ?> class="form-control">
                                            <option value=""></option>
                                            <?php for($i = 0; $i < count($_options); $i++): ?> <option
                                                value="<?php echo e($_options[$i], false); ?>"><?php echo e($_options[$i], false); ?></option>
                                                <?php endfor; ?>
                                        </select>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <?php endif; ?>

                                    <?php if($item->type == "text"): ?>
                                    <div class="form-group"><label class="form-label" for="<?php echo e($item->name, false); ?>">
                                            <?php if($item->is_required): ?>
                                            <span class="text-danger">*</span>
                                            <?php endif; ?> </label>
                                        <?php echo e($item->name, false); ?>


                                        <input type="text" value="<?php echo e(old("__".$item->id ), false); ?>" id="<?php echo e($item->name, false); ?>"
                                            name="<?php echo e("__".$item->id, false); ?>" <?php if($item->is_required): ?>
                                        required
                                        <?php endif; ?> class="form-control">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <?php endif; ?>

                                    <?php if($item->type == "number"): ?>
                                    <div class="form-group"><label class="form-label" for="<?php echo e($item->name, false); ?>">
                                            <?php if($item->is_required): ?>
                                            <span class="text-danger">*</span>
                                            <?php endif; ?>
                                            <?php echo e($item->name, false); ?>


                                            <?php if($item->units): ?>
                                            <small>(<?php echo e($item->units, false); ?>)</small>
                                            <?php endif; ?>
                                        </label>
                                        <input type="number" value="<?php echo e(old("__".$item->id ), false); ?>" id="<?php echo e($item->name, false); ?>"
                                            name="<?php echo e("__".$item->id, false); ?>" <?php if($item->is_required): ?>
                                        required
                                        <?php endif; ?> class="form-control">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <?php endif; ?>

                                    <?php if($item->type == "textarea"): ?>
                                    <div class="form-group"><label class="form-label" for="<?php echo e($item->name, false); ?>">
                                            <?php if($item->is_required): ?>
                                            <span class="text-danger">*</span>
                                            <?php endif; ?>

                                            <?php echo e($item->name, false); ?>


                                            <?php if($item->units): ?>
                                            <small>(<?php echo e($item->units, false); ?>)</small>
                                            <?php endif; ?>
                                        </label>
                                        <textarea name="<?php echo e("__".$item->id, false); ?>" id="<?php echo e($item->name, false); ?>" <?php if($item->is_required): ?>
                                                required
                                                <?php endif; ?> class="form-control"><?php echo e(old("__".$item->id ), false); ?></textarea>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <?php endif; ?>

                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group"><label class="form-label" for="name">Product title
                                        </label><input type="text" class="form-control" id="name" required
                                            name="name" placeholder="Enter your pricing amount">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group"><label class="form-label">product image</label>
                                        <input type="file" name="images[]" required value="<?php echo e(old('images'), false); ?>"
                                            accept=".jpeg,.jpg,.png,.gif" class="form-control" multiple>
                                        <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group"><label class="form-label">Country</label>
                                        <select name="country_id" required class="form-control  custom-select"
                                            id="countries">
                                            <option selected>Select Country</option>
                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id, false); ?>"><?php echo e($item->name, false); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['country_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group"><label for="city_id" class="form-label">City</label>
                                        <select name="city_id" class="form-control  custom-select" required
                                            id="city_id">
                                            <option selected>Select city</option>
                                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id, false); ?>"><?php echo e($item->name, false); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['city_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                
                                <div class="col-md-12">
                                    <div class="form-group"><label class="form-label" for="price">Starting
                                            Price</label><input type="number" class="form-control" id="price" required
                                            name="price" placeholder="Enter your pricing amount">
                                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group"><label class="form-label">Service
                                            description</label><textarea class="form-control"
                                            placeholder="Describe your service here" required
                                            value="<?php echo e(old('description'), false); ?>" name="description"></textarea>
                                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message, false); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="col-md-2"></div>
                    </div>

            </div>


            <div class="adpost-card pb-2">
                <div class="adpost-agree">
                    <div class="form-group"><input type="checkbox" class="form-check"></div>
                    <p>Send me Trade Email/SMS Alerts for people looking to buy mobile handsets in www By
                        clicking "Post", you agree to our <a href="#">Terms of Use</a>and <a href="#">Privacy
                            Policy</a>and acknowledge that you are the rightful owner of
                        this item and using Trade to find a genuine buyer.</p>
                </div>
                <div class="form-group text-right"><button class="btn btn-inline"><i
                            class="fas fa-check-circle"></i><span>publish service</span></button></div>
            </div>
            </form>
        </div>
    </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<script>
    window.addEventListener('DOMContentLoaded', (event) => {
        const countries = $("#countries");
        const cities = JSON.parse('<?php echo json_encode($cities); ?>');
        countries.change(function(event) {
            console.clear()
            alert(cities.length);
            const country_id = event.currentTarget.options.selectedIndex;
            cities.forEach(element => {
                console.log(element);
                if (country_id == element.country_id) {
                    countries.selectedIndex
                }
            });
            console.log(event.currentTarget.options.selectedIndex);

        }); 
    });
</script>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac/Desktop/Github/buy-and-sell/resources/views/dashboard/post-ad.blade.php ENDPATH**/ ?>
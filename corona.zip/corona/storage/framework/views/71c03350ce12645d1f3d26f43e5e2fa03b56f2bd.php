<?php
use App\Models\District;

$search = "";
$results = [];
$found_some = false;
$is_search = false;
$search_title = "Search for nearest vaccinations labs";
if(isset($_GET['search'])){
$search = trim($_GET['search']);
$is_search = true;
if(strlen($search)>1){
$search_title = "Search results for ".$search;
$dis = District::where('name', 'like', '%' . $search . '%')->get();
if($dis != null){
if(!empty($dis)){
foreach ($dis as $key => $value) {
$found_some = true;
$results = $value->labs;
break;
}
}
}
}
}
?>
<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <link rel="shortcut icon" href="images/favicon.png">
    <title>Kovid19 | Coronavirus (COVID-19) Prevention & Informatics HTML Template</title>
    <link rel="stylesheet" href="assets/css/bundle0ad1.css?ver=111">
    <link rel="stylesheet" href="assets/css/styles0ad1.css?ver=111">
</head>

<body class="nk-body">
    <div class="nk-wrap">
        <header class="nk-header bg-light has-overlay" id="home">
            <div class="w-100 bg-dark mt-3" style="height: 5px"></div>
            <div class="w-100 bg-warning " style="height: 5px"></div>
            <div class="w-100 bg-danger " style="height: 5px"></div>
    </header>
        <main class="nk-pages">
            <section class="section section-l bg-white section-about" id="about">
                <div class="container">
                    <div class="section-content">
                        <h1 class="heading text-dark"> <span >UGDANDA</span> <span class="heading-sm"> <span
                            class="sup text-warning" style="font-size: 2.2rem;">COVID-19</span> <span class="sub text-danger">PORTAL</span> </span></h1>
                        
                        <div class="row g-gs justify-content-between">
                            <div class="col-lg-6">
                                <div class="text-block">
                                    <h5 class="subtitle">About the disease</h5>
                                    <h2 class="title">Coronavirus <br class="d-sm-none">(COVID-19)</h2>
                                    <p class="lead"><strong>COVID-19 is a new illness that can affect your lungs and
                                            airways.</strong> It's caused by a virus called coronavirus. It was
                                        discovered in December 2019 in Wuhan, Hubei, China.</p>
                                    <p>Common signs of infection include respiratory symptoms, fever, cough, shortness
                                        of breath and breathing difficulties. In more severe cases, infection can cause
                                        pneumonia, severe acute respiratory syndrome, kidney failure and even death.</p>
                                    <p>Standard recommendations to prevent infection spread include regular hand
                                        washing, covering mouth and nose when coughing and sneezing, thoroughly cooking
                                        meat and eggs. Avoid close contact with anyone showing symptoms of respiratory
                                        illness such as coughing and sneezing.</p>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <form action="<?php echo e(url('near-me'), false); ?>" method="get"
                                    class="wgs wgs-card mt-sm-2 mt-md-4 mt-lg-0 ml-lg-4 ml-xl-0">
                                    <div class="wgs-head">
                                        <h4><?php echo e($search_title, false); ?></h4>
                                    </div>
                                    <ul class="wgs-list">
                                        <li><input name="search" value="<?php echo e($search, false); ?>" required minlength="2"
                                                type="stearch" class="form-control"
                                                placeholder="Enter your district name"></li>
                                        <li>
                                            <button class="btn btn-primary btn-block mt-3 mb-3">SEARCH</button>
                                        </li>

                                        <?php if($found_some): ?>
                                        <div class="wgs-head">
                                            <h4>Labs in <span class="text-primary"><?php echo e($search, false); ?></span></h4>
                                        </div>
                                        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="d-block"><a class="text-dark d-block" href="#faq">
                                                <p class="d-block">
                                                    <b>LAB NAME:</b>
                                                    <span><?php echo e($item->name, false); ?></span>
                                                </p>
                                                <p class="d-block">
                                                    <b>ADDRESS:</b>
                                                    <span><?php echo e($item->address, false); ?></span>
                                                </p>
                                            </a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>

                                        <li><a class="scrollto" href="<?php echo e(url("vaccinate"), false); ?>">BACK TO MAIN MENU</a></li>
                                    </ul>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </main>

    </div>
    <script src="assets/js/bundle0ad1.js?ver=111"></script>
    <script src="assets/js/scripts0ad1.js?ver=111"></script>
</body>

</html><?php /**PATH /Applications/MAMP/htdocs/corona/resources/views/main/near-me.blade.php ENDPATH**/ ?>
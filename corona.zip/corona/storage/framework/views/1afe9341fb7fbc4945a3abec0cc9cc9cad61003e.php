<!DOCTYPE html>
<html lang="zxx" class="js">
<head>
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <link rel="shortcut icon" href="images/favicon.png">
    <title>The Uganda | Coronavirus (COVID-19) portal</title>
    <link rel="stylesheet" href="assets/css/bundle0ad1.css?ver=111">
    <link rel="stylesheet" href="assets/css/styles0ad1.css?ver=111">
</head>

<body class="nk-body">
    <div class="nk-wrap">
        <header class="nk-header bg-light has-overlay" id="home">
            <div class="overlay shape shape-a"></div>
            <div class="nk-navbar is-light is-sticky" id="navbar" >
                <div class="container">
                    <div class="nk-navbar-wrap">
                        <div class="nk-navbar-logo logo"> <a href="index.html" class="logo-link"> <img class="logo-dark"
                                    src="images/logo-dark.png" srcset="images/logo-dark2x.png 2x" alt="logo"> <img
                                    class="logo-light" src="images/logo-white.png" srcset="images/logo-white2x.png 2x"
                                    alt="logo"> </a></div>
                        <div class="nk-navbar-toggle d-lg-none"> <a href="#" class="toggle"
                                data-menu-toggle="navbar-menu"><em class="icon-menu icon ni ni-menu"></em><em
                                    class="icon-close icon ni ni-cross"></em></a></div>
                        <nav class="nk-navbar-menu" id="navbar-menu">
                            <ul class="nk-menu">
                                <li class="nk-menu-item"><a class="scrollto nav-link nk-menu-link" href="#home">Home</a>
                                </li>
                                <li class="nk-menu-item"><a class="scrollto nav-link nk-menu-link" href="#about">About
                                        Corona</a></li>
                                <li class="nk-menu-item"><a class="scrollto nav-link nk-menu-link"
                                        href="#symptoms">Symptoms</a></li>
                                <li class="nk-menu-item"><a class="scrollto nav-link nk-menu-link"
                                        href="#prevention">Prevention</a></li>
                                <li class="nk-menu-item"><a class="scrollto nav-link nk-menu-link"
                                        href="#treatment">Treatment</a></li>
                                </li>  
                                <li class="nk-menu-item"><a class="scrollto nav-link nk-menu-link"
                                        href="<?php echo e(url("admin"), false); ?>">Login</a></li>
                                </li>  
                            </ul>
                            <ul class="nk-menu-btns">
                                <li class="nk-menu-item"><a href="<?php echo e(url('/vaccinate'), false); ?>" class="btn btn-sm scrollto nav-link">GET VACCINATED</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
                <div class="w-100 bg-dark mt-3" style="height: 5px"></div>
                <div class="w-100 bg-warning " style="height: 5px"></div>
                <div class="w-100 bg-danger " style="height: 5px"></div>
            </div>
            <div class="nk-banner">
                <div class="container">
                    <div class="row g-gs align-items-center justify-content-between">
                        <div class="col-lg-5 order-lg-last">
                            <div class="nk-banner-image"> <img src="images/gfx/header-a.png" alt=""></div>
                        </div>
                        <div class="col-lg-6">
                            <div class="nk-banner-block">
                                <div class="content">
                                    <h1 class="heading text-dark"> <span >UGDANDA</span> <span class="heading-sm"> <span
                                                class="sup text-warning" style="font-size: 2.2rem;">COVID-19</span> <span class="sub text-danger">PORTAL</span> </span></h1>
                                    <p>The Coronavirus (COVID-19) was first reported in Wuhan, Hubei, China in December
                                        2019, the outbreak was later recognized as a pandemic by the World Health
                                        Organization (WHO) on 11 March 2020.</p>
                                    <ul class="nk-banner-btns">
                                        <li><a href="<?php echo e(url('/vaccinate'), false); ?>" class="btn scrollto"><span>GET VACCINATED</span><em
                                                    class="icon ni ni-shield-half"></em></a></li>
                                        <li><a href="vaccine.html" class="btn btn-transparent scrollto"><span>Get Tasted</span><em class="icon ni ni-arrow-right"></em></a></li>
                                    </ul>
                                    <div class="status" data-covid="world">
                                        <div class="row g-gs">
                                            <div class="col-sm-4 col-6">
                                                <div class="status-item">
                                                    <h6 class="title">Worldwide Cases</h6>
                                                    <div class="h3 count covid-stats-cases">~</div>
                                                </div>
                                            </div>
                                            <div class="col-sm-4 col-6">
                                                <div class="status-item">
                                                    <h6 class="title">Deaths</h6>
                                                    <div class="h3 count covid-stats-death">~</div>
                                                </div>
                                            </div>
                                            <div class="col-sm-4 col-6">
                                                <div class="status-item">
                                                    <h6 class="title">Recovered</h6>
                                                    <div class="h3 count covid-stats-recovered">~</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="status-note">* Last updated: <span
                                                class="covid-update-time">~</span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <main class="nk-pages">
            <section class="section section-l bg-white section-about" id="about">
                <div class="container">
                    <div class="section-content">
                        <div class="row g-gs justify-content-between">
                            <div class="col-lg-7">
                                <div class="text-block">
                                    <h5 class="subtitle">About the disease</h5>
                                    <h2 class="title">Coronavirus <br class="d-sm-none">(COVID-19)</h2>
                                    <p class="lead"><strong>COVID-19 is a new illness that can affect your lungs and
                                            airways.</strong> It's caused by a virus called coronavirus. It was
                                        discovered in December 2019 in Wuhan, Hubei, China.</p>
                                    <p>Common signs of infection include respiratory symptoms, fever, cough, shortness
                                        of breath and breathing difficulties. In more severe cases, infection can cause
                                        pneumonia, severe acute respiratory syndrome, kidney failure and even death.</p>
                                    <p>Standard recommendations to prevent infection spread include regular hand
                                        washing, covering mouth and nose when coughing and sneezing, thoroughly cooking
                                        meat and eggs. Avoid close contact with anyone showing symptoms of respiratory
                                        illness such as coughing and sneezing.</p>
                                </div>
                            </div>
                            <div class="col-lg-5 col-xl-4">
                                <div class="wgs wgs-card mt-sm-2 mt-md-4 mt-lg-0 ml-lg-4 ml-xl-0">
                                    <div class="wgs-head">
                                        <h4>What you need to know</h4>
                                    </div>
                                    <ul class="wgs-list">
                                        <li><a class="scrollto" href="#spread">How coronavirus is spread</a></li>
                                        <li><a class="scrollto" href="#symptoms">Symptoms of coronavirus</a></li>
                                        <li><a class="scrollto" href="#protect">How to protect yourself</a></li>
                                        <li><a class="scrollto" href="#treatment">Treatment for coronavirus</a></li>
                                        <li><a class="scrollto" href="#faq">Myth-Busters of coronavirus</a></li>
                                        <li><a class="scrollto" href="#faq">Questions & answers</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="section section-l bg-light section-spread" id="spread">
                <div class="container">
                    <div class="section-head text-center wide-md">
                        <h5 class="subtitle">How coronavirus is spread</h5>
                        <h2 class="title">Transmission of <br class="d-sm-none"> COVID-19</h2>
                        <p>Because it's a new illness, we do not know exactly how coronavirus spreads from person to
                            person. Similar viruses are spread in cough droplets.</p>
                    </div>
                    <div class="section-content">
                        <div class="row g-gs justify-content-center">
                            <div class="col-sm-10 col-md-8 col-lg-4">
                                <div class="box">
                                    <div class="box-gfx"> <img src="images/gfx/spread-a.png" alt=""></div>
                                    <div class="box-content">
                                        <h4 class="title">Person-to-person spread as close contact with infected</h4>
                                        <p>The coronavirus is thought to spread mainly from person to person. This can
                                            happen between people who are in close contact with one another.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-10 col-md-8 col-lg-4">
                                <div class="box">
                                    <div class="box-gfx"> <img src="images/gfx/spread-b.png" alt=""></div>
                                    <div class="box-content">
                                        <h4 class="title">Touching or contact with infected surfaces or objects</h4>
                                        <p>A person can get COVID-19 by touching a surface or object that has the virus
                                            on it and then touching their own mouth, nose, or possibly their eyes.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-10 col-md-8 col-lg-4">
                                <div class="box">
                                    <div class="box-gfx"> <img src="images/gfx/spread-c.png" alt=""></div>
                                    <div class="box-content">
                                        <h4 class="title">Droplets that from infected person coughs or sneezes</h4>
                                        <p>The coronavirus is thought to spread mainly from person to person. This can
                                            happen between people who are in close contact with one another.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <ul class="section-actions">
                            <li><a href="#faq" class="btn scrollto"><em class="icon ni ni-question"></em><span>Have
                                        question about spreading?</span></a></li>
                        </ul>
                    </div>
                </div>
            </section>
            <section class="section section-l bg-white section-symptom" id="symptoms">
                <div class="container">
                    <div class="section-head text-center wide-lg">
                        <h5 class="subtitle">What are the symptoms of COVID-19?</h5>
                        <h2 class="title">Symptoms of Coronavirus</h2>
                        <p>The most common symptoms of COVID-19 are fever, tiredness, and dry cough. Some patients may
                            have aches and pains, nasal congestion, runny nose, sore throat or diarrhea. These symptoms
                            are usually mild and begin gradually. Also the symptoms may appear 2-14 days after exposure.
                        </p>
                    </div>
                    <div class="section-content">
                        <div class="row g-gs justify-content-center">
                            <div class="col-sm-10 col-md-8 col-lg-4">
                                <div class="box2">
                                    <div class="box2-gfx"> <img src="images/gfx/symptom-a.png" alt=""></div>
                                    <div class="box2-content">
                                        <h5 class="title">Fever</h5>
                                        <p><strong>High Fever</strong> – this means you feel hot to touch on your chest
                                            or back (you do not need to measure your temperature). It is a common sign
                                            and also may appear in 2-10 days if you affected.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-10 col-md-8 col-lg-4">
                                <div class="box2">
                                    <div class="box2-gfx"> <img src="images/gfx/symptom-b.png" alt=""></div>
                                    <div class="box2-content">
                                        <h5 class="title">Cough</h5>
                                        <p><strong>Continuous cough</strong> – this means coughing a lot for more than
                                            an hour, or 3 or more coughing episodes in 24 hours (if you usually have a
                                            cough, it may be worse than usual).</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-10 col-md-8 col-lg-4">
                                <div class="box2">
                                    <div class="box2-gfx"> <img src="images/gfx/symptom-c.png" alt=""></div>
                                    <div class="box2-content">
                                        <h5 class="title">Shortness of breath</h5>
                                        <p><strong>Difficulty breathing</strong> – Around 1 out of every 6 people who
                                            gets COVID-19 becomes seriously ill and develops difficulty breathing or
                                            shortness of breath.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="section-cta">
                            <div class="row g-gs justify-content-center">
                                <div class="col-sm-10 col-md-8 col-lg-7 col-xl-8">
                                    <div class="notes"> <em class="icon ni ni-alert-fill-c"></em>
                                        <p><strong>Stay at home and call your doctor:</strong> If you think you have
                                            been exposed to COVID-19 and develop a fever and any symptoms, such as cough
                                            or difficulty breathing, call your healthcare provider as soon as possible
                                            for medical advice.</p>
                                    </div>
                                </div>
                                <div class="col-sm-10 col-md-8 col-lg-5 col-xl-4">
                                    <div class="d-flex justify-content-lg-end ml-sm-5 ml-4 pl-3 ml-lg-0 pl-lg-0"> <a
                                            href="#faq" class="btn scrollto"><em
                                                class="icon ni ni-question"></em><span>Have question? Find
                                                answer.</span></a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="section section-l bg-light section-advice pb-0 ov-h" id="prevention">
                <div class="container">
                    <div class="section-head text-center wide-lg">
                        <h5 class="subtitle">How to Protect Yourself?</h5>
                        <h2 class="title">Prevention <br class="d-sm-none"> &amp; advice</h2>
                        <p>There is currently no vaccine to prevent coronavirus disease 2019 (COVID-19). <strong>The
                                best way to prevent illness is to avoid being exposed to this virus.</strong> Stay aware
                            of the latest information on the COVID-19 outbreak, available on the WHO website and through
                            your national and local public health authority.</p>
                    </div>
                    <div class="section-content">
                        <div class="row g-gs gy-sm-m">
                            <div class="col-lg-3 col-sm-6">
                                <div class="box3">
                                    <div class="box3-gfx"> <img src="images/gfx/advice-a.png" alt=""></div>
                                    <div class="box3-content">
                                        <h5 class="title">Wash your hands frequently</h5>
                                        <p>Regularly and thoroughly clean your hands with an alcohol-based hand rub or
                                            wash them with soap and water for at least 20 seconds.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-sm-6">
                                <div class="box3">
                                    <div class="box3-gfx"> <img src="images/gfx/advice-b.png" alt=""></div>
                                    <div class="box3-content">
                                        <h5 class="title">Maintain social distancing</h5>
                                        <p>Maintain at least 1 metre (3 feet) distance between yourself & anyone who is
                                            coughing or sneezing. If you are too close, get chance to infected.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-sm-6">
                                <div class="box3">
                                    <div class="box3-gfx"> <img src="images/gfx/advice-c.png" alt=""></div>
                                    <div class="box3-content">
                                        <h5 class="title">Avoid touching face</h5>
                                        <p>Hands touch many surfaces and can pick up viruses. So, hands can transfer the
                                            virus to your eyes, nose or mouth and can make you sick.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-sm-6">
                                <div class="box3">
                                    <div class="box3-gfx"> <img src="images/gfx/advice-d.png" alt=""></div>
                                    <div class="box3-content">
                                        <h5 class="title">Practice respiratory hygiene</h5>
                                        <p>Maintain good respiratory hygiene as covering your mouth & nose with your
                                            bent elbow or tissue when cough or sneeze.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <ul class="section-actions">
                            <li><a href="#handwash" class="btn scrollto"><span>Check how you wash hand</span><em
                                        class="icon ni ni-arrow-long-right"></em></a></li>
                            <li><a href="#faq" class="btn btn-transparent scrollto"><span>Q&A on Coronaviruses</span><em
                                        class="icon ni ni-arrow-long-right"></em></a></li>
                        </ul>
                    </div>
                </div>
            </section>
            <section class="section section-l bg-light section-steps pb-4" id="steps">
                <div class="container">
                    <div class="section-content section-content-boxed">
                        <div class="row g-gs justify-content-center align-items-center">
                            <div class="col-lg-8">
                                <div class="list-block pr-lg-4">
                                    <h4 class="title">Take steps to protect others</h4>
                                    <ul class="list-check">
                                        <li><strong>Stay home if you’re sick</strong> – Stay home if you are sick,
                                            except to get medical care.</li>
                                        <li><strong>Cover your mouth and nose</strong> – with a tissue when you cough or
                                            sneeze (throw used tissues in the trash) or use the inside of your elbow.
                                        </li>
                                        <li><strong>Wear a facemask if you are sick</strong> – You should wear a
                                            facemask when you are around other people (e.g., sharing a room or vehicle)
                                            and before you enter a healthcare provider’s</li>
                                        <li><strong>Clean AND disinfect frequently touched surfaces daily</strong> –
                                            This includes phones, tables, light switches, doorknobs, countertops,
                                            handles, desks, toilets, faucets, and sinks.</li>
                                        <li><strong>Clean the dirty surfaces</strong> – Use detergent or soap and water
                                            prior to disinfection.</li>
                                        <li><strong>Stay informed about the local COVID-19 situation</strong> – Get
                                            up-to-date information about local COVID-19 activity from <a href="#">public
                                                health officials.</a></li>
                                        <li><strong>Dedicated, lined trash can</strong> – If possible, dedicate a lined
                                            trash can for the ill person. Use gloves when removing garbage bags, and
                                            handling & disposing of trash.</li>
                                    </ul>
                                </div>
                            </div>
                            <div class=" col-sm-10 col-md-8 col-lg-4"> <img src="images/gfx/steps.png"
                                    class="mb-2 mb-sm-0" alt=""></div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="section section-l bg-light section-handwash" id="handwash">
                <div class="container mt-n4">
                    <div class="section-subhead text-center">
                        <h4 class="title">Follow steps to <br class="d-sm-none"> wash hands</h4> <a href="#faq"
                            class="btn btn-sm btn-transparent scrollto"><span>Why do I need wash hand</span><em
                                class="icon ni ni-arrow-long-right"></em></a>
                    </div>
                    <div class="section-content">
                        <div class="row g-gs justify-content-center">
                            <div class="col-6 col-mb-5 col-sm-4 col-lg-2">
                                <div class="box4">
                                    <div class="box4-gfx"> <img src="images/gfx/hand-a.png" alt=""></div>
                                    <div class="box4-content">
                                        <h6 class="title">Soap on Hand</h6>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-mb-5 col-sm-4 col-lg-2">
                                <div class="box4">
                                    <div class="box4-gfx"> <img src="images/gfx/hand-b.png" alt=""></div>
                                    <div class="box4-content">
                                        <h6 class="title">Palm to Palm</h6>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-mb-5 col-sm-4 col-lg-2">
                                <div class="box4">
                                    <div class="box4-gfx"> <img src="images/gfx/hand-c.png" alt=""></div>
                                    <div class="box4-content">
                                        <h6 class="title">Between Fingers</h6>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-mb-5 col-sm-4 col-lg-2">
                                <div class="box4">
                                    <div class="box4-gfx"> <img src="images/gfx/hand-d.png" alt=""></div>
                                    <div class="box4-content">
                                        <h6 class="title">Back to Hands</h6>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-mb-5 col-sm-4 col-lg-2">
                                <div class="box4">
                                    <div class="box4-gfx"> <img src="images/gfx/hand-e.png" alt=""></div>
                                    <div class="box4-content">
                                        <h6 class="title">Clean with Water</h6>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-mb-5 col-sm-4 col-lg-2">
                                <div class="box4">
                                    <div class="box4-gfx"> <img src="images/gfx/hand-f.png" alt=""></div>
                                    <div class="box4-content">
                                        <h6 class="title">Focus on Wrist</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="section section-l bg-accent-light tc-light section-treatment has-overlay" id="treatment">
                <div class="overlay shape shape-b"></div>
                <div class="container">
                    <div class="section-content">
                        <div class="row g-gs gy-sm-m justify-content-between align-items-center">
                            <div class="col-lg-7 col-xl-6">
                                <div class="text-block">
                                    <h5 class="subtitle">Be carefull & Stay Safe</h5>
                                    <h2 class="title">Treatment for coronavirus</h2>
                                    <p> <strong>To date, there is no vaccine and no specific antiviral medicine to
                                            prevent or treat COVID-2019. </strong> However, those affected should
                                        receive care to relieve symptoms. People with serious illness should be
                                        hospitalized. Most patients recover thanks to supportive care.</p>
                                    <p>Antibiotics do not help, as they do not work against viruses. Treatment aims to
                                        relieve the symptoms while your body fights the illness. You'll need to stay in
                                        isolation, away from other people, until you have recovered.</p>
                                </div>
                            </div>
                            <div class="col-lg-5">
                                <div class="box5 bg-accent-dark">
                                    <h6 class="title">Self Care</h6>
                                    <p>If you have mild symptoms, stay at home until you’ve recovered. You can relieve
                                        your symptoms if you:</p>
                                    <ul class="list-arrow">
                                        <li>Rest and sleep</li>
                                        <li>Keep warm</li>
                                        <li>Drink plenty of liquids</li>
                                        <li>Use a room humidifier or take a hot shower to help ease a sore throat and
                                            cough</li>
                                    </ul>
                                    <h6 class="title">Medical Treatments</h6>
                                    <p>If you develop a fever, cough, and have difficulty breathing, promptly seek
                                        medical care. Call in advance and tell your health provider of any recent travel
                                        or recent contact with travelers.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="section section-l bg-light section-protect" id="protect">
                <div class="container">
                    <div class="section-head text-center wide-lg">
                        <h5 class="subtitle">Do’s &amp; Don’ts</h5>
                        <h2 class="title">Protect yourself</h2>
                        <p>The best thing you can do now is plan for how you can adapt your daily routine. Take few
                            steps to protect yourself as Clean your hands often, Avoid close contact, Cover coughs and
                            sneezes, clean daily used surfaces etc. The best way to prevent illness is to avoid being
                            exposed to this virus.</p>
                    </div>
                    <div class="section-content">
                        <div class="row g-gs justify-content-center flex-lg-nowrap">
                            <div class="col-md-8 col-lg-5 col-xl-6 align-self-end">
                                <div class="protect-block-gfx"> <img src="images/gfx/protect.png" alt=""></div>
                            </div>
                            <div class="col-6 col-mb-5 col-sm-6 col-lg-4 col-xl-3 flex-grow-1 order-lg-first">
                                <div class="protect-item negative">
                                    <div class="protect-gfx"> <img src="images/gfx/donts-a.png" alt=""></div>
                                    <div class="protect-text">
                                        <h5 class="title">Avoid Close Contact</h5>
                                    </div>
                                </div>
                                <div class="protect-item negative">
                                    <div class="protect-gfx"> <img src="images/gfx/donts-b.png" alt=""></div>
                                    <div class="protect-text">
                                        <h5 class="title">Don’t Touch Face</h5>
                                    </div>
                                </div>
                                <div class="protect-item negative">
                                    <div class="protect-gfx"> <img src="images/gfx/donts-c.png" alt=""></div>
                                    <div class="protect-text">
                                        <h5 class="title">Social Distancing</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-mb-5 col-sm-6 col-lg-4 col-xl-3 flex-grow-1 ">
                                <div class="protect-item positive">
                                    <div class="protect-gfx"> <img src="images/gfx/dos-a.png" alt=""></div>
                                    <div class="protect-text">
                                        <h5 class="title">Wash Your Hands</h5>
                                    </div>
                                </div>
                                <div class="protect-item positive">
                                    <div class="protect-gfx"> <img src="images/gfx/dos-b.png" alt=""></div>
                                    <div class="protect-text">
                                        <h5 class="title">Drink Much Watar</h5>
                                    </div>
                                </div>
                                <div class="protect-item positive">
                                    <div class="protect-gfx"> <img src="images/gfx/dos-c.png" alt=""></div>
                                    <div class="protect-text">
                                        <h5 class="title">Use Face Mask</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section> 
        </main>
        <footer class="nk-footer bg-dark tc-light has-overlay">
            <div class="overlay shape shape-c"></div>
            <section class="section section-footer section-m tc-light">
                <div class="container">
                    <div class="nk-footer-top">
                        <div class="row g-gs gy-m">
                            <div class="col-lg-3 col-md-9 mr-auto">
                                <div class="wgs wgs-about">
                                    <div class="wgs-logo logo"> <a href="index.html" class="logo-link"> <img
                                                src="images/logo-white.png" srcset="images/logo-white2x.png 2x"
                                                alt="logo"> </a></div>
                                    <div class="wgs-about-text">
                                        <p>This website is for health information and advice about coronavirus
                                            (COVID-19), how to prevent and protect yourself from disease.</p>
                                        <p>Learn about the government response to coronavirus on GOV.UK.</p>
                                    </div>
                                    <ul class="wgs-social">
                                        <li><a href="#"><em class="icon ni ni-facebook-f"></em></a></li>
                                        <li><a href="#"><em class="icon ni ni-twitter"></em></a></li>
                                        <li><a href="#"><em class="icon ni ni-youtube-fill"></em></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-sm-4 col-lg-2">
                                <div class="wgs wgs-menu">
                                    <h6 class="wgs-title">Quick Link</h6>
                                    <ul class="wgs-links">
                                        <li><a class="scrollto" href="#symptoms">Symptoms</a></li>
                                        <li><a class="scrollto" href="#prevention">Prevention</a></li>
                                        <li><a class="scrollto" href="#protect">Protect Youself</a></li>
                                        <li><a class="scrollto" href="#about">About Corona</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-sm-4 col-lg-3">
                                <div class="wgs wgs-menu">
                                    <h6 class="wgs-title">Helpfull link</h6>
                                    <ul class="wgs-links">
                                        <li><a href="#">Healthcare Professionals</a></li>
                                        <li><a href="#">Healthcare Facilities</a></li>
                                        <li><a href="#">Older Adults & Medical Conditions</a></li>
                                        <li><a href="#">Repare your Family</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-sm-4 col-lg-2">
                                <div class="wgs wgs-menu">
                                    <h6 class="wgs-title">Important Link</h6>
                                    <ul class="wgs-links">
                                        <li><a href="#">WHO Website</a></li>
                                        <li><a href="#">CDC Website</a></li>
                                        <li><a href="#">NHS Website</a></li>
                                        <li><a href="#">Harvard Health</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="nk-footer-bottom">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <p class="nk-copyright">&copy; 2020 KOVID-19. Template Made by <a
                                        href="https://softnio.com/">Softnio</a>.</p>
                            </div>
                            <div class="col-md-6">
                                <ul class="nk-footer-links justify-content-md-end">
                                    <li><a href="#">Privacy Policy</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <div class="nk-dislaimer">
                                    <p>Disclaimer: We hope you find the information presented on this website useful.
                                        This website is for general information and raise awareness of (2019-nCoV) only.
                                        <br class="d-none d-lg-block"> All the information based on WHO, NHS and CDC
                                        website. Information on our website is meant for awareness, if you have any
                                        doubt please verify from respective site.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </footer>
    </div>
    <script src="assets/js/bundle0ad1.js?ver=111"></script>
    <script src="assets/js/scripts0ad1.js?ver=111"></script>
</body>

</html><?php /**PATH /Applications/MAMP/htdocs/corona/resources/views/main/index.blade.php ENDPATH**/ ?>
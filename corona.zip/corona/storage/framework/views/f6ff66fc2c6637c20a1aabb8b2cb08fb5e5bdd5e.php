<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('sidebar'); ?>
##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##

<p>This is appended to the master sidebar.</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>




<?php
use Illuminate\Support\Facades\Auth;
use App\Models\Product;
use App\Models\City;
use App\Models\category;
$cats = category::all();

$is_searching = false;
$key_word = "";
$search_title = "";

if(isset($_GET['search'])){
if(strlen(isset($_GET['search']))>0){
$key_word = trim($_GET['search']);
$is_searching = true;
}
}

if($is_searching){
$products = Product::where('name', 'LIKE', "%$key_word%")->get();
$search_title = "Found ".count($products)." search results for \"".$key_word."\"";
}else{
$products = Product::all();
}
$cities = City::all();

?>


<section class="inner-section ad-list-part mt-4">
    <div class="container">
        <div class="row content-reverse">
            <div class="col-lg-4 col-xl-3">
                <div class="row">


                    <div class="col-md-6 col-lg-12">
                        <div class="product-widget">
                            <h6 class="product-widget-title">filter by category</h6>
                            <form class="product-widget-form">
                                <div class="product-widget-search"><input type="text" placeholder="search"></div>
                                <ul class="product-widget-list product-widget-scroll">
                                    <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    if($item->parent == null){
                                    $parent = 0;
                                    }else{
                                    $parent = (int)($item->parent);
                                    }

                                    if($parent>=1){
                                    continue;
                                    }
                                    ?>
                                    <li class="product-widget-dropitem"><button type="button"
                                            class="product-widget-link"><i class="fas fa-tags"></i>
                                            <?php echo e($item->name, false); ?>

                                        </button>
                                        <ul class="product-widget-dropdown">
                                            <?php $__currentLoopData = $item->sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(url("/"), false); ?>/<?php echo e($sub_item->slug, false); ?>"><?php echo e($sub_item->name, false); ?> (<?php echo e(count($sub_item->products), false); ?>)</a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul><button type="submit" class="product-widget-btn"><i
                                        class="fas fa-broom"></i><span>Clear Filter</span></button>
                            </form>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-12">
                        <div class="product-widget">
                            <h6 class="product-widget-title">Filter by cities</h6>
                            <form class="product-widget-form">
                                <div class="product-widget-search"><input type="text" placeholder="Search"></div>
                                <ul class="product-widget-list product-widget-scroll">
                                    <li class="product-widget-item">
                                        <div class="product-widget-checkbox"><input type="checkbox" id="chcek9">
                                        </div><label class="product-widget-label" for="chcek9"><span
                                                class="product-widget-text">Los Angeles</span><span
                                                class="product-widget-number">(95)</span></label>
                                    </li>
                                    <li class="product-widget-item">
                                        <div class="product-widget-checkbox"><input type="checkbox" id="chcek10">
                                        </div><label class="product-widget-label" for="chcek10"><span
                                                class="product-widget-text">San Francisco</span><span
                                                class="product-widget-number">(82)</span></label>
                                    </li>
                                    <li class="product-widget-item">
                                        <div class="product-widget-checkbox"><input type="checkbox" id="chcek11">
                                        </div><label class="product-widget-label" for="chcek11"><span
                                                class="product-widget-text">California</span><span
                                                class="product-widget-number">(1t)</span></label>
                                    </li>
                                    <li class="product-widget-item">
                                        <div class="product-widget-checkbox"><input type="checkbox" id="chcek12">
                                        </div><label class="product-widget-label" for="chcek12"><span
                                                class="product-widget-text">Manhattan</span><span
                                                class="product-widget-number">(46)</span></label>
                                    </li>
                                    <li class="product-widget-item">
                                        <div class="product-widget-checkbox"><input type="checkbox" id="chcek13">
                                        </div><label class="product-widget-label" for="chcek13"><span
                                                class="product-widget-text">Baltimore</span><span
                                                class="product-widget-number">(24)</span></label>
                                    </li>
                                    <li class="product-widget-item">
                                        <div class="product-widget-checkbox"><input type="checkbox" id="chcek14">
                                        </div><label class="product-widget-label" for="chcek14"><span
                                                class="product-widget-text">Avocados</span><span
                                                class="product-widget-number">(34)</span></label>
                                    </li>
                                    <li class="product-widget-item">
                                        <div class="product-widget-checkbox"><input type="checkbox" id="chcek15">
                                        </div><label class="product-widget-label" for="chcek15"><span
                                                class="product-widget-text">new york</span><span
                                                class="product-widget-number">(82)</span></label>
                                    </li>
                                    <li class="product-widget-item">
                                        <div class="product-widget-checkbox"><input type="checkbox" id="chcek16">
                                        </div><label class="product-widget-label" for="chcek16"><span
                                                class="product-widget-text">Houston</span><span
                                                class="product-widget-number">(45)</span></label>
                                    </li>
                                    <li class="product-widget-item">
                                        <div class="product-widget-checkbox"><input type="checkbox" id="chcek17">
                                        </div><label class="product-widget-label" for="chcek17"><span
                                                class="product-widget-text">Chicago</span><span
                                                class="product-widget-number">(19)</span></label>
                                    </li>
                                </ul><button type="submit" class="product-widget-btn"><i
                                        class="fas fa-broom"></i><span>Clear Filter</span></button>
                            </form>
                        </div>
                    </div>


                </div>
            </div>
            <div class="col-lg-8 col-xl-9">

                <?php if($is_searching): ?>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="header-filter">
                            <div class="">
                                <?php echo e($search_title, false); ?>

                            </div>
                            <div class="filter-action">
                                Clear search
                                <a href="/" title="Clear search" class="active ml-2"><i class="fa fa-times"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="ad-feature-slider slider-arrow">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if (isset($component)) { $__componentOriginalabe5708cba472885c12327e1fe98054e51034be9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ProductFeatured::class, ['item' => $item]); ?>
<?php $component->withName('product-featured'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalabe5708cba472885c12327e1fe98054e51034be9)): ?>
<?php $component = $__componentOriginalabe5708cba472885c12327e1fe98054e51034be9; ?>
<?php unset($__componentOriginalabe5708cba472885c12327e1fe98054e51034be9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="row ad-standard">



                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 ">
                        <?php if (isset($component)) { $__componentOriginal38812bf47c2ad01377aef8240815641b5bcc6805 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Product2::class, ['item' => $item]); ?>
<?php $component->withName('product2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal38812bf47c2ad01377aef8240815641b5bcc6805)): ?>
<?php $component = $__componentOriginal38812bf47c2ad01377aef8240815641b5bcc6805; ?>
<?php unset($__componentOriginal38812bf47c2ad01377aef8240815641b5bcc6805); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="footer-pagection">
                            <p class="page-info">Showing 12 of 60 Results</p>
                            <ul class="pagination">
                                <li class="page-item"><a class="page-link" href="#"><i
                                            class="fas fa-long-arrow-alt-left"></i></a></li>
                                <li class="page-item"><a class="page-link active" href="#">1</a></li>
                                <li class="page-item"><a class="page-link" href="#">2</a></li>
                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                <li class="page-item">...</li>
                                <li class="page-item"><a class="page-link" href="#">67</a></li>
                                <li class="page-item"><a class="page-link" href="#"><i
                                            class="fas fa-long-arrow-alt-right"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac/Desktop/Github/buy-and-sell/resources/views/main/index.blade.php ENDPATH**/ ?>
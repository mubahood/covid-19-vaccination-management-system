<?php
$id = Auth::id();
$user = Auth::user();
$status = $user->account_status();
if($status != "active"){
header("Location: ".route('complete_profile_request'));
die();
}

use App\Models\category;
$cats = category::where("parent",0)->get();
?>



<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('/assets/css/custom/ad-post.css'), false); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.dashboard-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<section class="adpost-part">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 ">
                <form class="adpost-form">
                    <div class="adpost-card pb-5">
                        <div class="adpost-title">
                            <h3 class="text-secondary text-center mb-3">STEP 1/2</h3>
                            <h3>Select Ad category</h3>
                        </div>
                        <ul class="adpost-plan-list">


                            <div class="accordion " id="accordionExample">

                                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="card">
                                    <div class="card-header" id="_<?php echo e($item->id, false); ?>">
                                        <h2 class="mb-0">
                                            <button class="btn  btn-block text-left border-0 pt-3 pb-0" type="button"
                                                data-toggle="collapse" data-target="#__<?php echo e($item->id, false); ?>"
                                                aria-expanded="true" aria-controls="__<?php echo e($item->id, false); ?>">
                                                <img width="25" height="25" src="storage/<?php echo e($item->image, false); ?>" alt="">
                                                <?php echo e($item->name, false); ?>

                                            </button>
                                        </h2>
                                    </div>

                                    <div id="__<?php echo e($item->id, false); ?>" class="collapse" aria-labelledby="_<?php echo e($item->id, false); ?>"
                                        data-parent="#accordionExample">
                                        <div class="card-body pb-0">
                                            <?php $__currentLoopData = $item->sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="border-bottom pb-2 pt-1">
                                                <a href="<?php echo e(url("post-ad/".$sub_cat->slug), false); ?>"
                                                    ><h6><?php echo e($sub_cat->name, false); ?> </h6>
                                                </a>
                                            </div> 
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>

 
                        </ul>
                    </div>

                </form>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac/Desktop/Github/buy-and-sell/resources/views/dashboard/post-ad-category-pick.blade.php ENDPATH**/ ?>
@php
use App\Models\District;
use App\Models\VaccinationRecord;

$search = "";
$results = [];
$found_some = false;
$is_search = false;
$vaccinated = false;
$vaccinated_full = false;
$rec_1 = null;
$search_title = "vaccinations verification";
if(isset($_GET['nin'])){
$search = trim($_GET['nin']);
$is_search = true;
if(strlen($search)>1){
$search_title = "Vaccination Verification for NIN: ".$search;
$rec_1 = VaccinationRecord::where('nin_number', '=', $search )->first();
if($rec_1){
if(isset($rec_1->id)){
$vaccinated = true;

$rec_2 = VaccinationRecord::where('full_name', '=', $rec_1->id )->first();
if($rec_2){
if(isset($rec_2->id)){
$vaccinated_full = true;
}
}
}
}


}
}
@endphp
<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <link rel="shortcut icon" href="images/favicon.png">
    <title>Kovid19 | Coronavirus (COVID-19) Prevention & Informatics HTML Template</title>
    <link rel="stylesheet" href="assets/css/bundle0ad1.css?ver=111">
    <link rel="stylesheet" href="assets/css/styles0ad1.css?ver=111">
</head>

<body class="nk-body">
    <div class="nk-wrap">
        <header class="nk-header bg-light has-overlay" id="home">
            <div class="w-100 bg-dark " style="height: 5px"></div>
            <div class="w-100 bg-warning " style="height: 5px"></div>
            <div class="w-100 bg-danger " style="height: 5px"></div>
    </header>
        <main class="nk-pages">
            <section class="section section-l bg-white section-about" id="about">
                <div class="container">
                    <div class="section-content">
                        <div class="row g-gs justify-content-between">
                            <div class="col-lg-6">
                                <h1 class="heading text-dark"> <span >UGDANDA</span> <span class="heading-sm"> <span
                                    class="sup text-warning" style="font-size: 2.2rem;">COVID-19</span> <span class="sub text-danger">PORTAL</span> </span></h1>
                                <div class="text-block">
                                    <h5 class="subtitle">About the disease</h5>
                                    <h2 class="title">Coronavirus <br class="d-sm-none">(COVID-19)</h2>
                                    <p class="lead"><strong>COVID-19 is a new illness that can affect your lungs and
                                            airways.</strong> It's caused by a virus called coronavirus. It was
                                        discovered in December 2019 in Wuhan, Hubei, China.</p>
                                    <p>Common signs of infection include respiratory symptoms, fever, cough, shortness
                                        of breath and breathing difficulties. In more severe cases, infection can cause
                                        pneumonia, severe acute respiratory syndrome, kidney failure and even death.</p>
                                    <p>Standard recommendations to prevent infection spread include regular hand
                                        washing, covering mouth and nose when coughing and sneezing, thoroughly cooking
                                        meat and eggs. Avoid close contact with anyone showing symptoms of respiratory
                                        illness such as coughing and sneezing.</p>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <form action="{{url('verification')}}" method="get"
                                    class="wgs wgs-card mt-sm-2 mt-md-4 mt-lg-0 ml-lg-4 ml-xl-0">
                                    <div class="wgs-head">
                                        <h4>{{$search_title}}</h4>
                                    </div>
                                    <ul class="wgs-list">
                                        <li><input name="nin" value="{{$search}}" required minlength="2" type="stearch"
                                                class="form-control" placeholder="Enter NIN number"></li>
                                        <li>
                                            <button class="btn btn-primary btn-block mt-3 mb-3">VERIFY</button>
                                        </li>

                                        @if (!$vaccinated)
                                        <div class="wgs-head">
                                            <h4>NIN <span class="text-primary">{{$search}}</span> was not found in our
                                                records</h4>
                                        </div>
                                        @else
                                        <div class="wgs-head">
                                            <h4>Vaccination records for NIN <span
                                                    class="text-primary">{{$search}}</span></h4>
                                        </div>
                                        <li class="d-block"><a class="text-dark d-block" href="#faq">
                                                <p class="d-block">
                                                    <b>NAME:</b>
                                                    <span>{{$rec_1->full_name}}</span>
                                                </p>
                                                <p class="d-block">
                                                    <b>GENDER:</b>
                                                    <span>{{$rec_1->gender}}</span>
                                                </p>
                                                <p class="d-block">
                                                    <b>CONTACT:</b>
                                                    <span>{{$rec_1->phone_number}}</span>
                                                </p>
                                                <p class="d-block">
                                                    <b>PHOTO:</b>
                                                    <img width="100" src="{{url("files/$rec_1->photo")}}" alt="">
                                                </p>
                                                <p class="d-block">
                                                    <b>AGE:</b>
                                                    <span>{{$rec_1->age}}</span>
                                                </p>
                                                <p class="d-block">
                                                    <b>ADDRESS:</b>
                                                    <span>{{$rec_1->address}}</span>
                                                </p>

                                                <p class="d-block">
                                                    <b>FIRST DOSE:</b>
                                                    <span class="text-success">VACCINATED <small>{{$rec_1->created_at->diffForHumans()}}</small></span>
                                                </p>
                                                @if ($vaccinated_full)
                                                    <p class="d-block">
                                                        <b>SECOND DOSE:</b>
                                                        <span class="text-success">VACCINATED <small>{{$rec_2->created_at->diffForHumans()}}</small></span>
                                                    </p>
                                                @else
                                                    <p class="d-block">
                                                        <b>SECOND DOSE:</b>
                                                        <span class="text-dark">scheduled on <small>{{$rec_1->next_vaccination}}</small></span>
                                                    </p>
                                                @endif

                                            </a></li>
                                        @endif
 

                                        <li><a class="scrollto" href="{{
                                            url("vaccinate") }}">BACK TO MAIN MENU</a></li>
                                    </ul>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </main>

    </div>
    <script src="assets/js/bundle0ad1.js?ver=111"></script>
    <script src="assets/js/scripts0ad1.js?ver=111"></script>
</body>

</html>
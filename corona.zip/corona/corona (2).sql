-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Oct 29, 2021 at 08:48 PM
-- Server version: 5.7.34
-- PHP Version: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `corona`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_menu`
--

CREATE TABLE `admin_menu` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL DEFAULT '0',
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uri` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permission` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_menu`
--

INSERT INTO `admin_menu` (`id`, `parent_id`, `order`, `title`, `icon`, `uri`, `permission`, `created_at`, `updated_at`) VALUES
(1, 0, 7, 'Dashboard', 'fa-bar-chart', '/', NULL, NULL, '2021-10-23 10:40:34'),
(2, 0, 8, 'Admin', 'fa-tasks', NULL, NULL, NULL, '2021-10-23 15:55:03'),
(3, 2, 9, 'Users', 'fa-users', 'auth/users', NULL, NULL, '2021-10-23 10:40:34'),
(8, 0, 11, 'Media manager', 'fa-file', 'media', NULL, '2021-10-20 12:28:29', '2021-10-26 05:31:30'),
(10, 0, 10, 'My Profile', 'fa-user-md', 'auth/setting', NULL, '2021-10-20 13:29:13', '2021-10-26 05:31:30'),
(16, 0, 1, 'Districts', 'fa-building', 'districts', NULL, '2021-10-23 05:13:25', '2021-10-23 06:12:22'),
(17, 0, 2, 'Laboratories', 'fa-gitlab', 'labs', NULL, '2021-10-23 05:32:33', '2021-10-23 06:12:22'),
(18, 0, 3, 'Stock records', 'fa-dropbox', 'stock-records', NULL, '2021-10-23 06:12:14', '2021-10-23 06:28:30'),
(19, 0, 5, 'Vaccination - 1st dose', 'fa-book', 'vaccination-records', NULL, '2021-10-23 06:48:23', '2021-10-23 10:40:57'),
(20, 0, 4, 'Doctors', 'fa-user-md', 'doctors', NULL, '2021-10-23 09:34:07', '2021-10-23 09:34:38'),
(21, 0, 6, 'Vaccination - 2nd Dose', 'fa-check', 'vaccination-records-2', NULL, '2021-10-23 10:40:13', '2021-10-23 10:40:34');

-- --------------------------------------------------------

--
-- Table structure for table `admin_operation_log`
--

CREATE TABLE `admin_operation_log` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `input` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_operation_log`
--

INSERT INTO `admin_operation_log` (`id`, `user_id`, `path`, `method`, `ip`, `input`, `created_at`, `updated_at`) VALUES
(1, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 08:50:22', '2021-10-20 08:50:22'),
(2, 1, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 08:50:28', '2021-10-20 08:50:28'),
(3, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 09:28:56', '2021-10-20 09:28:56'),
(4, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 09:29:21', '2021-10-20 09:29:21'),
(5, 1, 'admin/auth/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 09:29:27', '2021-10-20 09:29:27'),
(6, 1, 'admin/auth/users/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 09:29:32', '2021-10-20 09:29:32'),
(7, 1, 'admin/auth/users/create', 'GET', '127.0.0.1', '[]', '2021-10-20 09:30:01', '2021-10-20 09:30:01'),
(8, 1, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 09:30:08', '2021-10-20 09:30:08'),
(9, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 09:54:59', '2021-10-20 09:54:59'),
(10, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 09:55:11', '2021-10-20 09:55:11'),
(11, 1, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 09:56:12', '2021-10-20 09:56:12'),
(12, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 10:16:29', '2021-10-20 10:16:29'),
(13, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 10:16:34', '2021-10-20 10:16:34'),
(14, 1, 'admin/auth/login', 'GET', '127.0.0.1', '[]', '2021-10-20 10:16:40', '2021-10-20 10:16:40'),
(15, 1, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 10:16:45', '2021-10-20 10:16:45'),
(16, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 10:22:39', '2021-10-20 10:22:39'),
(17, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 10:24:09', '2021-10-20 10:24:09'),
(18, 1, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 10:24:22', '2021-10-20 10:24:22'),
(19, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 10:26:35', '2021-10-20 10:26:35'),
(20, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 10:30:31', '2021-10-20 10:30:31'),
(21, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 10:30:48', '2021-10-20 10:30:48'),
(22, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 10:30:54', '2021-10-20 10:30:54'),
(23, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '[]', '2021-10-20 12:05:46', '2021-10-20 12:05:46'),
(24, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '[]', '2021-10-20 12:08:53', '2021-10-20 12:08:53'),
(25, 1, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:09:10', '2021-10-20 12:09:10'),
(26, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 12:10:09', '2021-10-20 12:10:09'),
(27, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 12:11:10', '2021-10-20 12:11:10'),
(28, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 12:11:29', '2021-10-20 12:11:29'),
(29, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 12:12:43', '2021-10-20 12:12:43'),
(30, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 12:13:06', '2021-10-20 12:13:06'),
(31, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 12:13:47', '2021-10-20 12:13:47'),
(32, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:13:53', '2021-10-20 12:13:53'),
(33, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 12:15:48', '2021-10-20 12:15:48'),
(34, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:16:07', '2021-10-20 12:16:07'),
(35, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 12:20:05', '2021-10-20 12:20:05'),
(36, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 12:20:24', '2021-10-20 12:20:24'),
(37, 1, 'admin/auth/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:20:35', '2021-10-20 12:20:35'),
(38, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:20:53', '2021-10-20 12:20:53'),
(39, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:21:22', '2021-10-20 12:21:22'),
(40, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:21:50', '2021-10-20 12:21:50'),
(41, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:21:52', '2021-10-20 12:21:52'),
(42, 1, 'admin/auth/menu/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:22:09', '2021-10-20 12:22:09'),
(43, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:22:19', '2021-10-20 12:22:19'),
(44, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:22:21', '2021-10-20 12:22:21'),
(45, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:22:33', '2021-10-20 12:22:33'),
(46, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:22:42', '2021-10-20 12:22:42'),
(47, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 12:23:09', '2021-10-20 12:23:09'),
(48, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 12:25:10', '2021-10-20 12:25:10'),
(49, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 12:29:35', '2021-10-20 12:29:35'),
(50, 1, 'admin/media', 'GET', '127.0.0.1', '[]', '2021-10-20 12:29:39', '2021-10-20 12:29:39'),
(51, 1, 'admin/media', 'GET', '127.0.0.1', '[]', '2021-10-20 12:30:15', '2021-10-20 12:30:15'),
(52, 1, 'admin/media', 'GET', '127.0.0.1', '[]', '2021-10-20 12:31:49', '2021-10-20 12:31:49'),
(53, 1, 'admin/media', 'GET', '127.0.0.1', '{\"path\":\"\\/\",\"view\":\"list\",\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:32:00', '2021-10-20 12:32:00'),
(54, 1, 'admin/media', 'GET', '127.0.0.1', '{\"path\":\"\\/\",\"view\":\"table\",\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:32:02', '2021-10-20 12:32:02'),
(55, 1, 'admin/media/folder', 'POST', '127.0.0.1', '{\"name\":\"Romina Files\",\"dir\":\"\\/\",\"_token\":\"Gd34F9pnpWnNb7rTRcoB9sDURze5nXzvPQeDUeFU\"}', '2021-10-20 12:32:11', '2021-10-20 12:32:11'),
(56, 1, 'admin/media', 'GET', '127.0.0.1', '{\"path\":\"\\/\",\"view\":\"table\",\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:32:11', '2021-10-20 12:32:11'),
(57, 1, 'admin/media', 'GET', '127.0.0.1', '{\"path\":\"\\/Romina Files\",\"view\":\"table\",\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:32:14', '2021-10-20 12:32:14'),
(58, 1, 'admin/media', 'GET', '127.0.0.1', '{\"path\":\"\\/Romina Files\",\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:32:18', '2021-10-20 12:32:18'),
(59, 1, 'admin/media/upload', 'POST', '127.0.0.1', '{\"dir\":\"\\/Romina Files\",\"_token\":\"Gd34F9pnpWnNb7rTRcoB9sDURze5nXzvPQeDUeFU\"}', '2021-10-20 12:32:34', '2021-10-20 12:32:34'),
(60, 1, 'admin/media', 'GET', '127.0.0.1', '{\"path\":\"\\/Romina Files\"}', '2021-10-20 12:32:35', '2021-10-20 12:32:35'),
(61, 1, 'admin/media/download', 'GET', '127.0.0.1', '{\"file\":\"Romina Files\\/49142-1634636084-2.png\"}', '2021-10-20 12:32:40', '2021-10-20 12:32:40'),
(62, 1, 'admin/media', 'GET', '127.0.0.1', '{\"path\":\"\\/Romina Files\",\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:32:50', '2021-10-20 12:32:50'),
(63, 1, 'admin/media', 'GET', '127.0.0.1', '{\"path\":\"\\/Romina Files\",\"view\":\"list\",\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:32:55', '2021-10-20 12:32:55'),
(64, 1, 'admin/media', 'GET', '127.0.0.1', '{\"path\":\"\\/Romina Files\",\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:32:58', '2021-10-20 12:32:58'),
(65, 1, 'admin/media', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:32:59', '2021-10-20 12:32:59'),
(66, 1, 'admin/media', 'GET', '127.0.0.1', '{\"path\":\"\\/Romina Files\",\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:33:11', '2021-10-20 12:33:11'),
(67, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:34:22', '2021-10-20 12:34:22'),
(68, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 12:37:16', '2021-10-20 12:37:16'),
(69, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 12:39:03', '2021-10-20 12:39:03'),
(70, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 12:39:11', '2021-10-20 12:39:11'),
(71, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 12:40:21', '2021-10-20 12:40:21'),
(72, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 12:40:32', '2021-10-20 12:40:32'),
(73, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 12:41:25', '2021-10-20 12:41:25'),
(74, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 12:41:57', '2021-10-20 12:41:57'),
(75, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 12:44:02', '2021-10-20 12:44:02'),
(76, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 12:45:22', '2021-10-20 12:45:22'),
(77, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 12:45:47', '2021-10-20 12:45:47'),
(78, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:46:07', '2021-10-20 12:46:07'),
(79, 1, 'admin/auth/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:52:30', '2021-10-20 12:52:30'),
(80, 1, 'admin/auth/users/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:52:48', '2021-10-20 12:52:48'),
(81, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:52:51', '2021-10-20 12:52:51'),
(82, 1, 'admin/auth/roles/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:52:55', '2021-10-20 12:52:55'),
(83, 1, 'admin/auth/roles', 'POST', '127.0.0.1', '{\"slug\":\"admin\",\"name\":\"Admin\",\"permissions\":[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",null],\"_token\":\"Gd34F9pnpWnNb7rTRcoB9sDURze5nXzvPQeDUeFU\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/roles\"}', '2021-10-20 12:53:35', '2021-10-20 12:53:35'),
(84, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '[]', '2021-10-20 12:53:36', '2021-10-20 12:53:36'),
(85, 1, 'admin/auth/roles/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:53:42', '2021-10-20 12:53:42'),
(86, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:55:07', '2021-10-20 12:55:07'),
(87, 1, 'admin/auth/roles/2/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:55:12', '2021-10-20 12:55:12'),
(88, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:55:15', '2021-10-20 12:55:15'),
(89, 1, 'admin/auth/roles/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:55:23', '2021-10-20 12:55:23'),
(90, 1, 'admin/auth/roles/1', 'PUT', '127.0.0.1', '{\"slug\":null,\"name\":\"Super Admin\",\"permissions\":[\"1\",null],\"_token\":\"Gd34F9pnpWnNb7rTRcoB9sDURze5nXzvPQeDUeFU\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/roles\"}', '2021-10-20 12:55:57', '2021-10-20 12:55:57'),
(91, 1, 'admin/auth/roles/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-20 12:55:57', '2021-10-20 12:55:57'),
(92, 1, 'admin/auth/roles/1', 'PUT', '127.0.0.1', '{\"slug\":\"super-admin\",\"name\":\"Super Admin\",\"permissions\":[\"1\",null],\"_token\":\"Gd34F9pnpWnNb7rTRcoB9sDURze5nXzvPQeDUeFU\",\"_method\":\"PUT\"}', '2021-10-20 12:56:12', '2021-10-20 12:56:12'),
(93, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '[]', '2021-10-20 12:56:12', '2021-10-20 12:56:12'),
(94, 1, 'admin/auth/roles/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 12:56:34', '2021-10-20 12:56:34'),
(95, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:02:15', '2021-10-20 13:02:15'),
(96, 1, 'admin/auth/roles/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:02:18', '2021-10-20 13:02:18'),
(97, 1, 'admin/auth/roles', 'POST', '127.0.0.1', '{\"slug\":\"basic-user\",\"name\":\"Basic User\",\"permissions\":[\"2\",\"3\",null],\"_token\":\"Gd34F9pnpWnNb7rTRcoB9sDURze5nXzvPQeDUeFU\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/roles\"}', '2021-10-20 13:02:58', '2021-10-20 13:02:58'),
(98, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '[]', '2021-10-20 13:02:59', '2021-10-20 13:02:59'),
(99, 1, 'admin/auth/roles/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:08:20', '2021-10-20 13:08:20'),
(100, 1, 'admin/auth/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:08:27', '2021-10-20 13:08:27'),
(101, 1, 'admin/auth/users/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:08:33', '2021-10-20 13:08:33'),
(102, 1, 'admin/auth/users', 'POST', '127.0.0.1', '{\"username\":\"admin1\",\"name\":\"Muhindo Mubaraka\",\"password\":\"4321\",\"password_confirmation\":\"4321\",\"roles\":[\"2\",null],\"permissions\":[null],\"_token\":\"Gd34F9pnpWnNb7rTRcoB9sDURze5nXzvPQeDUeFU\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/users\"}', '2021-10-20 13:09:43', '2021-10-20 13:09:43'),
(103, 1, 'admin/auth/users', 'GET', '127.0.0.1', '[]', '2021-10-20 13:09:43', '2021-10-20 13:09:43'),
(104, 1, 'admin/auth/users/2', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:09:52', '2021-10-20 13:09:52'),
(105, 1, 'admin/auth/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:09:54', '2021-10-20 13:09:54'),
(106, 1, 'admin/auth/users/2/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:09:57', '2021-10-20 13:09:57'),
(107, 1, 'admin/auth/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:10:04', '2021-10-20 13:10:04'),
(108, 2, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 13:10:34', '2021-10-20 13:10:34'),
(109, 2, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:10:51', '2021-10-20 13:10:51'),
(110, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:11:01', '2021-10-20 13:11:01'),
(111, 1, 'admin/auth/roles/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:11:06', '2021-10-20 13:11:06'),
(112, 1, 'admin/auth/roles/3', 'PUT', '127.0.0.1', '{\"slug\":\"basic-user\",\"name\":\"Basic User\",\"permissions\":[\"3\",null],\"_token\":\"Gd34F9pnpWnNb7rTRcoB9sDURze5nXzvPQeDUeFU\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/roles\"}', '2021-10-20 13:11:12', '2021-10-20 13:11:12'),
(113, 1, 'admin/auth/roles/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-20 13:11:13', '2021-10-20 13:11:13'),
(114, 2, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:11:18', '2021-10-20 13:11:18'),
(115, 2, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 13:11:21', '2021-10-20 13:11:21'),
(116, 2, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:11:26', '2021-10-20 13:11:26'),
(117, 2, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 13:11:31', '2021-10-20 13:11:31'),
(118, 2, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:11:42', '2021-10-20 13:11:42'),
(119, 2, 'admin/media', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:11:45', '2021-10-20 13:11:45'),
(120, 2, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:11:46', '2021-10-20 13:11:46'),
(121, 2, 'admin/media', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:11:55', '2021-10-20 13:11:55'),
(122, 2, 'admin/media', 'GET', '127.0.0.1', '{\"path\":\"\\/Romina Files\",\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:11:58', '2021-10-20 13:11:58'),
(123, 2, 'admin/media', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:12:00', '2021-10-20 13:12:00'),
(124, 2, 'admin/media/download', 'GET', '127.0.0.1', '{\"file\":\"muhind mubaraka.jpeg\"}', '2021-10-20 13:12:03', '2021-10-20 13:12:03'),
(125, 2, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:12:17', '2021-10-20 13:12:17'),
(126, 1, 'admin/auth/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:12:38', '2021-10-20 13:12:38'),
(127, 1, 'admin/auth/users/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:12:44', '2021-10-20 13:12:44'),
(128, 1, 'admin/auth/users/1', 'PUT', '127.0.0.1', '{\"username\":\"super-admin\",\"name\":\"Administrator\",\"password\":\"4321\",\"password_confirmation\":\"4321\",\"roles\":[\"1\",null],\"permissions\":[null],\"_token\":\"Gd34F9pnpWnNb7rTRcoB9sDURze5nXzvPQeDUeFU\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/users\"}', '2021-10-20 13:14:55', '2021-10-20 13:14:55'),
(129, 1, 'admin/auth/users', 'GET', '127.0.0.1', '[]', '2021-10-20 13:14:56', '2021-10-20 13:14:56'),
(130, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:15:36', '2021-10-20 13:15:36'),
(131, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 13:16:08', '2021-10-20 13:16:08'),
(132, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 13:16:25', '2021-10-20 13:16:25'),
(133, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 13:16:47', '2021-10-20 13:16:47'),
(134, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 13:17:20', '2021-10-20 13:17:20'),
(135, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 13:17:34', '2021-10-20 13:17:34'),
(136, 2, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 13:17:42', '2021-10-20 13:17:42'),
(137, 2, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 13:17:46', '2021-10-20 13:17:46'),
(138, 2, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:17:58', '2021-10-20 13:17:58'),
(139, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 13:18:25', '2021-10-20 13:18:25'),
(140, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 13:18:30', '2021-10-20 13:18:30'),
(141, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:18:35', '2021-10-20 13:18:35'),
(142, 1, 'admin/auth/menu/8/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:18:47', '2021-10-20 13:18:47'),
(143, 1, 'admin/auth/menu/8', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Media manager\",\"icon\":\"fa-file\",\"uri\":\"media\",\"roles\":[\"1\",\"2\",null],\"permission\":null,\"_token\":\"Gd34F9pnpWnNb7rTRcoB9sDURze5nXzvPQeDUeFU\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/menu\"}', '2021-10-20 13:19:14', '2021-10-20 13:19:14'),
(144, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-20 13:19:14', '2021-10-20 13:19:14'),
(145, 2, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 13:19:19', '2021-10-20 13:19:19'),
(146, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:20:07', '2021-10-20 13:20:07'),
(147, 1, 'admin/auth/roles/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:20:11', '2021-10-20 13:20:11'),
(148, 1, 'admin/auth/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:20:38', '2021-10-20 13:20:38'),
(149, 1, 'admin/auth/users/2/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:20:42', '2021-10-20 13:20:42'),
(150, 1, 'admin/auth/users/2', 'PUT', '127.0.0.1', '{\"username\":\"admin\",\"name\":\"Muhindo Mubaraka\",\"password\":\"$2y$10$JnOG.x2fFxqp3g\\/sfxaQou7rr7QRrhhQxHF.JRgXyv6eAlecjtOiO\",\"password_confirmation\":\"$2y$10$JnOG.x2fFxqp3g\\/sfxaQou7rr7QRrhhQxHF.JRgXyv6eAlecjtOiO\",\"roles\":[\"2\",null],\"permissions\":[null],\"_token\":\"Gd34F9pnpWnNb7rTRcoB9sDURze5nXzvPQeDUeFU\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/users\"}', '2021-10-20 13:20:46', '2021-10-20 13:20:46'),
(151, 1, 'admin/auth/users', 'GET', '127.0.0.1', '[]', '2021-10-20 13:20:46', '2021-10-20 13:20:46'),
(152, 1, 'admin/auth/users/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:20:50', '2021-10-20 13:20:50'),
(153, 1, 'admin/auth/users', 'POST', '127.0.0.1', '{\"username\":\"basic-user\",\"name\":\"Betty Namagembe\",\"password\":\"4321\",\"password_confirmation\":\"4321\",\"roles\":[\"3\",null],\"permissions\":[null],\"_token\":\"Gd34F9pnpWnNb7rTRcoB9sDURze5nXzvPQeDUeFU\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/users\"}', '2021-10-20 13:21:47', '2021-10-20 13:21:47'),
(154, 1, 'admin/auth/users', 'GET', '127.0.0.1', '[]', '2021-10-20 13:21:48', '2021-10-20 13:21:48'),
(155, 2, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:22:09', '2021-10-20 13:22:09'),
(156, 3, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 13:22:21', '2021-10-20 13:22:21'),
(157, 3, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:22:30', '2021-10-20 13:22:30'),
(158, 1, 'admin/auth/users/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:22:47', '2021-10-20 13:22:47'),
(159, 1, 'admin/auth/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:22:50', '2021-10-20 13:22:50'),
(160, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:23:03', '2021-10-20 13:23:03'),
(161, 1, 'admin/auth/roles/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:23:12', '2021-10-20 13:23:12'),
(162, 1, 'admin/auth/roles/3', 'PUT', '127.0.0.1', '{\"slug\":\"basic-user\",\"name\":\"Basic User\",\"permissions\":[\"2\",\"3\",null],\"_token\":\"Gd34F9pnpWnNb7rTRcoB9sDURze5nXzvPQeDUeFU\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/roles\"}', '2021-10-20 13:24:06', '2021-10-20 13:24:06'),
(163, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '[]', '2021-10-20 13:24:06', '2021-10-20 13:24:06'),
(164, 3, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 13:24:13', '2021-10-20 13:24:13'),
(165, 3, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:24:35', '2021-10-20 13:24:35'),
(166, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:24:44', '2021-10-20 13:24:44'),
(167, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Application Forms\",\"icon\":\"fa-wpforms\",\"uri\":null,\"roles\":[\"3\",null],\"permission\":null,\"_token\":\"Gd34F9pnpWnNb7rTRcoB9sDURze5nXzvPQeDUeFU\"}', '2021-10-20 13:27:34', '2021-10-20 13:27:34'),
(168, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-20 13:27:34', '2021-10-20 13:27:34'),
(169, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"_token\":\"Gd34F9pnpWnNb7rTRcoB9sDURze5nXzvPQeDUeFU\",\"_order\":\"[{\\\"id\\\":1},{\\\"id\\\":9},{\\\"id\\\":2,\\\"children\\\":[{\\\"id\\\":3},{\\\"id\\\":4},{\\\"id\\\":5},{\\\"id\\\":6},{\\\"id\\\":7}]},{\\\"id\\\":8}]\"}', '2021-10-20 13:27:44', '2021-10-20 13:27:44'),
(170, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:27:44', '2021-10-20 13:27:44'),
(171, 3, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 13:27:48', '2021-10-20 13:27:48'),
(172, 3, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:28:11', '2021-10-20 13:28:11'),
(173, 3, 'admin/auth/setting', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:28:29', '2021-10-20 13:28:29'),
(174, 3, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:28:36', '2021-10-20 13:28:36'),
(175, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"My Profile\",\"icon\":\"fa-user-md\",\"uri\":null,\"roles\":[null],\"permission\":null,\"_token\":\"Gd34F9pnpWnNb7rTRcoB9sDURze5nXzvPQeDUeFU\"}', '2021-10-20 13:29:12', '2021-10-20 13:29:12'),
(176, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-20 13:29:13', '2021-10-20 13:29:13'),
(177, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"_token\":\"Gd34F9pnpWnNb7rTRcoB9sDURze5nXzvPQeDUeFU\",\"_order\":\"[{\\\"id\\\":1},{\\\"id\\\":9},{\\\"id\\\":2,\\\"children\\\":[{\\\"id\\\":3},{\\\"id\\\":4},{\\\"id\\\":5},{\\\"id\\\":6},{\\\"id\\\":7}]},{\\\"id\\\":10},{\\\"id\\\":8}]\"}', '2021-10-20 13:29:23', '2021-10-20 13:29:23'),
(178, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:29:24', '2021-10-20 13:29:24'),
(179, 3, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 13:29:29', '2021-10-20 13:29:29'),
(180, 3, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:29:32', '2021-10-20 13:29:32'),
(181, 3, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:29:34', '2021-10-20 13:29:34'),
(182, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"parent_id\":\"9\",\"title\":\"Seed Merchant Form - SR4\",\"icon\":\"fa-wpforms\",\"uri\":null,\"roles\":[null],\"permission\":null,\"_token\":\"Gd34F9pnpWnNb7rTRcoB9sDURze5nXzvPQeDUeFU\"}', '2021-10-20 13:32:18', '2021-10-20 13:32:18'),
(183, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-20 13:32:18', '2021-10-20 13:32:18'),
(184, 1, 'admin/auth/menu/11/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:32:24', '2021-10-20 13:32:24'),
(185, 1, 'admin/auth/menu/11', 'PUT', '127.0.0.1', '{\"parent_id\":\"9\",\"title\":\"SR4 - Seed Merchant Form\",\"icon\":\"fa-wpforms\",\"uri\":null,\"roles\":[null],\"permission\":null,\"_token\":\"Gd34F9pnpWnNb7rTRcoB9sDURze5nXzvPQeDUeFU\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/menu\"}', '2021-10-20 13:32:34', '2021-10-20 13:32:34'),
(186, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-20 13:32:34', '2021-10-20 13:32:34'),
(187, 3, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 13:32:41', '2021-10-20 13:32:41'),
(188, 1, 'admin/auth/menu/11/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:32:56', '2021-10-20 13:32:56'),
(189, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:33:00', '2021-10-20 13:33:00'),
(190, 1, 'admin/auth/menu/11/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:33:06', '2021-10-20 13:33:06'),
(191, 3, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:33:28', '2021-10-20 13:33:28'),
(192, 3, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 13:34:27', '2021-10-20 13:34:27'),
(193, 3, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:34:33', '2021-10-20 13:34:33'),
(194, 1, 'admin/auth/menu/11', 'PUT', '127.0.0.1', '{\"parent_id\":\"9\",\"title\":\"SR4 - Seed Merchant Form\",\"icon\":null,\"uri\":null,\"roles\":[null],\"permission\":null,\"_token\":\"Gd34F9pnpWnNb7rTRcoB9sDURze5nXzvPQeDUeFU\",\"_method\":\"PUT\"}', '2021-10-20 13:34:46', '2021-10-20 13:34:46'),
(195, 1, 'admin/auth/menu/11/edit', 'GET', '127.0.0.1', '[]', '2021-10-20 13:34:47', '2021-10-20 13:34:47'),
(196, 3, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 13:34:51', '2021-10-20 13:34:51'),
(197, 3, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 13:35:16', '2021-10-20 13:35:16'),
(198, 3, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 16:12:00', '2021-10-20 16:12:00'),
(199, 3, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 16:12:04', '2021-10-20 16:12:04'),
(200, 3, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 16:12:16', '2021-10-20 16:12:16'),
(201, 3, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 16:13:31', '2021-10-20 16:13:31'),
(202, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 16:13:51', '2021-10-20 16:13:51'),
(203, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-20 16:13:57', '2021-10-20 16:13:57'),
(204, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-20 16:15:17', '2021-10-20 16:15:17'),
(205, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-20 17:15:02', '2021-10-20 17:15:02'),
(206, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-20 17:15:09', '2021-10-20 17:15:09'),
(207, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:15:20', '2021-10-20 17:15:20'),
(208, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:16:30', '2021-10-20 17:16:30'),
(209, 1, 'admin/auth/menu/11/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:16:49', '2021-10-20 17:16:49'),
(210, 1, 'admin/auth/menu/11', 'PUT', '127.0.0.1', '{\"parent_id\":\"9\",\"title\":\"SR4 - Seed Merchant Form\",\"icon\":\"fa-wpforms\",\"uri\":\"form-sr4s\\/create\",\"roles\":[null],\"permission\":null,\"_token\":\"Xn6JBnXEWr8B07DMaW55SvDANGwDUgRd2JrDe6Tf\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/menu\"}', '2021-10-20 17:16:58', '2021-10-20 17:16:58'),
(211, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-20 17:16:58', '2021-10-20 17:16:58'),
(212, 3, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 17:17:02', '2021-10-20 17:17:02'),
(213, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:17:07', '2021-10-20 17:17:07'),
(214, 1, 'admin/auth/menu/11/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:17:18', '2021-10-20 17:17:18'),
(215, 1, 'admin/auth/menu/11', 'PUT', '127.0.0.1', '{\"parent_id\":\"9\",\"title\":\"SR4 - Seed Merchant Form\",\"icon\":\"fa-wpforms\",\"uri\":\"form-sr4s\\/create\",\"roles\":[\"3\",null],\"permission\":null,\"_token\":\"Xn6JBnXEWr8B07DMaW55SvDANGwDUgRd2JrDe6Tf\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/menu\"}', '2021-10-20 17:17:39', '2021-10-20 17:17:39'),
(216, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-20 17:17:39', '2021-10-20 17:17:39'),
(217, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-20 17:17:43', '2021-10-20 17:17:43'),
(218, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:17:47', '2021-10-20 17:17:47'),
(219, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-20 17:17:49', '2021-10-20 17:17:49'),
(220, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:17:52', '2021-10-20 17:17:52'),
(221, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-20 17:17:58', '2021-10-20 17:17:58'),
(222, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-20 17:18:07', '2021-10-20 17:18:07'),
(223, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:18:14', '2021-10-20 17:18:14'),
(224, 1, 'admin/auth/users', 'GET', '127.0.0.1', '[]', '2021-10-20 17:18:28', '2021-10-20 17:18:28'),
(225, 1, 'admin/auth/users/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:18:35', '2021-10-20 17:18:35'),
(226, 1, 'admin/auth/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:18:39', '2021-10-20 17:18:39'),
(227, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:18:45', '2021-10-20 17:18:45'),
(228, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:18:47', '2021-10-20 17:18:47'),
(229, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:19:20', '2021-10-20 17:19:20'),
(230, 1, 'admin/auth/menu/11/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:19:24', '2021-10-20 17:19:24'),
(231, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:19:44', '2021-10-20 17:19:44'),
(232, 1, 'admin/auth/permissions', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:19:45', '2021-10-20 17:19:45'),
(233, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:19:46', '2021-10-20 17:19:46'),
(234, 1, 'admin/auth/menu/9/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:19:55', '2021-10-20 17:19:55'),
(235, 1, 'admin/auth/menu/9', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Application Forms\",\"icon\":\"fa-wpforms\",\"uri\":\"form-sr4s\\/create\",\"roles\":[\"3\",null],\"permission\":null,\"_token\":\"Xn6JBnXEWr8B07DMaW55SvDANGwDUgRd2JrDe6Tf\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/menu\"}', '2021-10-20 17:20:23', '2021-10-20 17:20:23'),
(236, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-20 17:20:23', '2021-10-20 17:20:23'),
(237, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-20 17:20:27', '2021-10-20 17:20:27'),
(238, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:20:30', '2021-10-20 17:20:30'),
(239, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:20:35', '2021-10-20 17:20:35'),
(240, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:20:41', '2021-10-20 17:20:41'),
(241, 3, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:20:47', '2021-10-20 17:20:47'),
(242, 3, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:20:51', '2021-10-20 17:20:51'),
(243, 3, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 17:20:56', '2021-10-20 17:20:56'),
(244, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:21:02', '2021-10-20 17:21:02'),
(245, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-20 17:21:13', '2021-10-20 17:21:13'),
(246, 3, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:21:17', '2021-10-20 17:21:17'),
(247, 3, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 17:21:19', '2021-10-20 17:21:19'),
(248, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:21:22', '2021-10-20 17:21:22'),
(249, 1, 'admin/auth/menu/11', 'DELETE', '127.0.0.1', '{\"_method\":\"delete\",\"_token\":\"Xn6JBnXEWr8B07DMaW55SvDANGwDUgRd2JrDe6Tf\"}', '2021-10-20 17:21:31', '2021-10-20 17:21:31'),
(250, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:21:32', '2021-10-20 17:21:32'),
(251, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-20 17:21:39', '2021-10-20 17:21:39'),
(252, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:21:41', '2021-10-20 17:21:41'),
(253, 1, 'admin/auth/menu/9/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:21:55', '2021-10-20 17:21:55'),
(254, 1, 'admin/auth/menu/9', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Application Forms\",\"icon\":\"fa-wpforms\",\"uri\":\"form-sr4s\\/create\",\"roles\":[\"3\",null],\"permission\":\"*\",\"_token\":\"Xn6JBnXEWr8B07DMaW55SvDANGwDUgRd2JrDe6Tf\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/menu\"}', '2021-10-20 17:22:02', '2021-10-20 17:22:02'),
(255, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-20 17:22:02', '2021-10-20 17:22:02'),
(256, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-20 17:22:06', '2021-10-20 17:22:06'),
(257, 3, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:22:12', '2021-10-20 17:22:12'),
(258, 1, 'admin/auth/menu/9/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:22:17', '2021-10-20 17:22:17'),
(259, 1, 'admin/auth/menu/9', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Application Forms\",\"icon\":\"fa-wpforms\",\"uri\":\"form-sr4s\\/create\",\"roles\":[\"3\",null],\"permission\":\"auth.login\",\"_token\":\"Xn6JBnXEWr8B07DMaW55SvDANGwDUgRd2JrDe6Tf\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/menu\"}', '2021-10-20 17:22:30', '2021-10-20 17:22:30'),
(260, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-20 17:22:30', '2021-10-20 17:22:30'),
(261, 3, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 17:22:33', '2021-10-20 17:22:33'),
(262, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:22:35', '2021-10-20 17:22:35'),
(263, 1, 'admin/auth/menu/9/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:22:44', '2021-10-20 17:22:44'),
(264, 1, 'admin/auth/menu/9', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Application Forms\",\"icon\":\"fa-wpforms\",\"uri\":\"form-sr4s\\/create\",\"roles\":[null],\"permission\":\"auth.login\",\"_token\":\"Xn6JBnXEWr8B07DMaW55SvDANGwDUgRd2JrDe6Tf\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/menu\"}', '2021-10-20 17:22:54', '2021-10-20 17:22:54'),
(265, 1, 'admin/auth/menu/9/edit', 'GET', '127.0.0.1', '[]', '2021-10-20 17:22:54', '2021-10-20 17:22:54'),
(266, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-20 17:22:59', '2021-10-20 17:22:59'),
(267, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:23:02', '2021-10-20 17:23:02'),
(268, 1, 'admin/auth/menu/9', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Application Forms\",\"icon\":\"fa-wpforms\",\"uri\":\"form-sr4s\",\"roles\":[null],\"permission\":\"auth.login\",\"_token\":\"Xn6JBnXEWr8B07DMaW55SvDANGwDUgRd2JrDe6Tf\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-20 17:23:31', '2021-10-20 17:23:31'),
(269, 1, 'admin/auth/menu/9/edit', 'GET', '127.0.0.1', '[]', '2021-10-20 17:23:32', '2021-10-20 17:23:32'),
(270, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-20 17:23:33', '2021-10-20 17:23:33'),
(271, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:23:36', '2021-10-20 17:23:36'),
(272, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:23:38', '2021-10-20 17:23:38'),
(273, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:23:39', '2021-10-20 17:23:39'),
(274, 3, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:23:46', '2021-10-20 17:23:46'),
(275, 2, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 17:23:56', '2021-10-20 17:23:56'),
(276, 2, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:24:03', '2021-10-20 17:24:03'),
(277, 1, 'admin/auth/menu/9', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Application Forms\",\"icon\":\"fa-wpforms\",\"uri\":\"form-sr4s\\/create\",\"roles\":[null],\"permission\":\"auth.login\",\"_token\":\"Xn6JBnXEWr8B07DMaW55SvDANGwDUgRd2JrDe6Tf\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-20 17:24:22', '2021-10-20 17:24:22'),
(278, 1, 'admin/auth/menu/9/edit', 'GET', '127.0.0.1', '[]', '2021-10-20 17:24:22', '2021-10-20 17:24:22'),
(279, 2, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-20 17:24:25', '2021-10-20 17:24:25'),
(280, 2, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:24:28', '2021-10-20 17:24:28'),
(281, 2, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:24:37', '2021-10-20 17:24:37'),
(282, 3, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-20 17:24:45', '2021-10-20 17:24:45'),
(283, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:24:48', '2021-10-20 17:24:48'),
(284, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:24:52', '2021-10-20 17:24:52'),
(285, 1, 'admin/auth/roles/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:24:58', '2021-10-20 17:24:58'),
(286, 1, 'admin/auth/roles/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-20 17:25:13', '2021-10-20 17:25:13'),
(287, 1, 'admin/auth/roles/3', 'PUT', '127.0.0.1', '{\"slug\":\"basic-user\",\"name\":\"Basic User\",\"permissions\":[\"1\",\"2\",\"3\",null],\"_token\":\"Xn6JBnXEWr8B07DMaW55SvDANGwDUgRd2JrDe6Tf\",\"_method\":\"PUT\"}', '2021-10-20 17:25:26', '2021-10-20 17:25:26'),
(288, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '[]', '2021-10-20 17:25:26', '2021-10-20 17:25:26'),
(289, 1, 'admin/auth/roles/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:25:29', '2021-10-20 17:25:29'),
(290, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-20 17:25:32', '2021-10-20 17:25:32'),
(291, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:25:37', '2021-10-20 17:25:37'),
(292, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:25:47', '2021-10-20 17:25:47'),
(293, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:25:53', '2021-10-20 17:25:53'),
(294, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:26:10', '2021-10-20 17:26:10'),
(295, 1, 'admin/auth/menu/9/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:26:20', '2021-10-20 17:26:20'),
(296, 1, 'admin/auth/menu/9', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Application Forms\",\"icon\":\"fa-wpforms\",\"uri\":\"form-sr4s\\/create\",\"roles\":[\"1\",null],\"permission\":\"auth.login\",\"_token\":\"Xn6JBnXEWr8B07DMaW55SvDANGwDUgRd2JrDe6Tf\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/menu\"}', '2021-10-20 17:26:28', '2021-10-20 17:26:28'),
(297, 1, 'admin/auth/menu/9/edit', 'GET', '127.0.0.1', '[]', '2021-10-20 17:26:29', '2021-10-20 17:26:29'),
(298, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-20 17:26:31', '2021-10-20 17:26:31'),
(299, 1, 'admin/auth/menu/9', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Application Forms\",\"icon\":\"fa-wpforms\",\"uri\":\"form-sr4s\\/create\",\"roles\":[\"3\",null],\"permission\":\"*\",\"_token\":\"Xn6JBnXEWr8B07DMaW55SvDANGwDUgRd2JrDe6Tf\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-20 17:26:57', '2021-10-20 17:26:57'),
(300, 1, 'admin/auth/menu/9/edit', 'GET', '127.0.0.1', '[]', '2021-10-20 17:26:58', '2021-10-20 17:26:58'),
(301, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-20 17:27:01', '2021-10-20 17:27:01'),
(302, 1, 'admin/auth/menu/9/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:27:25', '2021-10-20 17:27:25'),
(303, 1, 'admin/auth/menu/9/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:27:29', '2021-10-20 17:27:29'),
(304, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:27:30', '2021-10-20 17:27:30'),
(305, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-20 17:27:33', '2021-10-20 17:27:33'),
(306, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:27:38', '2021-10-20 17:27:38'),
(307, 1, 'admin/auth/roles/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:27:42', '2021-10-20 17:27:42'),
(308, 1, 'admin/auth/roles/3', 'PUT', '127.0.0.1', '{\"slug\":\"basic-user\",\"name\":\"Basic User\",\"permissions\":[\"3\",\"2\",\"3\",null],\"_token\":\"Xn6JBnXEWr8B07DMaW55SvDANGwDUgRd2JrDe6Tf\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/roles\"}', '2021-10-20 17:28:18', '2021-10-20 17:28:18'),
(309, 1, 'admin/auth/roles/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-20 17:28:19', '2021-10-20 17:28:19'),
(310, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-20 17:28:21', '2021-10-20 17:28:21'),
(311, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-20 17:28:22', '2021-10-20 17:28:22'),
(312, 1, 'admin/auth/roles/3', 'PUT', '127.0.0.1', '{\"slug\":\"basic-user\",\"name\":\"Basic User\",\"permissions\":[\"1\",\"1\",\"2\",\"3\",null],\"_token\":\"Xn6JBnXEWr8B07DMaW55SvDANGwDUgRd2JrDe6Tf\",\"_method\":\"PUT\"}', '2021-10-20 17:28:50', '2021-10-20 17:28:50'),
(313, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '[]', '2021-10-20 17:28:50', '2021-10-20 17:28:50'),
(314, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-20 17:29:01', '2021-10-20 17:29:01'),
(315, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-20 17:30:06', '2021-10-20 17:30:06'),
(316, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:41:05', '2021-10-20 17:41:05'),
(317, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Forms\",\"icon\":\"fa-bars\",\"uri\":null,\"roles\":[\"1\",null],\"permission\":null,\"_token\":\"Xn6JBnXEWr8B07DMaW55SvDANGwDUgRd2JrDe6Tf\"}', '2021-10-20 17:41:28', '2021-10-20 17:41:28'),
(318, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-20 17:41:29', '2021-10-20 17:41:29'),
(319, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"parent_id\":\"12\",\"title\":\"form-sr4s\",\"icon\":\"fa-wpforms\",\"uri\":\"SR4\",\"roles\":[null],\"permission\":null,\"_token\":\"Xn6JBnXEWr8B07DMaW55SvDANGwDUgRd2JrDe6Tf\"}', '2021-10-20 17:42:02', '2021-10-20 17:42:02'),
(320, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-20 17:42:02', '2021-10-20 17:42:02'),
(321, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-20 17:42:12', '2021-10-20 17:42:12'),
(322, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-20 17:42:22', '2021-10-20 17:42:22'),
(323, 1, 'admin/auth/menu/13/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:42:40', '2021-10-20 17:42:40'),
(324, 1, 'admin/auth/menu/13', 'PUT', '127.0.0.1', '{\"parent_id\":\"12\",\"title\":\"SR4s\",\"icon\":\"fa-wpforms\",\"uri\":\"form-sr4s\",\"roles\":[null],\"permission\":null,\"_token\":\"Xn6JBnXEWr8B07DMaW55SvDANGwDUgRd2JrDe6Tf\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/menu\"}', '2021-10-20 17:42:53', '2021-10-20 17:42:53'),
(325, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-20 17:42:54', '2021-10-20 17:42:54'),
(326, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-20 17:43:02', '2021-10-20 17:43:02'),
(327, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:43:07', '2021-10-20 17:43:07'),
(328, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:43:13', '2021-10-20 17:43:13'),
(329, 1, 'admin/form-sr4s', 'POST', '127.0.0.1', '{\"administrator_id\":\"1\",\"name_of_applicant\":\"Muhindo Mubaraka\",\"address\":\"Kibuli, Kampala, Uganda\",\"company_initials\":\"IUT\",\"premises_location\":null,\"years_of_expirience\":null,\"expirience_in\":null,\"dealers_in\":null,\"processing_of\":null,\"marketing_of\":null,\"have_adequate_land\":\"off\",\"land_size\":\"0\",\"eqipment\":null,\"have_adequate_equipment\":\"off\",\"have_contractual_agreement\":\"off\",\"have_adequate_field_officers\":\"off\",\"have_conversant_seed_matters\":\"off\",\"souce_of_seed\":null,\"have_adequate_land_for_production\":\"off\",\"have_internal_quality_program\":\"off\",\"receipt\":null,\"accept_declaration\":\"off\",\"valid_from\":\"2021-10-20 20:43:13\",\"valid_until\":\"2021-10-20 20:43:13\",\"status\":null,\"status_comment\":null,\"inspector\":null,\"_token\":\"Xn6JBnXEWr8B07DMaW55SvDANGwDUgRd2JrDe6Tf\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr4s\"}', '2021-10-20 17:43:23', '2021-10-20 17:43:23'),
(330, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-20 17:43:23', '2021-10-20 17:43:23'),
(331, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 17:43:31', '2021-10-20 17:43:31'),
(332, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-20 17:51:02', '2021-10-20 17:51:02'),
(333, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 23:15:10', '2021-10-20 23:15:10'),
(334, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-20 23:15:51', '2021-10-20 23:15:51'),
(335, 1, 'admin/form-sr4s/1', 'PUT', '127.0.0.1', '{\"name\":\"address\",\"value\":\"Kibuli, Kampala,Uganda\",\"pk\":\"1\",\"_token\":\"kYdElwPB8b6IQTNb5B2Q5BJmDZ9m2cnjoVJmA3Hi\",\"_editable\":\"1\",\"_method\":\"PUT\"}', '2021-10-20 23:16:04', '2021-10-20 23:16:04'),
(336, 1, 'admin/form-sr4s/1', 'PUT', '127.0.0.1', '{\"name\":\"address\",\"value\":\"Kibuli, Kampala, Uganda.\",\"pk\":\"1\",\"_token\":\"kYdElwPB8b6IQTNb5B2Q5BJmDZ9m2cnjoVJmA3Hi\",\"_editable\":\"1\",\"_method\":\"PUT\"}', '2021-10-20 23:16:14', '2021-10-20 23:16:14'),
(337, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-20 23:16:56', '2021-10-20 23:16:56'),
(338, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-20 23:17:34', '2021-10-20 23:17:34'),
(339, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-20 23:18:00', '2021-10-20 23:18:00'),
(340, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-20 23:19:00', '2021-10-20 23:19:00'),
(341, 1, 'admin/form-sr4s/1', 'PUT', '127.0.0.1', '{\"name\":\"have_adequate_equipment\",\"value\":\"2\",\"pk\":\"1\",\"_token\":\"kYdElwPB8b6IQTNb5B2Q5BJmDZ9m2cnjoVJmA3Hi\",\"_editable\":\"1\",\"_method\":\"PUT\"}', '2021-10-20 23:19:10', '2021-10-20 23:19:10'),
(342, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 23:25:50', '2021-10-20 23:25:50'),
(343, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-20 23:26:43', '2021-10-20 23:26:43'),
(344, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-20 23:28:38', '2021-10-20 23:28:38'),
(345, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-20 23:28:50', '2021-10-20 23:28:50'),
(346, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 23:28:54', '2021-10-20 23:28:54'),
(347, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 23:28:59', '2021-10-20 23:28:59'),
(348, 1, 'admin/form-sr4s/1', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 23:29:10', '2021-10-20 23:29:10'),
(349, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 23:29:12', '2021-10-20 23:29:12'),
(350, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-20 23:42:42', '2021-10-20 23:42:42'),
(351, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-20 23:42:55', '2021-10-20 23:42:55');
INSERT INTO `admin_operation_log` (`id`, `user_id`, `path`, `method`, `ip`, `input`, `created_at`, `updated_at`) VALUES
(352, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 23:47:58', '2021-10-20 23:47:58'),
(353, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 23:48:00', '2021-10-20 23:48:00'),
(354, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 23:51:47', '2021-10-20 23:51:47'),
(355, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 23:51:51', '2021-10-20 23:51:51'),
(356, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 23:51:55', '2021-10-20 23:51:55'),
(357, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-20 23:52:01', '2021-10-20 23:52:01'),
(358, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-20 23:54:40', '2021-10-20 23:54:40'),
(359, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 00:04:38', '2021-10-21 00:04:38'),
(360, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 00:06:14', '2021-10-21 00:06:14'),
(361, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 00:07:47', '2021-10-21 00:07:47'),
(362, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 00:08:05', '2021-10-21 00:08:05'),
(363, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 00:09:53', '2021-10-21 00:09:53'),
(364, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 00:11:22', '2021-10-21 00:11:22'),
(365, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 00:12:19', '2021-10-21 00:12:19'),
(366, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 00:15:56', '2021-10-21 00:15:56'),
(367, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 00:16:34', '2021-10-21 00:16:34'),
(368, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 00:17:30', '2021-10-21 00:17:30'),
(369, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 00:18:36', '2021-10-21 00:18:36'),
(370, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 00:20:50', '2021-10-21 00:20:50'),
(371, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 00:21:23', '2021-10-21 00:21:23'),
(372, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 00:21:37', '2021-10-21 00:21:37'),
(373, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 00:23:31', '2021-10-21 00:23:31'),
(374, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 00:25:31', '2021-10-21 00:25:31'),
(375, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 00:28:59', '2021-10-21 00:28:59'),
(376, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 00:29:36', '2021-10-21 00:29:36'),
(377, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 00:29:49', '2021-10-21 00:29:49'),
(378, 1, 'admin/form-sr4s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"1\",\"name_of_applicant\":\"Muhindo Mubaraka\",\"address\":\"Kibuli, Kampala, Uganda.\",\"company_initials\":\"IUT\",\"premises_location\":null,\"expirience_in\":\"1\",\"years_of_expirience\":\"0\",\"dealers_in\":null,\"processing_of\":null,\"marketing_of\":null,\"have_adequate_land\":\"off\",\"land_size\":\"0\",\"eqipment\":null,\"have_adequate_equipment\":\"2\",\"have_contractual_agreement\":\"off\",\"have_adequate_field_officers\":\"off\",\"have_conversant_seed_matters\":\"off\",\"souce_of_seed\":null,\"have_adequate_land_for_production\":\"off\",\"have_internal_quality_program\":\"off\",\"receipt\":null,\"accept_declaration\":\"off\",\"valid_from\":\"2021-10-20 20:43:13\",\"valid_until\":\"2021-10-20 20:43:13\",\"status\":null,\"status_comment\":null,\"inspector\":null,\"_token\":\"kYdElwPB8b6IQTNb5B2Q5BJmDZ9m2cnjoVJmA3Hi\",\"_method\":\"PUT\"}', '2021-10-21 00:30:03', '2021-10-21 00:30:03'),
(379, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 00:30:03', '2021-10-21 00:30:03'),
(380, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 00:30:31', '2021-10-21 00:30:31'),
(381, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 00:33:10', '2021-10-21 00:33:10'),
(382, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 00:37:15', '2021-10-21 00:37:15'),
(383, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 01:57:56', '2021-10-21 01:57:56'),
(384, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 01:58:46', '2021-10-21 01:58:46'),
(385, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 01:59:06', '2021-10-21 01:59:06'),
(386, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 01:59:19', '2021-10-21 01:59:19'),
(387, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 01:59:35', '2021-10-21 01:59:35'),
(388, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 02:00:00', '2021-10-21 02:00:00'),
(389, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 02:00:30', '2021-10-21 02:00:30'),
(390, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 02:00:48', '2021-10-21 02:00:48'),
(391, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 02:01:13', '2021-10-21 02:01:13'),
(392, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 02:01:46', '2021-10-21 02:01:46'),
(393, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 02:01:58', '2021-10-21 02:01:58'),
(394, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 02:02:10', '2021-10-21 02:02:10'),
(395, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 02:02:24', '2021-10-21 02:02:24'),
(396, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 02:02:34', '2021-10-21 02:02:34'),
(397, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 02:08:24', '2021-10-21 02:08:24'),
(398, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 02:08:39', '2021-10-21 02:08:39'),
(399, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 02:11:54', '2021-10-21 02:11:54'),
(400, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 02:12:31', '2021-10-21 02:12:31'),
(401, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 02:13:22', '2021-10-21 02:13:22'),
(402, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 02:14:02', '2021-10-21 02:14:02'),
(403, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 02:18:41', '2021-10-21 02:18:41'),
(404, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 02:22:32', '2021-10-21 02:22:32'),
(405, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 02:23:30', '2021-10-21 02:23:30'),
(406, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 02:25:39', '2021-10-21 02:25:39'),
(407, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 02:26:15', '2021-10-21 02:26:15'),
(408, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 02:26:44', '2021-10-21 02:26:44'),
(409, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 02:27:20', '2021-10-21 02:27:20'),
(410, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 02:28:30', '2021-10-21 02:28:30'),
(411, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 02:29:06', '2021-10-21 02:29:06'),
(412, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 02:31:55', '2021-10-21 02:31:55'),
(413, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 02:33:27', '2021-10-21 02:33:27'),
(414, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 02:33:52', '2021-10-21 02:33:52'),
(415, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 02:34:39', '2021-10-21 02:34:39'),
(416, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 02:35:37', '2021-10-21 02:35:37'),
(417, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:20:38', '2021-10-21 05:20:38'),
(418, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:20:53', '2021-10-21 05:20:53'),
(419, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:31:37', '2021-10-21 05:31:37'),
(420, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:31:56', '2021-10-21 05:31:56'),
(421, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:32:34', '2021-10-21 05:32:34'),
(422, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:32:52', '2021-10-21 05:32:52'),
(423, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:35:07', '2021-10-21 05:35:07'),
(424, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:35:24', '2021-10-21 05:35:24'),
(425, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:35:47', '2021-10-21 05:35:47'),
(426, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:36:22', '2021-10-21 05:36:22'),
(427, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:36:41', '2021-10-21 05:36:41'),
(428, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:37:00', '2021-10-21 05:37:00'),
(429, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:37:33', '2021-10-21 05:37:33'),
(430, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:37:41', '2021-10-21 05:37:41'),
(431, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:37:57', '2021-10-21 05:37:57'),
(432, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:38:03', '2021-10-21 05:38:03'),
(433, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:38:08', '2021-10-21 05:38:08'),
(434, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:39:53', '2021-10-21 05:39:53'),
(435, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:40:35', '2021-10-21 05:40:35'),
(436, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:41:44', '2021-10-21 05:41:44'),
(437, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:43:21', '2021-10-21 05:43:21'),
(438, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:43:43', '2021-10-21 05:43:43'),
(439, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:47:49', '2021-10-21 05:47:49'),
(440, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:48:23', '2021-10-21 05:48:23'),
(441, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:48:49', '2021-10-21 05:48:49'),
(442, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:48:57', '2021-10-21 05:48:57'),
(443, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:49:39', '2021-10-21 05:49:39'),
(444, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:49:52', '2021-10-21 05:49:52'),
(445, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:50:26', '2021-10-21 05:50:26'),
(446, 1, 'admin/form-sr4s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 05:50:52', '2021-10-21 05:50:52'),
(447, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 05:51:04', '2021-10-21 05:51:04'),
(448, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 05:51:07', '2021-10-21 05:51:07'),
(449, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 05:51:52', '2021-10-21 05:51:52'),
(450, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 05:56:15', '2021-10-21 05:56:15'),
(451, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 05:57:47', '2021-10-21 05:57:47'),
(452, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:02:27', '2021-10-21 06:02:27'),
(453, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:02:45', '2021-10-21 06:02:45'),
(454, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:04:53', '2021-10-21 06:04:53'),
(455, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:09:49', '2021-10-21 06:09:49'),
(456, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:13:32', '2021-10-21 06:13:32'),
(457, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:14:05', '2021-10-21 06:14:05'),
(458, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:14:47', '2021-10-21 06:14:47'),
(459, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:15:20', '2021-10-21 06:15:20'),
(460, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:18:22', '2021-10-21 06:18:22'),
(461, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:23:05', '2021-10-21 06:23:05'),
(462, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:24:24', '2021-10-21 06:24:24'),
(463, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:24:46', '2021-10-21 06:24:46'),
(464, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:27:11', '2021-10-21 06:27:11'),
(465, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:32:29', '2021-10-21 06:32:29'),
(466, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:43:28', '2021-10-21 06:43:28'),
(467, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:43:47', '2021-10-21 06:43:47'),
(468, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:44:08', '2021-10-21 06:44:08'),
(469, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:45:22', '2021-10-21 06:45:22'),
(470, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:45:44', '2021-10-21 06:45:44'),
(471, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:46:02', '2021-10-21 06:46:02'),
(472, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:46:47', '2021-10-21 06:46:47'),
(473, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:47:29', '2021-10-21 06:47:29'),
(474, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:51:23', '2021-10-21 06:51:23'),
(475, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:51:30', '2021-10-21 06:51:30'),
(476, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:56:19', '2021-10-21 06:56:19'),
(477, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:57:39', '2021-10-21 06:57:39'),
(478, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:58:16', '2021-10-21 06:58:16'),
(479, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:59:10', '2021-10-21 06:59:10'),
(480, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 06:59:26', '2021-10-21 06:59:26'),
(481, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 07:00:21', '2021-10-21 07:00:21'),
(482, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 07:00:32', '2021-10-21 07:00:32'),
(483, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 07:02:33', '2021-10-21 07:02:33'),
(484, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 07:03:41', '2021-10-21 07:03:41'),
(485, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 07:04:15', '2021-10-21 07:04:15'),
(486, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 07:05:42', '2021-10-21 07:05:42'),
(487, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 07:06:18', '2021-10-21 07:06:18'),
(488, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 07:07:05', '2021-10-21 07:07:05'),
(489, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:07:20', '2021-10-21 07:07:20'),
(490, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:07:22', '2021-10-21 07:07:22'),
(491, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 07:08:58', '2021-10-21 07:08:58'),
(492, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 07:29:00', '2021-10-21 07:29:00'),
(493, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 07:31:49', '2021-10-21 07:31:49'),
(494, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:31:53', '2021-10-21 07:31:53'),
(495, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 07:34:28', '2021-10-21 07:34:28'),
(496, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:35:43', '2021-10-21 07:35:43'),
(497, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:36:11', '2021-10-21 07:36:11'),
(498, 1, 'admin/auth/menu/13/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:36:16', '2021-10-21 07:36:16'),
(499, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:36:22', '2021-10-21 07:36:22'),
(500, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:36:34', '2021-10-21 07:36:34'),
(501, 1, 'admin/auth/menu/9/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:36:44', '2021-10-21 07:36:44'),
(502, 1, 'admin/auth/menu/9', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Application Forms\",\"icon\":\"fa-wpforms\",\"uri\":\"form-sr4s\\/create\",\"roles\":[null],\"permission\":\"*\",\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/menu\"}', '2021-10-21 07:37:27', '2021-10-21 07:37:27'),
(503, 1, 'admin/auth/menu/9/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 07:37:28', '2021-10-21 07:37:28'),
(504, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 07:37:33', '2021-10-21 07:37:33'),
(505, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:37:36', '2021-10-21 07:37:36'),
(506, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:37:51', '2021-10-21 07:37:51'),
(507, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"parent_id\":\"9\",\"title\":\"SR4 - Seed Merchant Form\",\"icon\":\"fa-wpforms\",\"uri\":\"form-sr4s\",\"roles\":[null],\"permission\":null,\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\"}', '2021-10-21 07:39:47', '2021-10-21 07:39:47'),
(508, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-21 07:39:47', '2021-10-21 07:39:47'),
(509, 1, 'admin/auth/menu/12/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:39:57', '2021-10-21 07:39:57'),
(510, 1, 'admin/auth/menu/12', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"ApplicationForms\",\"icon\":\"fa-bars\",\"uri\":null,\"roles\":[null],\"permission\":null,\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/menu\"}', '2021-10-21 07:40:15', '2021-10-21 07:40:15'),
(511, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-21 07:40:16', '2021-10-21 07:40:16'),
(512, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 07:40:19', '2021-10-21 07:40:19'),
(513, 1, 'admin/auth/menu/12/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:40:53', '2021-10-21 07:40:53'),
(514, 1, 'admin/auth/menu/12', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Application Forms\",\"icon\":\"fa-wpforms\",\"uri\":null,\"roles\":[null],\"permission\":null,\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/menu\"}', '2021-10-21 07:41:23', '2021-10-21 07:41:23'),
(515, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-21 07:41:23', '2021-10-21 07:41:23'),
(516, 1, 'admin/auth/menu/9', 'DELETE', '127.0.0.1', '{\"_method\":\"delete\",\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\"}', '2021-10-21 07:41:34', '2021-10-21 07:41:34'),
(517, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:41:35', '2021-10-21 07:41:35'),
(518, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"_order\":\"[{\\\"id\\\":12,\\\"children\\\":[{\\\"id\\\":13}]},{\\\"id\\\":1},{\\\"id\\\":2,\\\"children\\\":[{\\\"id\\\":3},{\\\"id\\\":4},{\\\"id\\\":5},{\\\"id\\\":6},{\\\"id\\\":7}]},{\\\"id\\\":10},{\\\"id\\\":8}]\"}', '2021-10-21 07:41:45', '2021-10-21 07:41:45'),
(519, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:41:45', '2021-10-21 07:41:45'),
(520, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:41:46', '2021-10-21 07:41:46'),
(521, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 07:41:50', '2021-10-21 07:41:50'),
(522, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"_order\":\"[{\\\"id\\\":1},{\\\"id\\\":12,\\\"children\\\":[{\\\"id\\\":13}]},{\\\"id\\\":2,\\\"children\\\":[{\\\"id\\\":3},{\\\"id\\\":4},{\\\"id\\\":5},{\\\"id\\\":6},{\\\"id\\\":7}]},{\\\"id\\\":10},{\\\"id\\\":8}]\"}', '2021-10-21 07:42:08', '2021-10-21 07:42:08'),
(523, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:42:08', '2021-10-21 07:42:08'),
(524, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 07:42:10', '2021-10-21 07:42:10'),
(525, 1, 'admin/auth/menu/13/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:42:20', '2021-10-21 07:42:20'),
(526, 1, 'admin/auth/menu/13', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:43:03', '2021-10-21 07:43:03'),
(527, 1, 'admin/auth/menu/13/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 07:43:04', '2021-10-21 07:43:04'),
(528, 1, 'admin/auth/menu/13/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:43:08', '2021-10-21 07:43:08'),
(529, 1, 'admin/auth/menu/13', 'PUT', '127.0.0.1', '{\"parent_id\":\"12\",\"title\":\"SR4 - Seed Merchant\",\"icon\":\"fa-wpforms\",\"uri\":\"form-sr4s\",\"roles\":[null],\"permission\":null,\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"_method\":\"PUT\"}', '2021-10-21 07:43:30', '2021-10-21 07:43:30'),
(530, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-21 07:43:31', '2021-10-21 07:43:31'),
(531, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 07:43:35', '2021-10-21 07:43:35'),
(532, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 07:43:36', '2021-10-21 07:43:36'),
(533, 1, 'admin/auth/menu/13/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:43:49', '2021-10-21 07:43:49'),
(534, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 07:45:19', '2021-10-21 07:45:19'),
(535, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:45:44', '2021-10-21 07:45:44'),
(536, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:46:03', '2021-10-21 07:46:03'),
(537, 1, 'admin/form-sr4s/1', 'DELETE', '127.0.0.1', '{\"_method\":\"delete\",\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\"}', '2021-10-21 07:46:14', '2021-10-21 07:46:14'),
(538, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:46:15', '2021-10-21 07:46:15'),
(539, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 07:46:21', '2021-10-21 07:46:21'),
(540, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:46:25', '2021-10-21 07:46:25'),
(541, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 07:47:45', '2021-10-21 07:47:45'),
(542, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 07:47:49', '2021-10-21 07:47:49'),
(543, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 07:51:25', '2021-10-21 07:51:25'),
(544, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 07:51:34', '2021-10-21 07:51:34'),
(545, 3, 'admin/form-sr4s', 'POST', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"4\",\"years_of_expirience\":\"0\",\"dealers_in\":\"Agriculture crops\",\"processing_of\":\"Horticulture crops\",\"marketing_of\":\"Other\",\"marketing_of_other\":\"Floriculture\",\"have_adequate_land\":\"Yes\",\"land_size\":\"10\",\"have_adequate_equipment\":\"Yes\",\"eqipment\":\"Tractor\",\"have_contractual_agreement\":\"No\",\"have_adequate_field_officers\":\"Yes\",\"have_conversant_seed_matters\":\"No\",\"souce_of_seed\":\"2\",\"have_adequate_land_for_production\":\"Yes\",\"have_internal_quality_program\":\"No\",\"accept_declaration\":[\"1\",null],\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr4s\"}', '2021-10-21 07:54:33', '2021-10-21 07:54:33'),
(546, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 07:54:34', '2021-10-21 07:54:34'),
(547, 3, 'admin/form-sr4s', 'POST', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"4\",\"years_of_expirience\":\"0\",\"dealers_in\":\"Agriculture crops\",\"processing_of\":\"Horticulture crops\",\"marketing_of\":\"Other\",\"marketing_of_other\":\"Floriculture\",\"have_adequate_land\":\"Yes\",\"land_size\":\"10\",\"have_adequate_equipment\":\"Yes\",\"eqipment\":\"Tractor\",\"have_contractual_agreement\":\"No\",\"have_adequate_field_officers\":\"Yes\",\"have_conversant_seed_matters\":\"No\",\"souce_of_seed\":\"2\",\"have_adequate_land_for_production\":\"Yes\",\"have_internal_quality_program\":\"No\",\"accept_declaration\":[\"1\",null],\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\"}', '2021-10-21 07:58:33', '2021-10-21 07:58:33'),
(548, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 08:00:44', '2021-10-21 08:00:44'),
(549, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 08:00:48', '2021-10-21 08:00:48'),
(550, 3, 'admin/form-sr4s', 'POST', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"29\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Horticulture crops\",\"processing_of\":\"Horticulture crops\",\"marketing_of\":\"Horticulture crops\",\"have_adequate_land\":\"No\",\"have_adequate_equipment\":\"No\",\"have_contractual_agreement\":\"No\",\"have_adequate_field_officers\":\"No\",\"have_conversant_seed_matters\":\"No\",\"souce_of_seed\":\"3\",\"have_adequate_land_for_production\":\"No\",\"have_internal_quality_program\":\"No\",\"receipt\":\"ssd\",\"accept_declaration\":[\"1\",null],\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr4s\"}', '2021-10-21 08:01:29', '2021-10-21 08:01:29'),
(551, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 08:01:46', '2021-10-21 08:01:46'),
(552, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 08:01:49', '2021-10-21 08:01:49'),
(553, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 08:01:53', '2021-10-21 08:01:53'),
(554, 3, 'admin/form-sr4s', 'POST', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"3\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Horticulture crops\",\"processing_of\":\"Other\",\"marketing_of\":\"Horticulture crops\",\"have_adequate_land\":\"No\",\"have_adequate_equipment\":\"No\",\"have_contractual_agreement\":\"No\",\"have_adequate_field_officers\":\"No\",\"have_conversant_seed_matters\":\"No\",\"souce_of_seed\":\"2\",\"have_adequate_land_for_production\":\"No\",\"have_internal_quality_program\":\"No\",\"receipt\":\"ssd\",\"accept_declaration\":[\"1\",null],\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\"}', '2021-10-21 08:02:25', '2021-10-21 08:02:25'),
(555, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:02:26', '2021-10-21 08:02:26'),
(556, 3, 'admin/form-sr4s', 'POST', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"3\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Horticulture crops\",\"processing_of\":\"Other\",\"processing_of_other\":null,\"marketing_of\":\"Horticulture crops\",\"have_adequate_land\":\"No\",\"have_adequate_equipment\":\"No\",\"have_contractual_agreement\":\"No\",\"have_adequate_field_officers\":\"No\",\"have_conversant_seed_matters\":\"No\",\"souce_of_seed\":\"2\",\"have_adequate_land_for_production\":\"No\",\"have_internal_quality_program\":\"No\",\"receipt\":\"ssd\",\"accept_declaration\":[\"1\",null],\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\"}', '2021-10-21 08:10:07', '2021-10-21 08:10:07'),
(557, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:10:07', '2021-10-21 08:10:07'),
(558, 3, 'admin/form-sr4s', 'POST', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"3\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Horticulture crops\",\"processing_of\":\"Other\",\"processing_of_other\":null,\"marketing_of\":\"Horticulture crops\",\"have_adequate_land\":\"No\",\"have_adequate_equipment\":\"No\",\"have_contractual_agreement\":\"No\",\"have_adequate_field_officers\":\"No\",\"have_conversant_seed_matters\":\"No\",\"souce_of_seed\":\"2\",\"have_adequate_land_for_production\":\"No\",\"have_internal_quality_program\":\"No\",\"receipt\":\"ssd\",\"accept_declaration\":[\"1\",null],\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\"}', '2021-10-21 08:11:05', '2021-10-21 08:11:05'),
(559, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:11:05', '2021-10-21 08:11:05'),
(560, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:11:29', '2021-10-21 08:11:29'),
(561, 3, 'admin/form-sr4s', 'POST', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"2\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Horticulture crops\",\"processing_of\":\"Horticulture crops\",\"marketing_of\":\"Horticulture crops\",\"have_adequate_land\":\"No\",\"have_adequate_equipment\":\"No\",\"have_contractual_agreement\":\"No\",\"have_adequate_field_officers\":\"No\",\"have_conversant_seed_matters\":\"No\",\"souce_of_seed\":\"2\",\"have_adequate_land_for_production\":\"No\",\"have_internal_quality_program\":\"No\",\"accept_declaration\":[\"1\",null],\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr4s\"}', '2021-10-21 08:12:11', '2021-10-21 08:12:11'),
(562, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:12:11', '2021-10-21 08:12:11'),
(563, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:12:47', '2021-10-21 08:12:47'),
(564, 3, 'admin/form-sr4s', 'POST', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\"}', '2021-10-21 08:12:55', '2021-10-21 08:12:55'),
(565, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 08:12:55', '2021-10-21 08:12:55'),
(566, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 08:13:01', '2021-10-21 08:13:01'),
(567, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:13:19', '2021-10-21 08:13:19'),
(568, 3, 'admin/form-sr4s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"20\",\"years_of_expirience\":\"1\",\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr4s\\/create\"}', '2021-10-21 08:13:29', '2021-10-21 08:13:29'),
(569, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:13:29', '2021-10-21 08:13:29'),
(570, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:13:32', '2021-10-21 08:13:32'),
(571, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:13:48', '2021-10-21 08:13:48'),
(572, 3, 'admin/form-sr4s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"20\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Agriculture crops\",\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 08:13:54', '2021-10-21 08:13:54'),
(573, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:13:54', '2021-10-21 08:13:54'),
(574, 3, 'admin/form-sr4s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"20\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Horticulture crops\",\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 08:13:58', '2021-10-21 08:13:58'),
(575, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:13:59', '2021-10-21 08:13:59'),
(576, 3, 'admin/form-sr4s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"20\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Other\",\"dealers_in_other\":\"Floriculture\",\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 08:14:24', '2021-10-21 08:14:24'),
(577, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:14:24', '2021-10-21 08:14:24'),
(578, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:14:28', '2021-10-21 08:14:28'),
(579, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:14:41', '2021-10-21 08:14:41'),
(580, 3, 'admin/form-sr4s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"20\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Other\",\"dealers_in_other\":\"Floriculture\",\"processing_of\":\"Horticulture crops\",\"marketing_of\":\"Horticulture crops\",\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 08:14:52', '2021-10-21 08:14:52'),
(581, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:14:52', '2021-10-21 08:14:52'),
(582, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:15:07', '2021-10-21 08:15:07'),
(583, 3, 'admin/form-sr4s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"20\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Other\",\"dealers_in_other\":\"Floriculture\",\"processing_of\":\"Horticulture crops\",\"marketing_of\":\"Horticulture crops\",\"have_adequate_land\":\"Yes\",\"land_size\":\"20\",\"have_adequate_equipment\":\"No\",\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 08:15:16', '2021-10-21 08:15:16'),
(584, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:15:17', '2021-10-21 08:15:17'),
(585, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:16:00', '2021-10-21 08:16:00'),
(586, 3, 'admin/form-sr4s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"20\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Other\",\"dealers_in_other\":\"Floriculture\",\"processing_of\":\"Horticulture crops\",\"marketing_of\":\"Horticulture crops\",\"have_adequate_land\":\"0\",\"have_adequate_equipment\":\"0\",\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 08:16:06', '2021-10-21 08:16:06'),
(587, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:16:06', '2021-10-21 08:16:06'),
(588, 3, 'admin/form-sr4s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"20\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Other\",\"dealers_in_other\":\"Floriculture\",\"processing_of\":\"Horticulture crops\",\"marketing_of\":\"Horticulture crops\",\"have_adequate_land\":\"1\",\"land_size\":\"20\",\"have_adequate_equipment\":\"0\",\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 08:16:20', '2021-10-21 08:16:20'),
(589, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:16:21', '2021-10-21 08:16:21'),
(590, 3, 'admin/form-sr4s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"20\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Other\",\"dealers_in_other\":\"Floriculture\",\"processing_of\":\"Horticulture crops\",\"marketing_of\":\"Horticulture crops\",\"have_adequate_land\":\"1\",\"land_size\":\"20\",\"have_adequate_equipment\":\"1\",\"eqipment\":\"Tractor\",\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 08:16:30', '2021-10-21 08:16:30'),
(591, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:16:30', '2021-10-21 08:16:30'),
(592, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:17:10', '2021-10-21 08:17:10'),
(593, 3, 'admin/form-sr4s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"20\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Other\",\"dealers_in_other\":\"Floriculture\",\"processing_of\":\"Horticulture crops\",\"marketing_of\":\"Horticulture crops\",\"have_adequate_land\":\"1\",\"land_size\":\"20\",\"have_adequate_equipment\":\"1\",\"eqipment\":\"Tractor\",\"have_contractual_agreement\":\"1\",\"have_adequate_field_officers\":\"1\",\"have_conversant_seed_matters\":\"0\",\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 08:17:28', '2021-10-21 08:17:28'),
(594, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:17:29', '2021-10-21 08:17:29'),
(595, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:17:48', '2021-10-21 08:17:48'),
(596, 3, 'admin/form-sr4s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"20\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Other\",\"dealers_in_other\":\"Floriculture\",\"processing_of\":\"Horticulture crops\",\"marketing_of\":\"Horticulture crops\",\"have_adequate_land\":\"1\",\"land_size\":\"20\",\"have_adequate_equipment\":\"1\",\"eqipment\":\"Tractor\",\"have_contractual_agreement\":\"1\",\"have_adequate_field_officers\":\"1\",\"have_conversant_seed_matters\":\"1\",\"souce_of_seed\":\"2\",\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 08:17:56', '2021-10-21 08:17:56'),
(597, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:17:56', '2021-10-21 08:17:56'),
(598, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:18:32', '2021-10-21 08:18:32'),
(599, 3, 'admin/form-sr4s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"20\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Other\",\"dealers_in_other\":\"Floriculture\",\"processing_of\":\"Horticulture crops\",\"marketing_of\":\"Horticulture crops\",\"have_adequate_land\":\"1\",\"land_size\":\"20\",\"have_adequate_equipment\":\"1\",\"eqipment\":\"Tractor\",\"have_contractual_agreement\":\"1\",\"have_adequate_field_officers\":\"1\",\"have_conversant_seed_matters\":\"1\",\"souce_of_seed\":\"2\",\"have_adequate_land_for_production\":\"1\",\"have_internal_quality_program\":\"1\",\"accept_declaration\":[\"1\",null],\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 08:18:41', '2021-10-21 08:18:41'),
(600, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:18:42', '2021-10-21 08:18:42'),
(601, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:19:19', '2021-10-21 08:19:19'),
(602, 3, 'admin/form-sr4s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"20\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Other\",\"dealers_in_other\":\"Floriculture\",\"processing_of\":\"Horticulture crops\",\"marketing_of\":\"Horticulture crops\",\"have_adequate_land\":\"1\",\"land_size\":\"20\",\"have_adequate_equipment\":\"1\",\"eqipment\":\"Tractor\",\"have_contractual_agreement\":\"1\",\"have_adequate_field_officers\":\"1\",\"have_conversant_seed_matters\":\"1\",\"souce_of_seed\":\"2\",\"have_adequate_land_for_production\":\"0\",\"have_internal_quality_program\":\"0\",\"accept_declaration\":[\"1\",null],\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 08:19:24', '2021-10-21 08:19:24'),
(603, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:19:24', '2021-10-21 08:19:24'),
(604, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:20:38', '2021-10-21 08:20:38'),
(605, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:20:45', '2021-10-21 08:20:45'),
(606, 3, 'admin/form-sr4s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"20\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Other\",\"dealers_in_other\":\"Floriculture\",\"processing_of\":\"Horticulture crops\",\"marketing_of\":\"Horticulture crops\",\"have_adequate_land\":\"1\",\"land_size\":\"20\",\"have_adequate_equipment\":\"1\",\"eqipment\":\"Tractor\",\"have_contractual_agreement\":\"1\",\"have_adequate_field_officers\":\"1\",\"have_conversant_seed_matters\":\"1\",\"souce_of_seed\":\"2\",\"have_adequate_land_for_production\":\"0\",\"have_internal_quality_program\":\"0\",\"accept_declaration\":null,\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 08:20:50', '2021-10-21 08:20:50'),
(607, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:20:50', '2021-10-21 08:20:50'),
(608, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:21:05', '2021-10-21 08:21:05'),
(609, 3, 'admin/form-sr4s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"20\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Other\",\"dealers_in_other\":\"Floriculture\",\"processing_of\":\"Horticulture crops\",\"marketing_of\":\"Horticulture crops\",\"have_adequate_land\":\"1\",\"land_size\":\"20\",\"have_adequate_equipment\":\"1\",\"eqipment\":\"Tractor\",\"have_contractual_agreement\":\"1\",\"have_adequate_field_officers\":\"1\",\"have_conversant_seed_matters\":\"1\",\"souce_of_seed\":\"2\",\"have_adequate_land_for_production\":\"0\",\"have_internal_quality_program\":\"0\",\"accept_declaration\":\"1\",\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 08:21:10', '2021-10-21 08:21:10'),
(610, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:21:10', '2021-10-21 08:21:10'),
(611, 3, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 08:22:10', '2021-10-21 08:22:10'),
(612, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 08:24:58', '2021-10-21 08:24:58'),
(613, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 08:25:03', '2021-10-21 08:25:03'),
(614, 3, 'admin/form-sr4s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"20\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Other\",\"dealers_in_other\":\"Floriculture\",\"processing_of\":\"Horticulture crops\",\"marketing_of\":\"Horticulture crops\",\"have_adequate_land\":\"1\",\"land_size\":\"20\",\"have_adequate_equipment\":\"1\",\"eqipment\":\"Tractor\",\"have_contractual_agreement\":\"1\",\"have_adequate_field_officers\":\"1\",\"have_conversant_seed_matters\":\"1\",\"souce_of_seed\":\"2\",\"have_adequate_land_for_production\":\"0\",\"have_internal_quality_program\":\"0\",\"accept_declaration\":\"1\",\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr4s\"}', '2021-10-21 08:25:15', '2021-10-21 08:25:15'),
(615, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:25:15', '2021-10-21 08:25:15'),
(616, 3, 'admin/form-sr4s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"20\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Other\",\"dealers_in_other\":\"Floriculture\",\"processing_of\":\"Horticulture crops\",\"marketing_of\":\"Horticulture crops\",\"have_adequate_land\":\"1\",\"land_size\":\"20\",\"have_adequate_equipment\":\"1\",\"eqipment\":\"Tractor\",\"have_contractual_agreement\":\"1\",\"have_adequate_field_officers\":\"1\",\"have_conversant_seed_matters\":\"1\",\"souce_of_seed\":\"2\",\"have_adequate_land_for_production\":\"0\",\"have_internal_quality_program\":\"0\",\"accept_declaration\":\"1\",\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 08:27:10', '2021-10-21 08:27:10'),
(617, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:27:10', '2021-10-21 08:27:10'),
(618, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:27:22', '2021-10-21 08:27:22'),
(619, 3, 'admin/form-sr4s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"20\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Other\",\"dealers_in_other\":\"Floriculture\",\"processing_of\":\"Horticulture crops\",\"marketing_of\":\"Horticulture crops\",\"have_adequate_land\":\"1\",\"land_size\":\"20\",\"have_adequate_equipment\":\"1\",\"eqipment\":\"Tractor\",\"have_contractual_agreement\":\"1\",\"have_adequate_field_officers\":\"1\",\"have_conversant_seed_matters\":\"1\",\"souce_of_seed\":\"2\",\"have_adequate_land_for_production\":\"0\",\"have_internal_quality_program\":\"0\",\"accept_declaration\":\"1\",\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 08:27:28', '2021-10-21 08:27:28');
INSERT INTO `admin_operation_log` (`id`, `user_id`, `path`, `method`, `ip`, `input`, `created_at`, `updated_at`) VALUES
(620, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:27:28', '2021-10-21 08:27:28'),
(621, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:27:50', '2021-10-21 08:27:50'),
(622, 3, 'admin/form-sr4s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"20\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Other\",\"dealers_in_other\":\"Floriculture\",\"processing_of\":\"Horticulture crops\",\"marketing_of\":\"Horticulture crops\",\"have_adequate_land\":\"1\",\"land_size\":\"20\",\"have_adequate_equipment\":\"1\",\"eqipment\":\"Tractor\",\"have_contractual_agreement\":\"1\",\"have_adequate_field_officers\":\"1\",\"have_conversant_seed_matters\":\"1\",\"souce_of_seed\":\"2\",\"have_adequate_land_for_production\":\"0\",\"have_internal_quality_program\":\"0\",\"accept_declaration\":\"1\",\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 08:27:56', '2021-10-21 08:27:56'),
(623, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:27:56', '2021-10-21 08:27:56'),
(624, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:28:23', '2021-10-21 08:28:23'),
(625, 3, 'admin/form-sr4s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"20\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Other\",\"dealers_in_other\":\"Floriculture\",\"processing_of\":\"Horticulture crops\",\"marketing_of\":\"Horticulture crops\",\"have_adequate_land\":\"1\",\"land_size\":\"20\",\"have_adequate_equipment\":\"1\",\"eqipment\":\"Tractor\",\"have_contractual_agreement\":\"1\",\"have_adequate_field_officers\":\"1\",\"have_conversant_seed_matters\":\"1\",\"souce_of_seed\":\"2\",\"have_adequate_land_for_production\":\"0\",\"have_internal_quality_program\":\"0\",\"accept_declaration\":\"1\",\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 08:28:29', '2021-10-21 08:28:29'),
(626, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:28:29', '2021-10-21 08:28:29'),
(627, 3, 'admin/form-sr4s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"20\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Other\",\"dealers_in_other\":\"Floriculture\",\"processing_of\":\"Horticulture crops\",\"marketing_of\":\"Horticulture crops\",\"have_adequate_land\":\"1\",\"land_size\":\"20\",\"have_adequate_equipment\":\"1\",\"eqipment\":\"Tractor\",\"have_contractual_agreement\":\"1\",\"have_adequate_field_officers\":\"1\",\"have_conversant_seed_matters\":\"1\",\"souce_of_seed\":\"2\",\"have_adequate_land_for_production\":\"0\",\"have_internal_quality_program\":\"0\",\"accept_declaration\":\"1\",\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 08:28:40', '2021-10-21 08:28:40'),
(628, 3, 'admin/form-sr4s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 08:28:40', '2021-10-21 08:28:40'),
(629, 3, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 08:29:05', '2021-10-21 08:29:05'),
(630, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 08:29:08', '2021-10-21 08:29:08'),
(631, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 08:29:12', '2021-10-21 08:29:12'),
(632, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 08:29:23', '2021-10-21 08:29:23'),
(633, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:34:57', '2021-10-21 08:34:57'),
(634, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:38:52', '2021-10-21 08:38:52'),
(635, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:40:03', '2021-10-21 08:40:03'),
(636, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:41:54', '2021-10-21 08:41:54'),
(637, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:42:19', '2021-10-21 08:42:19'),
(638, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:42:42', '2021-10-21 08:42:42'),
(639, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:42:55', '2021-10-21 08:42:55'),
(640, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:43:04', '2021-10-21 08:43:04'),
(641, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:43:31', '2021-10-21 08:43:31'),
(642, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 08:43:58', '2021-10-21 08:43:58'),
(643, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:44:01', '2021-10-21 08:44:01'),
(644, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:44:08', '2021-10-21 08:44:08'),
(645, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:47:50', '2021-10-21 08:47:50'),
(646, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:50:11', '2021-10-21 08:50:11'),
(647, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:50:19', '2021-10-21 08:50:19'),
(648, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:50:34', '2021-10-21 08:50:34'),
(649, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:50:44', '2021-10-21 08:50:44'),
(650, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:50:55', '2021-10-21 08:50:55'),
(651, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:50:57', '2021-10-21 08:50:57'),
(652, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:51:03', '2021-10-21 08:51:03'),
(653, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:51:07', '2021-10-21 08:51:07'),
(654, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:51:18', '2021-10-21 08:51:18'),
(655, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:51:28', '2021-10-21 08:51:28'),
(656, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:52:47', '2021-10-21 08:52:47'),
(657, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 08:52:55', '2021-10-21 08:52:55'),
(658, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 08:53:02', '2021-10-21 08:53:02'),
(659, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 08:54:46', '2021-10-21 08:54:46'),
(660, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 08:55:37', '2021-10-21 08:55:37'),
(661, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 08:56:07', '2021-10-21 08:56:07'),
(662, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 08:56:29', '2021-10-21 08:56:29'),
(663, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 08:56:38', '2021-10-21 08:56:38'),
(664, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 09:00:20', '2021-10-21 09:00:20'),
(665, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 09:00:30', '2021-10-21 09:00:30'),
(666, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 09:00:31', '2021-10-21 09:00:31'),
(667, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 09:47:46', '2021-10-21 09:47:46'),
(668, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 09:47:52', '2021-10-21 09:47:52'),
(669, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 09:48:06', '2021-10-21 09:48:06'),
(670, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 09:48:33', '2021-10-21 09:48:33'),
(671, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 09:48:57', '2021-10-21 09:48:57'),
(672, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 09:49:31', '2021-10-21 09:49:31'),
(673, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 09:49:38', '2021-10-21 09:49:38'),
(674, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 09:51:45', '2021-10-21 09:51:45'),
(675, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 09:51:52', '2021-10-21 09:51:52'),
(676, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 09:52:34', '2021-10-21 09:52:34'),
(677, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 09:52:44', '2021-10-21 09:52:44'),
(678, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 09:53:01', '2021-10-21 09:53:01'),
(679, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 09:54:41', '2021-10-21 09:54:41'),
(680, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 09:54:50', '2021-10-21 09:54:50'),
(681, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 09:54:51', '2021-10-21 09:54:51'),
(682, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 09:54:56', '2021-10-21 09:54:56'),
(683, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 09:54:56', '2021-10-21 09:54:56'),
(684, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 09:55:00', '2021-10-21 09:55:00'),
(685, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 09:57:57', '2021-10-21 09:57:57'),
(686, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 09:58:20', '2021-10-21 09:58:20'),
(687, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 09:58:39', '2021-10-21 09:58:39'),
(688, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:00:46', '2021-10-21 10:00:46'),
(689, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:01:02', '2021-10-21 10:01:02'),
(690, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:04:18', '2021-10-21 10:04:18'),
(691, 1, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '[]', '2021-10-21 10:05:21', '2021-10-21 10:05:21'),
(692, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 10:05:27', '2021-10-21 10:05:27'),
(693, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:05:35', '2021-10-21 10:05:35'),
(694, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:07:34', '2021-10-21 10:07:34'),
(695, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:12:54', '2021-10-21 10:12:54'),
(696, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:13:40', '2021-10-21 10:13:40'),
(697, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:13:55', '2021-10-21 10:13:55'),
(698, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:14:08', '2021-10-21 10:14:08'),
(699, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:15:35', '2021-10-21 10:15:35'),
(700, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:17:03', '2021-10-21 10:17:03'),
(701, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:18:35', '2021-10-21 10:18:35'),
(702, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:19:54', '2021-10-21 10:19:54'),
(703, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:20:48', '2021-10-21 10:20:48'),
(704, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:25:50', '2021-10-21 10:25:50'),
(705, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:26:27', '2021-10-21 10:26:27'),
(706, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:27:10', '2021-10-21 10:27:10'),
(707, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:27:28', '2021-10-21 10:27:28'),
(708, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_export_\":\"page:1\"}', '2021-10-21 10:28:19', '2021-10-21 10:28:19'),
(709, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:29:18', '2021-10-21 10:29:18'),
(710, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:29:37', '2021-10-21 10:29:37'),
(711, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:30:26', '2021-10-21 10:30:26'),
(712, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_sort\":{\"column\":\"id\",\"type\":\"desc\"},\"_pjax\":\"#pjax-container\"}', '2021-10-21 10:30:30', '2021-10-21 10:30:30'),
(713, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_sort\":{\"column\":\"id\",\"type\":\"asc\"},\"_pjax\":\"#pjax-container\"}', '2021-10-21 10:30:31', '2021-10-21 10:30:31'),
(714, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_sort\":{\"column\":\"id\",\"type\":\"asc\"}}', '2021-10-21 10:30:56', '2021-10-21 10:30:56'),
(715, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_sort\":{\"column\":\"status\",\"type\":\"desc\"},\"_pjax\":\"#pjax-container\"}', '2021-10-21 10:31:01', '2021-10-21 10:31:01'),
(716, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_sort\":{\"column\":\"status\",\"type\":\"desc\"}}', '2021-10-21 10:31:36', '2021-10-21 10:31:36'),
(717, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_sort\":{\"column\":\"status\",\"type\":\"desc\"},\"per_page\":\"10\",\"_pjax\":\"#pjax-container\"}', '2021-10-21 10:31:45', '2021-10-21 10:31:45'),
(718, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_sort\":{\"column\":\"status\",\"type\":\"desc\"},\"per_page\":\"10\",\"_pjax\":\"#pjax-container\"}', '2021-10-21 10:31:58', '2021-10-21 10:31:58'),
(719, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_sort\":{\"column\":\"status\",\"type\":\"desc\"},\"per_page\":\"10\"}', '2021-10-21 10:37:05', '2021-10-21 10:37:05'),
(720, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_sort\":{\"column\":\"status\",\"type\":\"desc\"},\"per_page\":\"10\"}', '2021-10-21 10:37:19', '2021-10-21 10:37:19'),
(721, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_sort\":{\"column\":\"status\",\"type\":\"desc\"},\"per_page\":\"10\"}', '2021-10-21 10:38:32', '2021-10-21 10:38:32'),
(722, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:38:39', '2021-10-21 10:38:39'),
(723, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:39:09', '2021-10-21 10:39:09'),
(724, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:39:43', '2021-10-21 10:39:43'),
(725, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:39:50', '2021-10-21 10:39:50'),
(726, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:42:33', '2021-10-21 10:42:33'),
(727, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_sort\":{\"column\":\"status\",\"type\":\"desc\"},\"per_page\":\"10\"}', '2021-10-21 10:42:45', '2021-10-21 10:42:45'),
(728, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:48:31', '2021-10-21 10:48:31'),
(729, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:48:39', '2021-10-21 10:48:39'),
(730, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:51:08', '2021-10-21 10:51:08'),
(731, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:51:40', '2021-10-21 10:51:40'),
(732, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:52:04', '2021-10-21 10:52:04'),
(733, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:54:40', '2021-10-21 10:54:40'),
(734, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:54:49', '2021-10-21 10:54:49'),
(735, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:55:55', '2021-10-21 10:55:55'),
(736, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:56:17', '2021-10-21 10:56:17'),
(737, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:56:54', '2021-10-21 10:56:54'),
(738, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:57:49', '2021-10-21 10:57:49'),
(739, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:58:30', '2021-10-21 10:58:30'),
(740, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 10:58:43', '2021-10-21 10:58:43'),
(741, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 11:07:15', '2021-10-21 11:07:15'),
(742, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 11:07:52', '2021-10-21 11:07:52'),
(743, 3, 'admin/_handle_action_', 'POST', '127.0.0.1', '{\"_key\":\"2\",\"_model\":\"App_Models_FormSr4\",\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"_action\":\"Encore_Admin_Grid_Actions_Delete\",\"_input\":\"true\"}', '2021-10-21 11:08:05', '2021-10-21 11:08:05'),
(744, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 11:08:05', '2021-10-21 11:08:05'),
(745, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 11:08:10', '2021-10-21 11:08:10'),
(746, 3, 'admin/form-sr4s', 'POST', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"22\",\"years_of_expirience\":\"2\",\"dealers_in\":\"Horticulture crops\",\"processing_of\":\"Horticulture crops\",\"marketing_of\":\"Other\",\"marketing_of_other\":\"Floriculture\",\"have_adequate_land\":\"1\",\"land_size\":\"31\",\"have_adequate_equipment\":\"1\",\"eqipment\":\"Tractor\",\"have_contractual_agreement\":\"1\",\"have_adequate_field_officers\":\"1\",\"have_conversant_seed_matters\":\"0\",\"souce_of_seed\":\"2\",\"have_adequate_land_for_production\":\"1\",\"have_internal_quality_program\":\"1\",\"accept_declaration\":\"1\",\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr4s\"}', '2021-10-21 11:08:58', '2021-10-21 11:08:58'),
(747, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 11:08:58', '2021-10-21 11:08:58'),
(748, 3, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 11:09:10', '2021-10-21 11:09:10'),
(749, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 11:09:24', '2021-10-21 11:09:24'),
(750, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 11:09:45', '2021-10-21 11:09:45'),
(751, 3, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 11:09:49', '2021-10-21 11:09:49'),
(752, 3, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 11:09:50', '2021-10-21 11:09:50'),
(753, 3, 'admin/auth/setting', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 11:09:53', '2021-10-21 11:09:53'),
(754, 3, 'admin/auth/setting', 'PUT', '127.0.0.1', '{\"name\":\"Betty Namagembe\",\"password\":\"$2y$10$cBUNI05M8a7AUXSEgLr4cudiDW3nFZ2McpfuAQOf4HIfjUF.6Viha\",\"password_confirmation\":\"$2y$10$cBUNI05M8a7AUXSEgLr4cudiDW3nFZ2McpfuAQOf4HIfjUF.6Viha\",\"_token\":\"IMsG68eZDTkvwutJIuQPM73FLkAmxdDrAJHwjtd4\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\"}', '2021-10-21 11:10:00', '2021-10-21 11:10:00'),
(755, 3, 'admin/auth/setting', 'GET', '127.0.0.1', '[]', '2021-10-21 11:10:01', '2021-10-21 11:10:01'),
(756, 3, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 11:10:09', '2021-10-21 11:10:09'),
(757, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 11:10:12', '2021-10-21 11:10:12'),
(758, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 11:10:15', '2021-10-21 11:10:15'),
(759, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_sort\":{\"column\":\"status\",\"type\":\"desc\"},\"per_page\":\"10\"}', '2021-10-21 11:10:34', '2021-10-21 11:10:34'),
(760, 1, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 11:11:00', '2021-10-21 11:11:00'),
(761, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_sort\":{\"column\":\"status\",\"type\":\"desc\"},\"per_page\":\"10\",\"_pjax\":\"#pjax-container\"}', '2021-10-21 11:11:10', '2021-10-21 11:11:10'),
(762, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_sort\":{\"column\":\"status\",\"type\":\"desc\"},\"per_page\":\"10\"}', '2021-10-21 12:34:29', '2021-10-21 12:34:29'),
(763, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 12:34:37', '2021-10-21 12:34:37'),
(764, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 12:34:57', '2021-10-21 12:34:57'),
(765, 1, 'admin/auth/roles/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 12:35:03', '2021-10-21 12:35:03'),
(766, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 12:35:08', '2021-10-21 12:35:08'),
(767, 1, 'admin/auth/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 12:35:11', '2021-10-21 12:35:11'),
(768, 1, 'admin/auth/users/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 12:35:16', '2021-10-21 12:35:16'),
(769, 1, 'admin/auth/users/1', 'PUT', '127.0.0.1', '{\"username\":\"super-admin\",\"name\":\"Administrator\",\"password\":\"$2y$10$QNeDbnld.yMiYe17K.LtSeGcA7hDD96KUosMFvnM6tWBVWHoG0V.C\",\"password_confirmation\":\"$2y$10$QNeDbnld.yMiYe17K.LtSeGcA7hDD96KUosMFvnM6tWBVWHoG0V.C\",\"roles\":[\"1\",\"2\",null],\"permissions\":[null],\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/users\"}', '2021-10-21 12:35:23', '2021-10-21 12:35:23'),
(770, 1, 'admin/auth/users', 'GET', '127.0.0.1', '[]', '2021-10-21 12:35:23', '2021-10-21 12:35:23'),
(771, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 12:35:27', '2021-10-21 12:35:27'),
(772, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 12:38:26', '2021-10-21 12:38:26'),
(773, 1, 'admin/form-sr4s/3', 'PUT', '127.0.0.1', '{\"name\":\"inspector\",\"value\":\"2\",\"pk\":\"3\",\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"_editable\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 12:38:35', '2021-10-21 12:38:35'),
(774, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 12:38:44', '2021-10-21 12:38:44'),
(775, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 12:39:36', '2021-10-21 12:39:36'),
(776, 1, 'admin/form-sr4s/3', 'PUT', '127.0.0.1', '{\"name\":\"inspector\",\"value\":\"Romina\",\"pk\":\"3\",\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"_editable\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 12:39:47', '2021-10-21 12:39:47'),
(777, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 12:39:51', '2021-10-21 12:39:51'),
(778, 1, 'admin/form-sr4s/3', 'PUT', '127.0.0.1', '{\"name\":\"inspector\",\"value\":\"1\",\"pk\":\"3\",\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"_editable\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 12:39:56', '2021-10-21 12:39:56'),
(779, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 12:39:59', '2021-10-21 12:39:59'),
(780, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 12:40:10', '2021-10-21 12:40:10'),
(781, 1, 'admin/form-sr4s/3', 'PUT', '127.0.0.1', '{\"name\":\"inspector\",\"value\":\"1\",\"pk\":\"3\",\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"_editable\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 12:40:15', '2021-10-21 12:40:15'),
(782, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 12:40:19', '2021-10-21 12:40:19'),
(783, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 12:41:13', '2021-10-21 12:41:13'),
(784, 1, 'admin/form-sr4s/3', 'PUT', '127.0.0.1', '{\"name\":\"inspector\",\"value\":\"1\",\"pk\":\"3\",\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"_editable\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 12:41:21', '2021-10-21 12:41:21'),
(785, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 12:41:24', '2021-10-21 12:41:24'),
(786, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 12:42:12', '2021-10-21 12:42:12'),
(787, 1, 'admin/form-sr4s/3', 'PUT', '127.0.0.1', '{\"name\":\"inspector\",\"value\":\"1\",\"pk\":\"3\",\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"_editable\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 12:42:18', '2021-10-21 12:42:18'),
(788, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 12:42:21', '2021-10-21 12:42:21'),
(789, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 12:45:47', '2021-10-21 12:45:47'),
(790, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 12:45:59', '2021-10-21 12:45:59'),
(791, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 12:48:03', '2021-10-21 12:48:03'),
(792, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 12:51:01', '2021-10-21 12:51:01'),
(793, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 12:56:11', '2021-10-21 12:56:11'),
(794, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 12:58:56', '2021-10-21 12:58:56'),
(795, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:00:52', '2021-10-21 13:00:52'),
(796, 1, 'admin/form-sr4s/3', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"status\":\"2\",\"inspector\":\"2\",\"dealers_in_other\":\"Floriculture\",\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"_method\":\"PUT\"}', '2021-10-21 13:01:39', '2021-10-21 13:01:39'),
(797, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 13:01:39', '2021-10-21 13:01:39'),
(798, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:01:44', '2021-10-21 13:01:44'),
(799, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:01:55', '2021-10-21 13:01:55'),
(800, 1, 'admin/auth/roles/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:01:59', '2021-10-21 13:01:59'),
(801, 1, 'admin/auth/roles', 'POST', '127.0.0.1', '{\"slug\":\"inspector\",\"name\":\"Inspector\",\"permissions\":[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",null],\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/roles\"}', '2021-10-21 13:02:29', '2021-10-21 13:02:29'),
(802, 1, 'admin/auth/roles', 'GET', '127.0.0.1', '[]', '2021-10-21 13:02:30', '2021-10-21 13:02:30'),
(803, 1, 'admin/auth/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:02:32', '2021-10-21 13:02:32'),
(804, 1, 'admin/auth/users/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:02:33', '2021-10-21 13:02:33'),
(805, 1, 'admin/auth/users', 'POST', '127.0.0.1', '{\"username\":\"inspector\",\"name\":\"Dr. Drake Mirembe\",\"password\":\"4321\",\"password_confirmation\":\"4321\",\"roles\":[\"4\",null],\"permissions\":[null],\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/users\"}', '2021-10-21 13:07:57', '2021-10-21 13:07:57'),
(806, 1, 'admin/auth/users', 'GET', '127.0.0.1', '[]', '2021-10-21 13:07:58', '2021-10-21 13:07:58'),
(807, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:08:13', '2021-10-21 13:08:13'),
(808, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:08:19', '2021-10-21 13:08:19'),
(809, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:08:43', '2021-10-21 13:08:43'),
(810, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:09:20', '2021-10-21 13:09:20'),
(811, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:09:53', '2021-10-21 13:09:53'),
(812, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:10:28', '2021-10-21 13:10:28'),
(813, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:12:09', '2021-10-21 13:12:09'),
(814, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:15:31', '2021-10-21 13:15:31'),
(815, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:16:24', '2021-10-21 13:16:24'),
(816, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:16:37', '2021-10-21 13:16:37'),
(817, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:16:58', '2021-10-21 13:16:58'),
(818, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:18:12', '2021-10-21 13:18:12'),
(819, 1, 'admin/form-sr4s/3', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"status\":\"2\",\"inspector\":\"4\",\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"_method\":\"PUT\"}', '2021-10-21 13:18:20', '2021-10-21 13:18:20'),
(820, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 13:18:20', '2021-10-21 13:18:20'),
(821, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:18:26', '2021-10-21 13:18:26'),
(822, 1, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:19:15', '2021-10-21 13:19:15'),
(823, 1, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 13:20:30', '2021-10-21 13:20:30'),
(824, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:20:34', '2021-10-21 13:20:34'),
(825, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:20:39', '2021-10-21 13:20:39'),
(826, 1, 'admin/form-sr4s/3', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"status\":\"3\",\"status_comment\":\"Simple reason for hult\",\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 13:21:16', '2021-10-21 13:21:16'),
(827, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:21:16', '2021-10-21 13:21:16'),
(828, 1, 'admin/form-sr4s/3', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"status\":\"3\",\"status_comment\":\"Simple reason for halt\",\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 13:21:29', '2021-10-21 13:21:29'),
(829, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:21:29', '2021-10-21 13:21:29'),
(830, 1, 'admin/form-sr4s/3', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"status\":\"3\",\"status_comment\":\"Simple reason for halt\",\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 13:22:07', '2021-10-21 13:22:07'),
(831, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:22:08', '2021-10-21 13:22:08'),
(832, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 13:22:13', '2021-10-21 13:22:13'),
(833, 3, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:22:19', '2021-10-21 13:22:19'),
(834, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:22:33', '2021-10-21 13:22:33'),
(835, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:23:53', '2021-10-21 13:23:53'),
(836, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:26:47', '2021-10-21 13:26:47'),
(837, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:27:34', '2021-10-21 13:27:34'),
(838, 1, 'admin/form-sr4s/3', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"status\":\"6\",\"valid_from\":\"2021-10-21\",\"valid_until\":\"2021-10-23\",\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"_method\":\"PUT\"}', '2021-10-21 13:27:55', '2021-10-21 13:27:55'),
(839, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 13:27:56', '2021-10-21 13:27:56'),
(840, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:28:00', '2021-10-21 13:28:00'),
(841, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 13:28:05', '2021-10-21 13:28:05'),
(842, 1, 'admin/form-sr4s/3', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"status\":\"5\",\"valid_from\":\"2021-10-21\",\"valid_until\":\"2021-10-23\",\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr4s\"}', '2021-10-21 13:28:16', '2021-10-21 13:28:16'),
(843, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:28:16', '2021-10-21 13:28:16'),
(844, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:28:29', '2021-10-21 13:28:29'),
(845, 3, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:29:45', '2021-10-21 13:29:45'),
(846, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:29:53', '2021-10-21 13:29:53'),
(847, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:30:44', '2021-10-21 13:30:44'),
(848, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:31:07', '2021-10-21 13:31:07'),
(849, 1, 'admin/form-sr4s/3', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"status\":\"5\",\"valid_from\":\"2021-10-21\",\"valid_until\":\"2022-10-28\",\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr4s\"}', '2021-10-21 13:31:29', '2021-10-21 13:31:29'),
(850, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:31:30', '2021-10-21 13:31:30'),
(851, 1, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:31:33', '2021-10-21 13:31:33'),
(852, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:31:37', '2021-10-21 13:31:37'),
(853, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:31:45', '2021-10-21 13:31:45'),
(854, 1, 'admin/form-sr4s/3', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"status\":\"5\",\"valid_from\":\"2021-10-21\",\"valid_until\":\"2022-10-12\",\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr4s\"}', '2021-10-21 13:31:52', '2021-10-21 13:31:52'),
(855, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:31:52', '2021-10-21 13:31:52'),
(856, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:31:56', '2021-10-21 13:31:56'),
(857, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 13:32:35', '2021-10-21 13:32:35'),
(858, 3, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:32:42', '2021-10-21 13:32:42'),
(859, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:32:48', '2021-10-21 13:32:48'),
(860, 3, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:39:22', '2021-10-21 13:39:22'),
(861, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:39:55', '2021-10-21 13:39:55'),
(862, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:39:57', '2021-10-21 13:39:57'),
(863, 3, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:40:52', '2021-10-21 13:40:52'),
(864, 2, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-21 13:41:07', '2021-10-21 13:41:07'),
(865, 2, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:41:14', '2021-10-21 13:41:14'),
(866, 4, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-21 13:41:37', '2021-10-21 13:41:37'),
(867, 4, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:41:57', '2021-10-21 13:41:57'),
(868, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:42:00', '2021-10-21 13:42:00'),
(869, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:42:14', '2021-10-21 13:42:14'),
(870, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:42:17', '2021-10-21 13:42:17'),
(871, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 13:44:32', '2021-10-21 13:44:32'),
(872, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 13:44:37', '2021-10-21 13:44:37'),
(873, 4, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:44:49', '2021-10-21 13:44:49'),
(874, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:44:53', '2021-10-21 13:44:53'),
(875, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 13:45:41', '2021-10-21 13:45:41'),
(876, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:45:43', '2021-10-21 13:45:43'),
(877, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 13:46:01', '2021-10-21 13:46:01'),
(878, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 13:46:52', '2021-10-21 13:46:52'),
(879, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:47:32', '2021-10-21 13:47:32'),
(880, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 13:49:47', '2021-10-21 13:49:47'),
(881, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 13:50:00', '2021-10-21 13:50:00'),
(882, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 13:50:27', '2021-10-21 13:50:27'),
(883, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 13:50:36', '2021-10-21 13:50:36'),
(884, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 13:50:44', '2021-10-21 13:50:44'),
(885, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 13:51:52', '2021-10-21 13:51:52'),
(886, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:51:57', '2021-10-21 13:51:57'),
(887, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:52:01', '2021-10-21 13:52:01'),
(888, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:52:04', '2021-10-21 13:52:04'),
(889, 4, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:52:06', '2021-10-21 13:52:06'),
(890, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:52:09', '2021-10-21 13:52:09'),
(891, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:52:15', '2021-10-21 13:52:15'),
(892, 1, 'admin/form-sr4s/3', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"status\":\"2\",\"inspector\":\"4\",\"_token\":\"PCW4drjKQGCb5MluyIkjvoIu6vyR92WOOBv2uI6O\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr4s\"}', '2021-10-21 13:52:27', '2021-10-21 13:52:27'),
(893, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:52:27', '2021-10-21 13:52:27'),
(894, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 13:52:30', '2021-10-21 13:52:30'),
(895, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-21 13:53:09', '2021-10-21 13:53:09'),
(896, 4, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:53:18', '2021-10-21 13:53:18'),
(897, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:54:42', '2021-10-21 13:54:42'),
(898, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:55:31', '2021-10-21 13:55:31'),
(899, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:55:40', '2021-10-21 13:55:40'),
(900, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:56:54', '2021-10-21 13:56:54'),
(901, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:57:47', '2021-10-21 13:57:47'),
(902, 4, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:57:56', '2021-10-21 13:57:56'),
(903, 4, 'admin/form-sr4s/3', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"status\":\"5\",\"valid_from\":\"2021-10-21\",\"valid_until\":\"2022-10-12\",\"_token\":\"EESE31igY2Sxbr8wdDE3Feu3Cr6JnkXkZUwMxvVr\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-21 13:58:13', '2021-10-21 13:58:13'),
(904, 4, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:58:14', '2021-10-21 13:58:14'),
(905, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:58:18', '2021-10-21 13:58:18'),
(906, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:58:21', '2021-10-21 13:58:21'),
(907, 4, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:58:25', '2021-10-21 13:58:25'),
(908, 1, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:59:39', '2021-10-21 13:59:39'),
(909, 4, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 13:59:43', '2021-10-21 13:59:43'),
(910, 4, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-21 13:59:44', '2021-10-21 13:59:44'),
(911, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:59:47', '2021-10-21 13:59:47'),
(912, 4, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 13:59:53', '2021-10-21 13:59:53'),
(913, 4, 'admin/form-sr4s/3', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"status\":\"5\",\"valid_from\":\"2021-10-21\",\"valid_until\":\"2022-10-12\",\"_token\":\"EESE31igY2Sxbr8wdDE3Feu3Cr6JnkXkZUwMxvVr\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr4s\"}', '2021-10-21 14:00:07', '2021-10-21 14:00:07'),
(914, 4, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 14:00:08', '2021-10-21 14:00:08'),
(915, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 14:00:29', '2021-10-21 14:00:29'),
(916, 1, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 14:00:35', '2021-10-21 14:00:35'),
(917, 1, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:01:12', '2021-10-21 14:01:12'),
(918, 1, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:01:27', '2021-10-21 14:01:27'),
(919, 1, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:01:36', '2021-10-21 14:01:36'),
(920, 1, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:01:46', '2021-10-21 14:01:46'),
(921, 1, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:02:39', '2021-10-21 14:02:39'),
(922, 1, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:03:11', '2021-10-21 14:03:11'),
(923, 4, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-21 14:03:53', '2021-10-21 14:03:53'),
(924, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 14:03:59', '2021-10-21 14:03:59'),
(925, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:04:53', '2021-10-21 14:04:53'),
(926, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 14:06:36', '2021-10-21 14:06:36'),
(927, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 14:07:48', '2021-10-21 14:07:48'),
(928, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:10:53', '2021-10-21 14:10:53'),
(929, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:11:01', '2021-10-21 14:11:01'),
(930, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:11:45', '2021-10-21 14:11:45'),
(931, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:12:23', '2021-10-21 14:12:23'),
(932, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:13:25', '2021-10-21 14:13:25'),
(933, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:14:32', '2021-10-21 14:14:32'),
(934, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:15:23', '2021-10-21 14:15:23'),
(935, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 14:16:39', '2021-10-21 14:16:39'),
(936, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:17:13', '2021-10-21 14:17:13'),
(937, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:17:52', '2021-10-21 14:17:52'),
(938, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:18:39', '2021-10-21 14:18:39'),
(939, 4, 'admin/form-sr4s/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 14:18:58', '2021-10-21 14:18:58'),
(940, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 14:19:01', '2021-10-21 14:19:01'),
(941, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:19:23', '2021-10-21 14:19:23'),
(942, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:20:11', '2021-10-21 14:20:11'),
(943, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:21:43', '2021-10-21 14:21:43'),
(944, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:22:09', '2021-10-21 14:22:09'),
(945, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:22:46', '2021-10-21 14:22:46'),
(946, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:23:08', '2021-10-21 14:23:08'),
(947, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:23:42', '2021-10-21 14:23:42'),
(948, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:23:53', '2021-10-21 14:23:53'),
(949, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 14:26:28', '2021-10-21 14:26:28'),
(950, 1, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:26:39', '2021-10-21 14:26:39'),
(951, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:27:49', '2021-10-21 14:27:49'),
(952, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 14:31:16', '2021-10-21 14:31:16'),
(953, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 14:31:19', '2021-10-21 14:31:19'),
(954, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 14:31:46', '2021-10-21 14:31:46'),
(955, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 14:31:48', '2021-10-21 14:31:48'),
(956, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 14:31:56', '2021-10-21 14:31:56'),
(957, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 14:32:32', '2021-10-21 14:32:32'),
(958, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:33:03', '2021-10-21 14:33:03'),
(959, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 14:33:26', '2021-10-21 14:33:26'),
(960, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 14:33:42', '2021-10-21 14:33:42'),
(961, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '[]', '2021-10-21 14:34:22', '2021-10-21 14:34:22'),
(962, 4, 'admin/form-sr4s/3', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 14:34:50', '2021-10-21 14:34:50'),
(963, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-21 14:34:58', '2021-10-21 14:34:58'),
(964, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:20:40', '2021-10-22 02:20:40'),
(965, 1, 'admin/auth/setting', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:20:44', '2021-10-22 02:20:44'),
(966, 1, 'admin/auth/setting', 'PUT', '127.0.0.1', '{\"name\":\"Administrator\",\"password\":\"admin\",\"password_confirmation\":\"admin\",\"_token\":\"DPBzOc66R0x77u16Qnou2djXCEVHJRz3VQjjywph\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\"}', '2021-10-22 02:20:53', '2021-10-22 02:20:53'),
(967, 1, 'admin/auth/setting', 'GET', '127.0.0.1', '[]', '2021-10-22 02:20:54', '2021-10-22 02:20:54'),
(968, 1, 'admin/auth/setting', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:21:00', '2021-10-22 02:21:00');
INSERT INTO `admin_operation_log` (`id`, `user_id`, `path`, `method`, `ip`, `input`, `created_at`, `updated_at`) VALUES
(969, 1, 'admin/auth/setting', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:21:02', '2021-10-22 02:21:02'),
(970, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:21:23', '2021-10-22 02:21:23'),
(971, 1, 'admin/auth/menu/10/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:21:32', '2021-10-22 02:21:32'),
(972, 1, 'admin/auth/menu/10', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"My Profile\",\"icon\":\"fa-user-md\",\"uri\":\"auth\\/setting\",\"roles\":[null],\"permission\":null,\"_token\":\"DPBzOc66R0x77u16Qnou2djXCEVHJRz3VQjjywph\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/menu\"}', '2021-10-22 02:21:42', '2021-10-22 02:21:42'),
(973, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-22 02:21:43', '2021-10-22 02:21:43'),
(974, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:21:46', '2021-10-22 02:21:46'),
(975, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:21:50', '2021-10-22 02:21:50'),
(976, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:21:52', '2021-10-22 02:21:52'),
(977, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-22 02:21:54', '2021-10-22 02:21:54'),
(978, 1, 'admin/auth/setting', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:21:57', '2021-10-22 02:21:57'),
(979, 1, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:31:05', '2021-10-22 02:31:05'),
(980, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-22 02:31:37', '2021-10-22 02:31:37'),
(981, 1, 'admin/auth/users', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:32:34', '2021-10-22 02:32:34'),
(982, 1, 'admin/media', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:32:44', '2021-10-22 02:32:44'),
(983, 1, 'admin/auth/users', 'GET', '127.0.0.1', '[]', '2021-10-22 02:32:45', '2021-10-22 02:32:45'),
(984, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:32:51', '2021-10-22 02:32:51'),
(985, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:32:58', '2021-10-22 02:32:58'),
(986, 4, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:33:28', '2021-10-22 02:33:28'),
(987, 3, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-22 02:34:02', '2021-10-22 02:34:02'),
(988, 1, 'admin/_handle_action_', 'POST', '127.0.0.1', '{\"_key\":\"3\",\"_model\":\"App_Models_FormSr4\",\"_token\":\"s57KYgBa3jz3VnwAjSWeD8yBJspqwtNFHD61P1fC\",\"_action\":\"Encore_Admin_Grid_Actions_Delete\",\"_input\":\"true\"}', '2021-10-22 02:34:38', '2021-10-22 02:34:38'),
(989, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:34:39', '2021-10-22 02:34:39'),
(990, 3, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:34:45', '2021-10-22 02:34:45'),
(991, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:34:49', '2021-10-22 02:34:49'),
(992, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:37:33', '2021-10-22 02:37:33'),
(993, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:37:36', '2021-10-22 02:37:36'),
(994, 3, 'admin/form-sr4s', 'POST', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"expirience_in\":\"5\",\"years_of_expirience\":\"1\",\"dealers_in\":\"Other\",\"dealers_in_other\":\"Floriculture\",\"processing_of\":\"Horticulture crops\",\"marketing_of\":\"Agriculture crops\",\"have_adequate_land\":\"1\",\"land_size\":\"50\",\"have_adequate_equipment\":\"1\",\"eqipment\":\"Tractor\",\"have_contractual_agreement\":\"1\",\"have_adequate_field_officers\":\"1\",\"have_conversant_seed_matters\":\"1\",\"souce_of_seed\":\"Other\",\"souce_of_seed_other\":\"Bwambale Muhidin\",\"have_adequate_land_for_production\":\"1\",\"have_internal_quality_program\":\"0\",\"accept_declaration\":\"1\",\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr4s\"}', '2021-10-22 02:41:08', '2021-10-22 02:41:08'),
(995, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-22 02:41:08', '2021-10-22 02:41:08'),
(996, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:41:15', '2021-10-22 02:41:15'),
(997, 3, 'admin/form-sr4s/4', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:41:53', '2021-10-22 02:41:53'),
(998, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:42:07', '2021-10-22 02:42:07'),
(999, 1, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:42:19', '2021-10-22 02:42:19'),
(1000, 1, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:42:25', '2021-10-22 02:42:25'),
(1001, 2, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-22 02:42:36', '2021-10-22 02:42:36'),
(1002, 2, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-22 02:42:52', '2021-10-22 02:42:52'),
(1003, 2, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:43:03', '2021-10-22 02:43:03'),
(1004, 2, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\",\"_sort\":{\"column\":\"status\",\"type\":\"desc\"}}', '2021-10-22 02:43:11', '2021-10-22 02:43:11'),
(1005, 2, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\",\"_sort\":{\"column\":\"status\",\"type\":\"asc\"}}', '2021-10-22 02:43:15', '2021-10-22 02:43:15'),
(1006, 2, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\",\"_sort\":{\"column\":\"valid_until\",\"type\":\"desc\"}}', '2021-10-22 02:43:19', '2021-10-22 02:43:19'),
(1007, 2, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\",\"_sort\":{\"column\":\"valid_until\",\"type\":\"asc\"}}', '2021-10-22 02:43:20', '2021-10-22 02:43:20'),
(1008, 2, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\",\"_sort\":{\"column\":\"inspector\",\"type\":\"desc\"}}', '2021-10-22 02:43:26', '2021-10-22 02:43:26'),
(1009, 2, 'admin/form-sr4s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:43:55', '2021-10-22 02:43:55'),
(1010, 2, 'admin/form-sr4s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"status\":\"2\",\"inspector\":\"4\",\"_token\":\"C0fBrXJNfNcz077ly7dy1q1vKZaqvPJyUSQAtZY8\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr4s?&_sort%5Bcolumn%5D=inspector&_sort%5Btype%5D=desc\"}', '2021-10-22 02:44:34', '2021-10-22 02:44:34'),
(1011, 2, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_sort\":{\"column\":\"inspector\",\"type\":\"desc\"}}', '2021-10-22 02:44:34', '2021-10-22 02:44:34'),
(1012, 2, 'admin/form-sr4s/4', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:45:08', '2021-10-22 02:45:08'),
(1013, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:45:16', '2021-10-22 02:45:16'),
(1014, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:45:33', '2021-10-22 02:45:33'),
(1015, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:45:37', '2021-10-22 02:45:37'),
(1016, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:46:23', '2021-10-22 02:46:23'),
(1017, 3, 'admin/form-sr4s/4', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:46:46', '2021-10-22 02:46:46'),
(1018, 2, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:46:51', '2021-10-22 02:46:51'),
(1019, 2, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:47:07', '2021-10-22 02:47:07'),
(1020, 4, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-22 02:47:26', '2021-10-22 02:47:26'),
(1021, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:47:34', '2021-10-22 02:47:34'),
(1022, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:48:19', '2021-10-22 02:48:19'),
(1023, 4, 'admin/form-sr4s/4', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:48:38', '2021-10-22 02:48:38'),
(1024, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:48:41', '2021-10-22 02:48:41'),
(1025, 4, 'admin/form-sr4s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:48:46', '2021-10-22 02:48:46'),
(1026, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:48:49', '2021-10-22 02:48:49'),
(1027, 4, 'admin/form-sr4s/4', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:48:56', '2021-10-22 02:48:56'),
(1028, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:49:18', '2021-10-22 02:49:18'),
(1029, 4, 'admin/form-sr4s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:49:22', '2021-10-22 02:49:22'),
(1030, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:49:39', '2021-10-22 02:49:39'),
(1031, 4, 'admin/form-sr4s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:49:48', '2021-10-22 02:49:48'),
(1032, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:50:04', '2021-10-22 02:50:04'),
(1033, 4, 'admin/form-sr4s/4', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:50:08', '2021-10-22 02:50:08'),
(1034, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:50:16', '2021-10-22 02:50:16'),
(1035, 4, 'admin/form-sr4s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:50:23', '2021-10-22 02:50:23'),
(1036, 4, 'admin/form-sr4s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"status\":\"3\",\"status_comment\":\"submitted wrong receipt\",\"_token\":\"nXgxuxIrmYxGwiUG5YyWHqhUvW2SZal4iE3B6jrZ\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr4s\"}', '2021-10-22 02:51:28', '2021-10-22 02:51:28'),
(1037, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-22 02:51:29', '2021-10-22 02:51:29'),
(1038, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:51:40', '2021-10-22 02:51:40'),
(1039, 3, 'admin/form-sr4s/4', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:51:50', '2021-10-22 02:51:50'),
(1040, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:51:59', '2021-10-22 02:51:59'),
(1041, 3, 'admin/form-sr4s/4', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:52:07', '2021-10-22 02:52:07'),
(1042, 4, 'admin/form-sr4s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:52:17', '2021-10-22 02:52:17'),
(1043, 4, 'admin/form-sr4s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"status\":\"5\",\"valid_from\":\"2021-10-01\",\"valid_until\":\"2022-11-01\",\"_token\":\"nXgxuxIrmYxGwiUG5YyWHqhUvW2SZal4iE3B6jrZ\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr4s\"}', '2021-10-22 02:53:07', '2021-10-22 02:53:07'),
(1044, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-22 02:53:07', '2021-10-22 02:53:07'),
(1045, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:53:18', '2021-10-22 02:53:18'),
(1046, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:53:59', '2021-10-22 02:53:59'),
(1047, 3, 'admin/form-sr4s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:54:42', '2021-10-22 02:54:42'),
(1048, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:54:49', '2021-10-22 02:54:49'),
(1049, 4, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:55:08', '2021-10-22 02:55:08'),
(1050, 4, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:55:16', '2021-10-22 02:55:16'),
(1051, 2, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-22 02:55:26', '2021-10-22 02:55:26'),
(1052, 2, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 02:55:30', '2021-10-22 02:55:30'),
(1053, 2, 'admin/auth/logout', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 03:45:39', '2021-10-22 03:45:39'),
(1054, 1, 'admin', 'GET', '127.0.0.1', '[]', '2021-10-22 03:45:58', '2021-10-22 03:45:58'),
(1055, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 03:46:13', '2021-10-22 03:46:13'),
(1056, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"parent_id\":\"12\",\"title\":\"SR6 - Seed grower\",\"icon\":\"fa-wpforms\",\"uri\":\"form-sr6s\",\"roles\":[null],\"permission\":null,\"_token\":\"VBycNJb7uDEUHOndR2SWZIpxHByioKE684Z3rTKD\"}', '2021-10-22 03:47:14', '2021-10-22 03:47:14'),
(1057, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-22 03:47:14', '2021-10-22 03:47:14'),
(1058, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"_token\":\"VBycNJb7uDEUHOndR2SWZIpxHByioKE684Z3rTKD\",\"_order\":\"[{\\\"id\\\":1},{\\\"id\\\":12,\\\"children\\\":[{\\\"id\\\":13},{\\\"id\\\":15}]},{\\\"id\\\":2,\\\"children\\\":[{\\\"id\\\":3},{\\\"id\\\":4},{\\\"id\\\":5},{\\\"id\\\":6},{\\\"id\\\":7}]},{\\\"id\\\":10},{\\\"id\\\":8}]\"}', '2021-10-22 03:47:22', '2021-10-22 03:47:22'),
(1059, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 03:47:22', '2021-10-22 03:47:22'),
(1060, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2021-10-22 03:47:24', '2021-10-22 03:47:24'),
(1061, 1, 'admin/form-sr6s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 03:47:35', '2021-10-22 03:47:35'),
(1062, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '[]', '2021-10-22 03:47:43', '2021-10-22 03:47:43'),
(1063, 3, 'admin/form-sr6s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 03:47:46', '2021-10-22 03:47:46'),
(1064, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 03:47:51', '2021-10-22 03:47:51'),
(1065, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:48:06', '2021-10-22 03:48:06'),
(1066, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 03:54:56', '2021-10-22 03:54:56'),
(1067, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:54:57', '2021-10-22 03:54:57'),
(1068, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:54:57', '2021-10-22 03:54:57'),
(1069, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:54:58', '2021-10-22 03:54:58'),
(1070, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:54:58', '2021-10-22 03:54:58'),
(1071, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:54:58', '2021-10-22 03:54:58'),
(1072, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:54:59', '2021-10-22 03:54:59'),
(1073, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:54:59', '2021-10-22 03:54:59'),
(1074, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:55:00', '2021-10-22 03:55:00'),
(1075, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:55:01', '2021-10-22 03:55:01'),
(1076, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:55:01', '2021-10-22 03:55:01'),
(1077, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:55:01', '2021-10-22 03:55:01'),
(1078, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:55:02', '2021-10-22 03:55:02'),
(1079, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:55:02', '2021-10-22 03:55:02'),
(1080, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:55:03', '2021-10-22 03:55:03'),
(1081, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:55:03', '2021-10-22 03:55:03'),
(1082, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:55:04', '2021-10-22 03:55:04'),
(1083, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:55:04', '2021-10-22 03:55:04'),
(1084, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:55:05', '2021-10-22 03:55:05'),
(1085, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:55:05', '2021-10-22 03:55:05'),
(1086, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:55:05', '2021-10-22 03:55:05'),
(1087, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:55:06', '2021-10-22 03:55:06'),
(1088, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:55:48', '2021-10-22 03:55:48'),
(1089, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 03:56:01', '2021-10-22 03:56:01'),
(1090, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:56:04', '2021-10-22 03:56:04'),
(1091, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 03:56:06', '2021-10-22 03:56:06'),
(1092, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 03:56:19', '2021-10-22 03:56:19'),
(1093, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 03:57:11', '2021-10-22 03:57:11'),
(1094, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 03:58:56', '2021-10-22 03:58:56'),
(1095, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 03:59:12', '2021-10-22 03:59:12'),
(1096, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:00:06', '2021-10-22 04:00:06'),
(1097, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:00:54', '2021-10-22 04:00:54'),
(1098, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:03:55', '2021-10-22 04:03:55'),
(1099, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:06:06', '2021-10-22 04:06:06'),
(1100, 3, 'admin/form-sr6s', 'POST', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"dealers_in\":{\"new_1\":{\"key\":\"11\",\"value\":\"11\",\"desc\":\"111\",\"_remove_\":\"0\"}},\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\"}', '2021-10-22 04:06:40', '2021-10-22 04:06:40'),
(1101, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 04:06:40', '2021-10-22 04:06:40'),
(1102, 3, 'admin/form-sr6s', 'POST', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"dealers_in\":{\"new_1\":{\"key\":\"11\",\"value\":\"11\",\"desc\":\"111\",\"_remove_\":\"0\"}},\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\"}', '2021-10-22 04:12:00', '2021-10-22 04:12:00'),
(1103, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 04:12:00', '2021-10-22 04:12:00'),
(1104, 3, 'admin/form-sr6s', 'POST', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"dealers_in\":{\"new_1\":{\"key\":\"11\",\"value\":\"11\",\"desc\":\"111\",\"_remove_\":\"0\"}},\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\"}', '2021-10-22 04:12:23', '2021-10-22 04:12:23'),
(1105, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:12:24', '2021-10-22 04:12:24'),
(1106, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/create\"}', '2021-10-22 04:13:15', '2021-10-22 04:13:15'),
(1107, 3, 'admin/form-sr6s/1', 'GET', '127.0.0.1', '[]', '2021-10-22 04:13:54', '2021-10-22 04:13:54'),
(1108, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:14:03', '2021-10-22 04:14:03'),
(1109, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/1\"}', '2021-10-22 04:14:06', '2021-10-22 04:14:06'),
(1110, 3, 'admin/form-sr6s/1', 'GET', '127.0.0.1', '[]', '2021-10-22 04:14:06', '2021-10-22 04:14:06'),
(1111, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"2\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/create\"}', '2021-10-22 04:14:18', '2021-10-22 04:14:18'),
(1112, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 04:14:18', '2021-10-22 04:14:18'),
(1113, 3, 'admin/form-sr6s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:14:33', '2021-10-22 04:14:33'),
(1114, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:14:37', '2021-10-22 04:14:37'),
(1115, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\"}', '2021-10-22 04:14:42', '2021-10-22 04:14:42'),
(1116, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:14:46', '2021-10-22 04:14:46'),
(1117, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"dealers_in\":{\"new_2\":{\"key\":\"asas\",\"value\":\"22\",\"desc\":\"asas\",\"_remove_\":\"0\"}},\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:15:14', '2021-10-22 04:15:14'),
(1118, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:15:31', '2021-10-22 04:15:31'),
(1119, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:15:36', '2021-10-22 04:15:36'),
(1120, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:15:37', '2021-10-22 04:15:37'),
(1121, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"dealers_in\":{\"new_1\":{\"key\":\"11\",\"value\":\"11\",\"desc\":\"111\",\"_remove_\":\"0\"}},\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:17:07', '2021-10-22 04:17:07'),
(1122, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:17:48', '2021-10-22 04:17:48'),
(1123, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:17:52', '2021-10-22 04:17:52'),
(1124, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:18:02', '2021-10-22 04:18:02'),
(1125, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:18:06', '2021-10-22 04:18:06'),
(1126, 3, 'admin/form-sr6s/1', 'GET', '127.0.0.1', '[]', '2021-10-22 04:18:26', '2021-10-22 04:18:26'),
(1127, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:18:31', '2021-10-22 04:18:31'),
(1128, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/1\"}', '2021-10-22 04:18:36', '2021-10-22 04:18:36'),
(1129, 3, 'admin/form-sr6s/1', 'GET', '127.0.0.1', '[]', '2021-10-22 04:18:55', '2021-10-22 04:18:55'),
(1130, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:18:59', '2021-10-22 04:18:59'),
(1131, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"dealers_in\":{\"new_1\":{\"key\":\"11\",\"value\":\"11\",\"desc\":\"111\",\"_remove_\":\"0\"}},\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/1\"}', '2021-10-22 04:19:09', '2021-10-22 04:19:09'),
(1132, 3, 'admin/form-sr6s/1', 'GET', '127.0.0.1', '[]', '2021-10-22 04:19:47', '2021-10-22 04:19:47'),
(1133, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:19:50', '2021-10-22 04:19:50'),
(1134, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"dealers_in\":{\"new_1\":{\"key\":\"11\",\"value\":\"11\",\"desc\":\"111\",\"_remove_\":\"0\"}},\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/1\"}', '2021-10-22 04:20:01', '2021-10-22 04:20:01'),
(1135, 3, 'admin/form-sr6s/1', 'GET', '127.0.0.1', '[]', '2021-10-22 04:20:32', '2021-10-22 04:20:32'),
(1136, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:20:35', '2021-10-22 04:20:35'),
(1137, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"dealers_in\":{\"new_1\":{\"key\":\"11\",\"value\":\"11\",\"desc\":\"111\",\"_remove_\":\"0\"}},\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/1\"}', '2021-10-22 04:20:48', '2021-10-22 04:20:48'),
(1138, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:20:49', '2021-10-22 04:20:49'),
(1139, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:21:15', '2021-10-22 04:21:15'),
(1140, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:23:02', '2021-10-22 04:23:02'),
(1141, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"dealers_in\":{\"new_1\":{\"key\":\"1\",\"value\":\"test\",\"desc\":\"Test 2\",\"_remove_\":\"0\"}},\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:23:11', '2021-10-22 04:23:11'),
(1142, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:23:11', '2021-10-22 04:23:11'),
(1143, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"dealers_in\":{\"new_1\":{\"key\":\"1\",\"value\":\"test\",\"desc\":\"Test 4\",\"_remove_\":\"0\"}},\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:23:29', '2021-10-22 04:23:29'),
(1144, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:23:30', '2021-10-22 04:23:30'),
(1145, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:23:32', '2021-10-22 04:23:32'),
(1146, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"dealers_in\":{\"new_1\":{\"key\":\"1\",\"value\":\"test\",\"desc\":\"Test 2\",\"_remove_\":\"0\"}},\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:24:05', '2021-10-22 04:24:05'),
(1147, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:24:06', '2021-10-22 04:24:06'),
(1148, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"dealers_in\":{\"new_1\":{\"key\":\"1\",\"value\":\"test\",\"desc\":\"Test 2\",\"_remove_\":\"0\"}},\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:27:01', '2021-10-22 04:27:01'),
(1149, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:27:02', '2021-10-22 04:27:02'),
(1150, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:27:12', '2021-10-22 04:27:12'),
(1151, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:27:18', '2021-10-22 04:27:18'),
(1152, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:27:18', '2021-10-22 04:27:18'),
(1153, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:27:31', '2021-10-22 04:27:31'),
(1154, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:27:35', '2021-10-22 04:27:35'),
(1155, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:27:35', '2021-10-22 04:27:35'),
(1156, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:27:50', '2021-10-22 04:27:50'),
(1157, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:27:57', '2021-10-22 04:27:57'),
(1158, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:27:57', '2021-10-22 04:27:57'),
(1159, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:29:02', '2021-10-22 04:29:02'),
(1160, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:29:03', '2021-10-22 04:29:03'),
(1161, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:29:45', '2021-10-22 04:29:45'),
(1162, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Romina...\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:29:49', '2021-10-22 04:29:49'),
(1163, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:29:50', '2021-10-22 04:29:50'),
(1164, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:32:19', '2021-10-22 04:32:19'),
(1165, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Romina...\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:32:24', '2021-10-22 04:32:24'),
(1166, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:32:24', '2021-10-22 04:32:24'),
(1167, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:32:41', '2021-10-22 04:32:41'),
(1168, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Romina...\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:32:44', '2021-10-22 04:32:44'),
(1169, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:32:45', '2021-10-22 04:32:45'),
(1170, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:33:08', '2021-10-22 04:33:08'),
(1171, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:33:09', '2021-10-22 04:33:09'),
(1172, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:33:12', '2021-10-22 04:33:12'),
(1173, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Romina...\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:33:17', '2021-10-22 04:33:17'),
(1174, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:33:17', '2021-10-22 04:33:17'),
(1175, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Romina...\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:33:45', '2021-10-22 04:33:45'),
(1176, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:33:46', '2021-10-22 04:33:46'),
(1177, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:33:57', '2021-10-22 04:33:57');
INSERT INTO `admin_operation_log` (`id`, `user_id`, `path`, `method`, `ip`, `input`, `created_at`, `updated_at`) VALUES
(1178, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Romina...\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:34:00', '2021-10-22 04:34:00'),
(1179, 3, 'admin/form-sr6s/1', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:34:20', '2021-10-22 04:34:20'),
(1180, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:34:25', '2021-10-22 04:34:25'),
(1181, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Romina...\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/1\"}', '2021-10-22 04:34:28', '2021-10-22 04:34:28'),
(1182, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:34:29', '2021-10-22 04:34:29'),
(1183, 3, 'admin/form-sr6s/1', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Romina...\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:06:06\",\"valid_until\":\"2021-10-22 07:06:06\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:35:58', '2021-10-22 04:35:58'),
(1184, 3, 'admin/form-sr6s/1/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:35:58', '2021-10-22 04:35:58'),
(1185, 3, 'admin/form-sr6s/1', 'DELETE', '127.0.0.1', '{\"_method\":\"delete\",\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\"}', '2021-10-22 04:36:05', '2021-10-22 04:36:05'),
(1186, 3, 'admin/form-sr6s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:36:06', '2021-10-22 04:36:06'),
(1187, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:36:09', '2021-10-22 04:36:09'),
(1188, 3, 'admin/form-sr6s', 'POST', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"22\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:36:09\",\"valid_until\":\"2021-10-22 07:36:09\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\"}', '2021-10-22 04:36:25', '2021-10-22 04:36:25'),
(1189, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:36:26', '2021-10-22 04:36:26'),
(1190, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:36:56', '2021-10-22 04:36:56'),
(1191, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:37:07', '2021-10-22 04:37:07'),
(1192, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:37:11', '2021-10-22 04:37:11'),
(1193, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:37:55', '2021-10-22 04:37:55'),
(1194, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:38:33', '2021-10-22 04:38:33'),
(1195, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:38:47', '2021-10-22 04:38:47'),
(1196, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:38:59', '2021-10-22 04:38:59'),
(1197, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:42:08', '2021-10-22 04:42:08'),
(1198, 3, 'admin/form-sr6s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"[{\\\"name\\\":\\\"Muhindo\\\",\\\"age\\\":\\\"12\\\",\\\"gender\\\":\\\"Make\\\"}]\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"22\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:36:09\",\"valid_until\":\"2021-10-22 07:36:09\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:42:23', '2021-10-22 04:42:23'),
(1199, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:42:23', '2021-10-22 04:42:23'),
(1200, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:42:42', '2021-10-22 04:42:42'),
(1201, 3, 'admin/form-sr6s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"[{\\\"name\\\":\\\"Muhindo\\\",\\\"age\\\":\\\"12\\\",\\\"gender\\\":\\\"Make\\\"}]\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"22\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:36:09\",\"valid_until\":\"2021-10-22 07:36:09\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:42:47', '2021-10-22 04:42:47'),
(1202, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:42:48', '2021-10-22 04:42:48'),
(1203, 3, 'admin/form-sr6s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Romina...\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"22\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:36:09\",\"valid_until\":\"2021-10-22 07:36:09\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:43:11', '2021-10-22 04:43:11'),
(1204, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:43:11', '2021-10-22 04:43:11'),
(1205, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 04:43:47', '2021-10-22 04:43:47'),
(1206, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:44:06', '2021-10-22 04:44:06'),
(1207, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:44:18', '2021-10-22 04:44:18'),
(1208, 3, 'admin/form-sr6s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"{\\\"name\\\":\\\"Muhindo\\\",\\\"age\\\":\\\"12\\\",\\\"gender\\\":\\\"Make\\\"}\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"22\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:36:09\",\"valid_until\":\"2021-10-22 07:36:09\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:44:34', '2021-10-22 04:44:34'),
(1209, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:44:34', '2021-10-22 04:44:34'),
(1210, 3, 'admin/form-sr6s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"{\\\"key\\\":\\\"Muhindo\\\",\\\"value\\\":\\\"12\\\",\\\"desc\\\":\\\"Make\\\"}\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"22\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:36:09\",\"valid_until\":\"2021-10-22 07:36:09\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:44:51', '2021-10-22 04:44:51'),
(1211, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:44:51', '2021-10-22 04:44:51'),
(1212, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:45:24', '2021-10-22 04:45:24'),
(1213, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:52:58', '2021-10-22 04:52:58'),
(1214, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:55:38', '2021-10-22 04:55:38'),
(1215, 3, 'admin/form-sr6s/2', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"[{\\\"key\\\":\\\"Muhindo\\\",\\\"value\\\":\\\"12\\\",\\\"desc\\\":\\\"Make\\\"}]\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"22\",\"dealers_in\":{\"new_1\":{\"key\":\"1\",\"value\":\"test\",\"desc\":null,\"_remove_\":\"0\"}},\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 07:36:09\",\"valid_until\":\"2021-10-22 07:36:09\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 04:55:45', '2021-10-22 04:55:45'),
(1216, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:55:45', '2021-10-22 04:55:45'),
(1217, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 04:55:54', '2021-10-22 04:55:54'),
(1218, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:26:41', '2021-10-22 05:26:41'),
(1219, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:27:21', '2021-10-22 05:27:21'),
(1220, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:27:40', '2021-10-22 05:27:40'),
(1221, 1, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:29:10', '2021-10-22 05:29:10'),
(1222, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:29:21', '2021-10-22 05:29:21'),
(1223, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:29:45', '2021-10-22 05:29:45'),
(1224, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:29:51', '2021-10-22 05:29:51'),
(1225, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:30:06', '2021-10-22 05:30:06'),
(1226, 1, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:31:13', '2021-10-22 05:31:13'),
(1227, 1, 'admin/form-sr6s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 05:31:20', '2021-10-22 05:31:20'),
(1228, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 05:31:32', '2021-10-22 05:31:32'),
(1229, 3, 'admin/form-sr6s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 05:31:32', '2021-10-22 05:31:32'),
(1230, 3, 'admin/form-sr6s/2/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 05:31:37', '2021-10-22 05:31:37'),
(1231, 3, 'admin/form-sr6s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 05:31:41', '2021-10-22 05:31:41'),
(1232, 3, 'admin/_handle_action_', 'POST', '127.0.0.1', '{\"_key\":\"2\",\"_model\":\"App_Models_FormSr6\",\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"_action\":\"Encore_Admin_Grid_Actions_Delete\",\"_input\":\"true\"}', '2021-10-22 05:31:49', '2021-10-22 05:31:49'),
(1233, 3, 'admin/form-sr6s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 05:31:49', '2021-10-22 05:31:49'),
(1234, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 05:31:53', '2021-10-22 05:31:53'),
(1235, 3, 'admin/form-sr6s', 'POST', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"11\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 08:31:53\",\"valid_until\":\"2021-10-22 08:31:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\"}', '2021-10-22 05:32:08', '2021-10-22 05:32:08'),
(1236, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:32:08', '2021-10-22 05:32:08'),
(1237, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:32:10', '2021-10-22 05:32:10'),
(1238, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:34:09', '2021-10-22 05:34:09'),
(1239, 3, 'admin/form-sr6s/3', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"11\",\"dealers_in\":{\"new_1\":{\"Crops\":\"Cassava\",\"Variety\":\"Beans\",\"Ha\":\"Beans simple\",\"Origin\":\"Socue..\",\"_remove_\":\"0\"}},\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 08:31:53\",\"valid_until\":\"2021-10-22 08:31:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"_method\":\"PUT\"}', '2021-10-22 05:34:24', '2021-10-22 05:34:24'),
(1240, 3, 'admin/form-sr6s', 'GET', '127.0.0.1', '[]', '2021-10-22 05:34:24', '2021-10-22 05:34:24'),
(1241, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 05:34:31', '2021-10-22 05:34:31'),
(1242, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:43:47', '2021-10-22 05:43:47'),
(1243, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 05:44:14', '2021-10-22 05:44:14'),
(1244, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:46:14', '2021-10-22 05:46:14'),
(1245, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:46:23', '2021-10-22 05:46:23'),
(1246, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 05:46:26', '2021-10-22 05:46:26'),
(1247, 3, 'admin/form-sr6s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 05:46:27', '2021-10-22 05:46:27'),
(1248, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 05:47:10', '2021-10-22 05:47:10'),
(1249, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:47:43', '2021-10-22 05:47:43'),
(1250, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:48:04', '2021-10-22 05:48:04'),
(1251, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:48:07', '2021-10-22 05:48:07'),
(1252, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:48:13', '2021-10-22 05:48:13'),
(1253, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:48:30', '2021-10-22 05:48:30'),
(1254, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:48:50', '2021-10-22 05:48:50'),
(1255, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:49:03', '2021-10-22 05:49:03'),
(1256, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 05:49:21', '2021-10-22 05:49:21'),
(1257, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:49:25', '2021-10-22 05:49:25'),
(1258, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:52:22', '2021-10-22 05:52:22'),
(1259, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:53:13', '2021-10-22 05:53:13'),
(1260, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:53:16', '2021-10-22 05:53:16'),
(1261, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:53:29', '2021-10-22 05:53:29'),
(1262, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:53:37', '2021-10-22 05:53:37'),
(1263, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:55:07', '2021-10-22 05:55:07'),
(1264, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:55:16', '2021-10-22 05:55:16'),
(1265, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:56:08', '2021-10-22 05:56:08'),
(1266, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:56:22', '2021-10-22 05:56:22'),
(1267, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:56:33', '2021-10-22 05:56:33'),
(1268, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:56:45', '2021-10-22 05:56:45'),
(1269, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:56:50', '2021-10-22 05:56:50'),
(1270, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:57:00', '2021-10-22 05:57:00'),
(1271, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:57:43', '2021-10-22 05:57:43'),
(1272, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 05:58:37', '2021-10-22 05:58:37'),
(1273, 3, 'admin/form-sr6s/3/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 06:03:21', '2021-10-22 06:03:21'),
(1274, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 06:03:39', '2021-10-22 06:03:39'),
(1275, 3, 'admin/form-sr6s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 06:03:40', '2021-10-22 06:03:40'),
(1276, 3, 'admin/_handle_action_', 'POST', '127.0.0.1', '{\"_key\":\"3\",\"_model\":\"App_Models_FormSr6\",\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"_action\":\"Encore_Admin_Grid_Actions_Delete\",\"_input\":\"true\"}', '2021-10-22 06:03:58', '2021-10-22 06:03:58'),
(1277, 3, 'admin/form-sr6s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 06:03:58', '2021-10-22 06:03:58'),
(1278, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 06:04:01', '2021-10-22 06:04:01'),
(1279, 3, 'admin/form-sr6s', 'POST', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"22\",\"dealers_in\":{\"keys\":[\"love\",\"sex\"],\"values\":[\"blinde\",\"good\"]},\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 09:04:01\",\"valid_until\":\"2021-10-22 09:04:01\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\"}', '2021-10-22 06:04:26', '2021-10-22 06:04:26'),
(1280, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 06:04:27', '2021-10-22 06:04:27'),
(1281, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 06:04:35', '2021-10-22 06:04:35'),
(1282, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 06:06:20', '2021-10-22 06:06:20'),
(1283, 3, 'admin/form-sr6s', 'POST', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"2\",\"years_of_expirience\":\"333\",\"dealers_in\":{\"new_1\":{\"key\":\"11\",\"value\":\"11\",\"desc\":\"111\",\"romina\":\"asas\",\"_remove_\":\"0\"}},\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 09:06:20\",\"valid_until\":\"2021-10-22 09:06:20\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\"}', '2021-10-22 06:06:55', '2021-10-22 06:06:55'),
(1284, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 06:06:55', '2021-10-22 06:06:55'),
(1285, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 06:23:56', '2021-10-22 06:23:56'),
(1286, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 06:50:37', '2021-10-22 06:50:37'),
(1287, 3, 'admin/form-sr6s', 'POST', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"2\",\"dealers_in\":{\"new_1\":{\"key\":\"11\",\"value\":\"11\",\"desc\":\"111\",\"romina\":\"asas\",\"_remove_\":\"0\"}},\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 09:50:37\",\"valid_until\":\"2021-10-22 09:50:37\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\"}', '2021-10-22 06:51:06', '2021-10-22 06:51:06'),
(1288, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 06:51:06', '2021-10-22 06:51:06'),
(1289, 1, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 07:02:37', '2021-10-22 07:02:37'),
(1290, 1, 'admin/form-sr6s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 07:02:40', '2021-10-22 07:02:40'),
(1291, 1, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 07:02:42', '2021-10-22 07:02:42'),
(1292, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 07:02:55', '2021-10-22 07:02:55'),
(1293, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 07:03:18', '2021-10-22 07:03:18'),
(1294, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 07:59:59', '2021-10-22 07:59:59'),
(1295, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 08:02:27', '2021-10-22 08:02:27'),
(1296, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 08:11:30', '2021-10-22 08:11:30'),
(1297, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 08:15:03', '2021-10-22 08:15:03'),
(1298, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 08:20:29', '2021-10-22 08:20:29'),
(1299, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 08:20:46', '2021-10-22 08:20:46'),
(1300, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 08:23:11', '2021-10-22 08:23:11'),
(1301, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 08:23:40', '2021-10-22 08:23:40'),
(1302, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 08:23:57', '2021-10-22 08:23:57'),
(1303, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 08:25:18', '2021-10-22 08:25:18'),
(1304, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 08:25:26', '2021-10-22 08:25:26'),
(1305, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 08:28:29', '2021-10-22 08:28:29'),
(1306, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 08:33:29', '2021-10-22 08:33:29'),
(1307, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 08:41:13', '2021-10-22 08:41:13'),
(1308, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 08:42:02', '2021-10-22 08:42:02'),
(1309, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 08:42:38', '2021-10-22 08:42:38'),
(1310, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 08:43:31', '2021-10-22 08:43:31'),
(1311, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 08:44:52', '2021-10-22 08:44:52'),
(1312, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 08:51:08', '2021-10-22 08:51:08'),
(1313, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 08:52:51', '2021-10-22 08:52:51'),
(1314, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 08:53:22', '2021-10-22 08:53:22'),
(1315, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 08:53:52', '2021-10-22 08:53:52'),
(1316, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 08:54:45', '2021-10-22 08:54:45'),
(1317, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 08:54:53', '2021-10-22 08:54:53'),
(1318, 3, 'admin/form-sr6s', 'POST', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\"}', '2021-10-22 08:55:34', '2021-10-22 08:55:34'),
(1319, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 08:55:34', '2021-10-22 08:55:34'),
(1320, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 08:57:39', '2021-10-22 08:57:39'),
(1321, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"group-a\":[{\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\"}],\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/create\"}', '2021-10-22 08:58:09', '2021-10-22 08:58:09'),
(1322, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '[]', '2021-10-22 09:01:06', '2021-10-22 09:01:06'),
(1323, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:01:12', '2021-10-22 09:01:12'),
(1324, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:01:50', '2021-10-22 09:01:50'),
(1325, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"group-a\":[{\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\"}],\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/4\"}', '2021-10-22 09:01:55', '2021-10-22 09:01:55'),
(1326, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '[]', '2021-10-22 09:03:21', '2021-10-22 09:03:21'),
(1327, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:03:29', '2021-10-22 09:03:29'),
(1328, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/4\"}', '2021-10-22 09:03:34', '2021-10-22 09:03:34'),
(1329, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:03:34', '2021-10-22 09:03:34'),
(1330, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:04:09', '2021-10-22 09:04:09'),
(1331, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:04:11', '2021-10-22 09:04:11'),
(1332, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/4\"}', '2021-10-22 09:04:30', '2021-10-22 09:04:30'),
(1333, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '[]', '2021-10-22 09:05:57', '2021-10-22 09:05:57'),
(1334, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:06:00', '2021-10-22 09:06:00'),
(1335, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/4\"}', '2021-10-22 09:06:06', '2021-10-22 09:06:06'),
(1336, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:06:07', '2021-10-22 09:06:07'),
(1337, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:06:49', '2021-10-22 09:06:49'),
(1338, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"group_a\":[{\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\"}],\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/4\"}', '2021-10-22 09:06:56', '2021-10-22 09:06:56'),
(1339, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '[]', '2021-10-22 09:07:08', '2021-10-22 09:07:08'),
(1340, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:07:13', '2021-10-22 09:07:13'),
(1341, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/4\"}', '2021-10-22 09:07:18', '2021-10-22 09:07:18'),
(1342, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:07:18', '2021-10-22 09:07:18'),
(1343, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:07:39', '2021-10-22 09:07:39'),
(1344, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"group_a\":[{\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\"}],\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/4\"}', '2021-10-22 09:07:44', '2021-10-22 09:07:44'),
(1345, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '[]', '2021-10-22 09:08:46', '2021-10-22 09:08:46'),
(1346, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:08:50', '2021-10-22 09:08:50'),
(1347, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/4\"}', '2021-10-22 09:08:55', '2021-10-22 09:08:55'),
(1348, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:09:08', '2021-10-22 09:09:08'),
(1349, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 09:09:17', '2021-10-22 09:09:17'),
(1350, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '[]', '2021-10-22 09:12:49', '2021-10-22 09:12:49'),
(1351, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:12:52', '2021-10-22 09:12:52'),
(1352, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"crop\":\"11s\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/4\"}', '2021-10-22 09:13:01', '2021-10-22 09:13:01'),
(1353, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '[]', '2021-10-22 09:13:31', '2021-10-22 09:13:31'),
(1354, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:13:34', '2021-10-22 09:13:34'),
(1355, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/4\"}', '2021-10-22 09:13:38', '2021-10-22 09:13:38'),
(1356, 3, 'admin/form-sr6s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:14:27', '2021-10-22 09:14:27'),
(1357, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:14:29', '2021-10-22 09:14:29'),
(1358, 3, 'admin/form-sr6s', 'POST', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"12\",\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 12:14:29\",\"valid_until\":\"2021-10-22 12:14:29\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\"}', '2021-10-22 09:14:40', '2021-10-22 09:14:40'),
(1359, 3, 'admin/form-sr6s', 'GET', '127.0.0.1', '[]', '2021-10-22 09:15:10', '2021-10-22 09:15:10'),
(1360, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:15:16', '2021-10-22 09:15:16'),
(1361, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\"}', '2021-10-22 09:15:19', '2021-10-22 09:15:19'),
(1362, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:15:23', '2021-10-22 09:15:23'),
(1363, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:15:32', '2021-10-22 09:15:32'),
(1364, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:15:38', '2021-10-22 09:15:38'),
(1365, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:15:44', '2021-10-22 09:15:44'),
(1366, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"group-a\":[{\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\"},{\"crop\":\"origin\",\"variety\":\"origin\",\"ha\":\"origin\",\"origin\":\"origin\"}],\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 09:15:57', '2021-10-22 09:15:57'),
(1367, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '[]', '2021-10-22 09:21:26', '2021-10-22 09:21:26'),
(1368, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:21:34', '2021-10-22 09:21:34'),
(1369, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:21:38', '2021-10-22 09:21:38'),
(1370, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"group-a\":[{\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\"},{\"crop\":\"habsk\",\"variety\":\"habskb\",\"ha\":\"kahsb\",\"origin\":\"akshbk\"}],\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/4\"}', '2021-10-22 09:22:11', '2021-10-22 09:22:11'),
(1371, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:22:11', '2021-10-22 09:22:11'),
(1372, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:22:21', '2021-10-22 09:22:21'),
(1373, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:26:04', '2021-10-22 09:26:04'),
(1374, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:27:09', '2021-10-22 09:27:09'),
(1375, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:27:19', '2021-10-22 09:27:19'),
(1376, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:27:41', '2021-10-22 09:27:41'),
(1377, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:28:18', '2021-10-22 09:28:18'),
(1378, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:28:35', '2021-10-22 09:28:35'),
(1379, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:28:48', '2021-10-22 09:28:48'),
(1380, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:28:49', '2021-10-22 09:28:49'),
(1381, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:29:27', '2021-10-22 09:29:27'),
(1382, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:32:18', '2021-10-22 09:32:18'),
(1383, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:35:35', '2021-10-22 09:35:35'),
(1384, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:35:47', '2021-10-22 09:35:47'),
(1385, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:35:55', '2021-10-22 09:35:55'),
(1386, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:37:59', '2021-10-22 09:37:59'),
(1387, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:38:01', '2021-10-22 09:38:01'),
(1388, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:39:18', '2021-10-22 09:39:18');
INSERT INTO `admin_operation_log` (`id`, `user_id`, `path`, `method`, `ip`, `input`, `created_at`, `updated_at`) VALUES
(1389, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:40:06', '2021-10-22 09:40:06'),
(1390, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:40:21', '2021-10-22 09:40:21'),
(1391, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:40:29', '2021-10-22 09:40:29'),
(1392, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:40:48', '2021-10-22 09:40:48'),
(1393, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:41:12', '2021-10-22 09:41:12'),
(1394, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:41:49', '2021-10-22 09:41:49'),
(1395, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:42:13', '2021-10-22 09:42:13'),
(1396, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:42:28', '2021-10-22 09:42:28'),
(1397, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:42:42', '2021-10-22 09:42:42'),
(1398, 3, 'admin/form-sr6s', 'GET', '127.0.0.1', '[]', '2021-10-22 09:42:51', '2021-10-22 09:42:51'),
(1399, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:42:56', '2021-10-22 09:42:56'),
(1400, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:42:59', '2021-10-22 09:42:59'),
(1401, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:43:15', '2021-10-22 09:43:15'),
(1402, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:43:47', '2021-10-22 09:43:47'),
(1403, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:43:48', '2021-10-22 09:43:48'),
(1404, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"group-a\":[{\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\"},{\"crop\":\"origin\",\"variety\":\"habskb\",\"ha\":\"origin\",\"origin\":\"akshbk\"}],\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 09:44:00', '2021-10-22 09:44:00'),
(1405, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '[]', '2021-10-22 09:44:08', '2021-10-22 09:44:08'),
(1406, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '[]', '2021-10-22 09:44:20', '2021-10-22 09:44:20'),
(1407, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:44:26', '2021-10-22 09:44:26'),
(1408, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:44:34', '2021-10-22 09:44:34'),
(1409, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"group-a\":[{\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\"},{\"crop\":\"origin\",\"variety\":\"origin\",\"ha\":\"origin\",\"origin\":\"akshbk\"}],\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/4\"}', '2021-10-22 09:44:44', '2021-10-22 09:44:44'),
(1410, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:44:44', '2021-10-22 09:44:44'),
(1411, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:44:51', '2021-10-22 09:44:51'),
(1412, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '[]', '2021-10-22 09:45:12', '2021-10-22 09:45:12'),
(1413, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:45:14', '2021-10-22 09:45:14'),
(1414, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/4\"}', '2021-10-22 09:45:20', '2021-10-22 09:45:20'),
(1415, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '[]', '2021-10-22 09:45:21', '2021-10-22 09:45:21'),
(1416, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '[]', '2021-10-22 09:46:25', '2021-10-22 09:46:25'),
(1417, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:46:33', '2021-10-22 09:46:33'),
(1418, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:46:35', '2021-10-22 09:46:35'),
(1419, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"group-a\":[{\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\"}],\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/4\"}', '2021-10-22 09:46:38', '2021-10-22 09:46:38'),
(1420, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '[]', '2021-10-22 09:46:39', '2021-10-22 09:46:39'),
(1421, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '[]', '2021-10-22 09:47:24', '2021-10-22 09:47:24'),
(1422, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:47:32', '2021-10-22 09:47:32'),
(1423, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:47:33', '2021-10-22 09:47:33'),
(1424, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"group-a\":[{\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\"}],\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/4\"}', '2021-10-22 09:47:37', '2021-10-22 09:47:37'),
(1425, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '[]', '2021-10-22 09:48:14', '2021-10-22 09:48:14'),
(1426, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:48:16', '2021-10-22 09:48:16'),
(1427, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:48:19', '2021-10-22 09:48:19'),
(1428, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"group-a\":[{\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\"}],\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/4\"}', '2021-10-22 09:48:26', '2021-10-22 09:48:26'),
(1429, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '[]', '2021-10-22 09:48:38', '2021-10-22 09:48:38'),
(1430, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:48:39', '2021-10-22 09:48:39'),
(1431, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:48:41', '2021-10-22 09:48:41'),
(1432, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"group-a\":[{\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\"}],\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/4\"}', '2021-10-22 09:48:45', '2021-10-22 09:48:45'),
(1433, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '[]', '2021-10-22 09:48:45', '2021-10-22 09:48:45'),
(1434, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '[]', '2021-10-22 09:49:33', '2021-10-22 09:49:33'),
(1435, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:49:36', '2021-10-22 09:49:36'),
(1436, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:49:39', '2021-10-22 09:49:39'),
(1437, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"[{\\\"crop\\\":\\\"11\\\",\\\"variety\\\":\\\"22\\\",\\\"ha\\\":\\\"33\\\",\\\"origin\\\":\\\"44\\\"}]\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"group-a\":[{\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\"}],\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\\/4\"}', '2021-10-22 09:49:42', '2021-10-22 09:49:42'),
(1438, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '[]', '2021-10-22 09:49:42', '2021-10-22 09:49:42'),
(1439, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:50:05', '2021-10-22 09:50:05'),
(1440, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:50:08', '2021-10-22 09:50:08'),
(1441, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"[{\\\"crop\\\":\\\"11\\\",\\\"variety\\\":\\\"22\\\",\\\"ha\\\":\\\"33\\\",\\\"origin\\\":\\\"44\\\"}]\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"group-a\":[{\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\"},{\"crop\":\"origin\",\"variety\":\"habskb\",\"ha\":\"origin\",\"origin\":\"origin\"}],\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"_method\":\"PUT\"}', '2021-10-22 09:51:04', '2021-10-22 09:51:04'),
(1442, 3, 'admin/form-sr6s', 'GET', '127.0.0.1', '[]', '2021-10-22 09:51:04', '2021-10-22 09:51:04'),
(1443, 3, 'admin/form-sr6s', 'GET', '127.0.0.1', '[]', '2021-10-22 09:52:06', '2021-10-22 09:52:06'),
(1444, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:52:09', '2021-10-22 09:52:09'),
(1445, 3, 'admin/form-sr6s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:52:10', '2021-10-22 09:52:10'),
(1446, 3, 'admin/form-sr4s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:52:14', '2021-10-22 09:52:14'),
(1447, 3, 'admin/form-sr6s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:52:14', '2021-10-22 09:52:14'),
(1448, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:52:19', '2021-10-22 09:52:19'),
(1449, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:52:27', '2021-10-22 09:52:27'),
(1450, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"[{\\\"crop\\\":\\\"11\\\",\\\"variety\\\":\\\"22\\\",\\\"ha\\\":\\\"33\\\",\\\"origin\\\":\\\"44\\\"},{\\\"crop\\\":\\\"origin\\\",\\\"variety\\\":\\\"habskb\\\",\\\"ha\\\":\\\"origin\\\",\\\"origin\\\":\\\"origin\\\"}]\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"Bwera, Kasese, Uganda\",\"years_of_expirience\":\"21\",\"group-a\":[{\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\"},{\"crop\":\"Roina\",\"variety\":\"SOMALIA\",\"ha\":\"jUMAA\",\"origin\":\"kASESE\"}],\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\"}', '2021-10-22 09:52:43', '2021-10-22 09:52:43'),
(1451, 3, 'admin/form-sr6s', 'GET', '127.0.0.1', '[]', '2021-10-22 09:52:44', '2021-10-22 09:52:44'),
(1452, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:52:56', '2021-10-22 09:52:56'),
(1453, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:53:04', '2021-10-22 09:53:04'),
(1454, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:53:05', '2021-10-22 09:53:05'),
(1455, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:53:20', '2021-10-22 09:53:20'),
(1456, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:54:14', '2021-10-22 09:54:14'),
(1457, 3, 'admin/form-sr6s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:54:30', '2021-10-22 09:54:30'),
(1458, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:54:32', '2021-10-22 09:54:32'),
(1459, 3, 'admin/form-sr6s', 'POST', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"AS\",\"company_initials\":\"AS\",\"premises_location\":{\"new_1\":{\"key\":\"AS\",\"value\":\"AS\",\"desc\":\"AS\",\"_remove_\":\"0\"}},\"years_of_expirience\":\"11\",\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 12:54:32\",\"valid_until\":\"2021-10-22 12:54:32\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/form-sr6s\"}', '2021-10-22 09:54:51', '2021-10-22 09:54:51'),
(1460, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 09:54:51', '2021-10-22 09:54:51'),
(1461, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 09:55:02', '2021-10-22 09:55:02'),
(1462, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 09:55:35', '2021-10-22 09:55:35'),
(1463, 3, 'admin/form-sr6s', 'POST', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"AS\",\"company_initials\":\"AS\",\"premises_location\":{\"new_1\":{\"key\":\"Q\",\"value\":\"W\",\"desc\":\"W\",\"_remove_\":\"0\"}},\"years_of_expirience\":\"1\",\"group-a\":[{\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\"}],\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 12:55:35\",\"valid_until\":\"2021-10-22 12:55:35\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\"}', '2021-10-22 09:55:54', '2021-10-22 09:55:54'),
(1464, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 09:55:54', '2021-10-22 09:55:54'),
(1465, 3, 'admin/form-sr6s', 'POST', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"AS\",\"company_initials\":\"AS\",\"premises_location\":{\"new_1\":{\"key\":\"Q\",\"value\":\"W\",\"desc\":\"W\",\"_remove_\":\"0\"}},\"years_of_expirience\":\"1\",\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 12:55:35\",\"valid_until\":\"2021-10-22 12:55:35\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\"}', '2021-10-22 09:56:03', '2021-10-22 09:56:03'),
(1466, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 09:56:04', '2021-10-22 09:56:04'),
(1467, 3, 'admin/form-sr6s', 'POST', '127.0.0.1', '{\"administrator_id\":\"3\",\"name_of_applicant\":\"Betty Namagembe\",\"address\":\"AS\",\"company_initials\":\"AS\",\"premises_location\":{\"new_1\":{\"key\":\"Q\",\"value\":\"W\",\"desc\":\"W\",\"_remove_\":\"0\"}},\"years_of_expirience\":\"1\",\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 12:55:35\",\"valid_until\":\"2021-10-22 12:55:35\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\"}', '2021-10-22 09:56:30', '2021-10-22 09:56:30'),
(1468, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 09:56:31', '2021-10-22 09:56:31'),
(1469, 3, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 09:56:39', '2021-10-22 09:56:39'),
(1470, 3, 'admin/form-sr6s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:56:46', '2021-10-22 09:56:46'),
(1471, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 09:56:53', '2021-10-22 09:56:53'),
(1472, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 09:58:31', '2021-10-22 09:58:31'),
(1473, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 10:10:41', '2021-10-22 10:10:41'),
(1474, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"dealers_in\":null,\"name_of_applicant\":\"[{\\\"crop\\\":\\\"11\\\",\\\"variety\\\":\\\"22\\\",\\\"ha\\\":\\\"33\\\",\\\"origin\\\":\\\"44\\\"},{\\\"crop\\\":\\\"origin\\\",\\\"variety\\\":\\\"habskb\\\",\\\"ha\\\":\\\"origin\\\",\\\"origin\\\":\\\"origin\\\"}]\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"[{\\\"crop\\\":\\\"11\\\",\\\"variety\\\":\\\"22\\\",\\\"ha\\\":\\\"33\\\",\\\"origin\\\":\\\"44\\\"},{\\\"crop\\\":\\\"Roina\\\",\\\"variety\\\":\\\"SOMALIA\\\",\\\"ha\\\":\\\"jUMAA\\\",\\\"origin\\\":\\\"kASESE\\\"}]\",\"years_of_expirience\":\"21\",\"group-a\":[{\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\"},{\"crop\":\"BETY\",\"variety\":\"NAMAGEMBER\",\"ha\":\"11\",\"origin\":\"ROMINA\"}],\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"_method\":\"PUT\"}', '2021-10-22 10:12:26', '2021-10-22 10:12:26'),
(1475, 3, 'admin/form-sr6s', 'GET', '127.0.0.1', '[]', '2021-10-22 10:12:26', '2021-10-22 10:12:26'),
(1476, 3, 'admin/form-sr6s', 'GET', '127.0.0.1', '[]', '2021-10-22 10:15:48', '2021-10-22 10:15:48'),
(1477, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 10:15:54', '2021-10-22 10:15:54'),
(1478, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 10:17:10', '2021-10-22 10:17:10'),
(1479, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 10:18:04', '2021-10-22 10:18:04'),
(1480, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 10:20:18', '2021-10-22 10:20:18'),
(1481, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 10:23:10', '2021-10-22 10:23:10'),
(1482, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 10:23:18', '2021-10-22 10:23:18'),
(1483, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 10:23:28', '2021-10-22 10:23:28'),
(1484, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"dealers_in\":\"[{\\\"crop\\\":\\\"11\\\",\\\"variety\\\":\\\"22\\\",\\\"ha\\\":\\\"33\\\",\\\"origin\\\":\\\"44\\\"},{\\\"crop\\\":\\\"BETY\\\",\\\"variety\\\":\\\"NAMAGEMBER\\\",\\\"ha\\\":\\\"11\\\",\\\"origin\\\":\\\"ROMINA\\\"}]\",\"name_of_applicant\":\"[{\\\"crop\\\":\\\"11\\\",\\\"variety\\\":\\\"22\\\",\\\"ha\\\":\\\"33\\\",\\\"origin\\\":\\\"44\\\"},{\\\"crop\\\":\\\"origin\\\",\\\"variety\\\":\\\"habskb\\\",\\\"ha\\\":\\\"origin\\\",\\\"origin\\\":\\\"origin\\\"}]\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"[{\\\"crop\\\":\\\"11\\\",\\\"variety\\\":\\\"22\\\",\\\"ha\\\":\\\"33\\\",\\\"origin\\\":\\\"44\\\"},{\\\"crop\\\":\\\"Roina\\\",\\\"variety\\\":\\\"SOMALIA\\\",\\\"ha\\\":\\\"jUMAA\\\",\\\"origin\\\":\\\"kASESE\\\"}]\",\"years_of_expirience\":\"21\",\"group-a\":[{\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\"}],\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"_method\":\"PUT\"}', '2021-10-22 10:23:36', '2021-10-22 10:23:36'),
(1485, 3, 'admin/form-sr6s', 'GET', '127.0.0.1', '[]', '2021-10-22 10:23:36', '2021-10-22 10:23:36'),
(1486, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 10:23:40', '2021-10-22 10:23:40'),
(1487, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 10:23:41', '2021-10-22 10:23:41'),
(1488, 1, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '[]', '2021-10-22 11:57:32', '2021-10-22 11:57:32'),
(1489, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 11:59:42', '2021-10-22 11:59:42'),
(1490, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:00:11', '2021-10-22 12:00:11'),
(1491, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:00:51', '2021-10-22 12:00:51'),
(1492, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:00:52', '2021-10-22 12:00:52'),
(1493, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:00:53', '2021-10-22 12:00:53'),
(1494, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:01:06', '2021-10-22 12:01:06'),
(1495, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:01:07', '2021-10-22 12:01:07'),
(1496, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:01:08', '2021-10-22 12:01:08'),
(1497, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:01:09', '2021-10-22 12:01:09'),
(1498, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:01:22', '2021-10-22 12:01:22'),
(1499, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:01:23', '2021-10-22 12:01:23'),
(1500, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:01:29', '2021-10-22 12:01:29'),
(1501, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:02:30', '2021-10-22 12:02:30'),
(1502, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"dealers_in\":\"[{\\\"crop\\\":\\\"11\\\",\\\"variety\\\":\\\"22\\\",\\\"ha\\\":\\\"33\\\",\\\"origin\\\":\\\"44\\\"}]\",\"name_of_applicant\":\"[{\\\"crop\\\":\\\"11\\\",\\\"variety\\\":\\\"22\\\",\\\"ha\\\":\\\"33\\\",\\\"origin\\\":\\\"44\\\"},{\\\"crop\\\":\\\"origin\\\",\\\"variety\\\":\\\"habskb\\\",\\\"ha\\\":\\\"origin\\\",\\\"origin\\\":\\\"origin\\\"}]\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"[{\\\"crop\\\":\\\"11\\\",\\\"variety\\\":\\\"22\\\",\\\"ha\\\":\\\"33\\\",\\\"origin\\\":\\\"44\\\"},{\\\"crop\\\":\\\"Roina\\\",\\\"variety\\\":\\\"SOMALIA\\\",\\\"ha\\\":\\\"jUMAA\\\",\\\"origin\\\":\\\"kASESE\\\"}]\",\"years_of_expirience\":\"21\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"_method\":\"PUT\"}', '2021-10-22 12:02:37', '2021-10-22 12:02:37'),
(1503, 3, 'admin/form-sr6s', 'GET', '127.0.0.1', '[]', '2021-10-22 12:02:37', '2021-10-22 12:02:37'),
(1504, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:02:49', '2021-10-22 12:02:49'),
(1505, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:02:54', '2021-10-22 12:02:54'),
(1506, 3, 'admin/form-sr6s/4', 'PUT', '127.0.0.1', '{\"administrator_id\":\"3\",\"dealers_in\":\"[{\\\"crop\\\":\\\"11\\\",\\\"variety\\\":\\\"22\\\",\\\"ha\\\":\\\"33\\\",\\\"origin\\\":\\\"44\\\"}]\",\"name_of_applicant\":\"[{\\\"crop\\\":\\\"11\\\",\\\"variety\\\":\\\"22\\\",\\\"ha\\\":\\\"33\\\",\\\"origin\\\":\\\"44\\\"},{\\\"crop\\\":\\\"origin\\\",\\\"variety\\\":\\\"habskb\\\",\\\"ha\\\":\\\"origin\\\",\\\"origin\\\":\\\"origin\\\"}]\",\"address\":\"Bwera, Kasese, Uganda\",\"company_initials\":\"Ugnews24\",\"premises_location\":\"[{\\\"crop\\\":\\\"11\\\",\\\"variety\\\":\\\"22\\\",\\\"ha\\\":\\\"33\\\",\\\"origin\\\":\\\"44\\\"},{\\\"crop\\\":\\\"Roina\\\",\\\"variety\\\":\\\"SOMALIA\\\",\\\"ha\\\":\\\"jUMAA\\\",\\\"origin\\\":\\\"kASESE\\\"}]\",\"years_of_expirience\":\"21\",\"previous_grower_number\":null,\"cropping_histroy\":null,\"have_adequate_isolation\":\"off\",\"have_adequate_labor\":\"off\",\"aware_of_minimum_standards\":\"off\",\"signature_of_applicant\":null,\"grower_number\":null,\"registration_number\":null,\"valid_from\":\"2021-10-22 11:54:53\",\"valid_until\":\"2021-10-22 11:54:53\",\"status\":null,\"inspector\":null,\"status_comment\":null,\"_token\":\"8kXxuHIqoK7HYtDvvOyFsCYKSkfkiV89flHC0ziN\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-22 12:04:08', '2021-10-22 12:04:08'),
(1507, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:04:08', '2021-10-22 12:04:08'),
(1508, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:04:12', '2021-10-22 12:04:12'),
(1509, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:04:17', '2021-10-22 12:04:17'),
(1510, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:05:50', '2021-10-22 12:05:50'),
(1511, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:05:52', '2021-10-22 12:05:52'),
(1512, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:05:56', '2021-10-22 12:05:56'),
(1513, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:05:57', '2021-10-22 12:05:57'),
(1514, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:06:00', '2021-10-22 12:06:00'),
(1515, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:06:01', '2021-10-22 12:06:01'),
(1516, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:06:49', '2021-10-22 12:06:49'),
(1517, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:06:56', '2021-10-22 12:06:56'),
(1518, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:07:30', '2021-10-22 12:07:30'),
(1519, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:08:59', '2021-10-22 12:08:59'),
(1520, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:09:54', '2021-10-22 12:09:54'),
(1521, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:09:56', '2021-10-22 12:09:56'),
(1522, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:09:58', '2021-10-22 12:09:58'),
(1523, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:10:40', '2021-10-22 12:10:40'),
(1524, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:10:41', '2021-10-22 12:10:41'),
(1525, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:10:42', '2021-10-22 12:10:42'),
(1526, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:10:43', '2021-10-22 12:10:43'),
(1527, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:10:44', '2021-10-22 12:10:44'),
(1528, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:10:46', '2021-10-22 12:10:46'),
(1529, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:10:47', '2021-10-22 12:10:47'),
(1530, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:10:48', '2021-10-22 12:10:48'),
(1531, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:10:50', '2021-10-22 12:10:50'),
(1532, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:10:52', '2021-10-22 12:10:52'),
(1533, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:10:53', '2021-10-22 12:10:53'),
(1534, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:10:54', '2021-10-22 12:10:54'),
(1535, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:10:56', '2021-10-22 12:10:56'),
(1536, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:10:58', '2021-10-22 12:10:58'),
(1537, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:10:59', '2021-10-22 12:10:59'),
(1538, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:11:01', '2021-10-22 12:11:01'),
(1539, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:11:03', '2021-10-22 12:11:03'),
(1540, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:11:04', '2021-10-22 12:11:04'),
(1541, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:11:05', '2021-10-22 12:11:05'),
(1542, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:11:08', '2021-10-22 12:11:08'),
(1543, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:11:27', '2021-10-22 12:11:27'),
(1544, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:11:30', '2021-10-22 12:11:30'),
(1545, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:11:40', '2021-10-22 12:11:40'),
(1546, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:11:42', '2021-10-22 12:11:42'),
(1547, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:11:43', '2021-10-22 12:11:43'),
(1548, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:11:44', '2021-10-22 12:11:44'),
(1549, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:11:45', '2021-10-22 12:11:45'),
(1550, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:11:46', '2021-10-22 12:11:46'),
(1551, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:11:48', '2021-10-22 12:11:48'),
(1552, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:11:50', '2021-10-22 12:11:50'),
(1553, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:11:51', '2021-10-22 12:11:51'),
(1554, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:11:53', '2021-10-22 12:11:53'),
(1555, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:11:54', '2021-10-22 12:11:54'),
(1556, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:11:56', '2021-10-22 12:11:56'),
(1557, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:12:00', '2021-10-22 12:12:00'),
(1558, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:12:01', '2021-10-22 12:12:01'),
(1559, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:12:13', '2021-10-22 12:12:13'),
(1560, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:12:15', '2021-10-22 12:12:15'),
(1561, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:12:15', '2021-10-22 12:12:15'),
(1562, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:12:16', '2021-10-22 12:12:16'),
(1563, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:12:34', '2021-10-22 12:12:34'),
(1564, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:12:35', '2021-10-22 12:12:35'),
(1565, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:12:46', '2021-10-22 12:12:46'),
(1566, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:12:47', '2021-10-22 12:12:47'),
(1567, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:12:51', '2021-10-22 12:12:51'),
(1568, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:12:52', '2021-10-22 12:12:52'),
(1569, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:12:53', '2021-10-22 12:12:53'),
(1570, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:13:04', '2021-10-22 12:13:04'),
(1571, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:13:05', '2021-10-22 12:13:05'),
(1572, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:13:10', '2021-10-22 12:13:10'),
(1573, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:13:11', '2021-10-22 12:13:11'),
(1574, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:13:42', '2021-10-22 12:13:42'),
(1575, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:13:43', '2021-10-22 12:13:43'),
(1576, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:13:44', '2021-10-22 12:13:44'),
(1577, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:13:45', '2021-10-22 12:13:45'),
(1578, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:14:04', '2021-10-22 12:14:04'),
(1579, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:14:07', '2021-10-22 12:14:07'),
(1580, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:14:15', '2021-10-22 12:14:15'),
(1581, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:14:17', '2021-10-22 12:14:17'),
(1582, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:14:46', '2021-10-22 12:14:46'),
(1583, 1, 'admin/form-sr6s', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:14:56', '2021-10-22 12:14:56'),
(1584, 1, 'admin/form-sr6s/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:14:59', '2021-10-22 12:14:59'),
(1585, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:15:24', '2021-10-22 12:15:24'),
(1586, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:15:25', '2021-10-22 12:15:25'),
(1587, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:16:37', '2021-10-22 12:16:37'),
(1588, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '[]', '2021-10-22 12:16:38', '2021-10-22 12:16:38'),
(1589, 3, 'admin/form-sr6s/4', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:16:46', '2021-10-22 12:16:46'),
(1590, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:16:48', '2021-10-22 12:16:48'),
(1591, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:16:48', '2021-10-22 12:16:48'),
(1592, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:17:19', '2021-10-22 12:17:19'),
(1593, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:17:20', '2021-10-22 12:17:20'),
(1594, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:17:30', '2021-10-22 12:17:30'),
(1595, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:17:31', '2021-10-22 12:17:31'),
(1596, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:18:22', '2021-10-22 12:18:22'),
(1597, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:18:24', '2021-10-22 12:18:24'),
(1598, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:19:17', '2021-10-22 12:19:17'),
(1599, 3, 'admin/form-sr6s/4/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-22 12:19:17', '2021-10-22 12:19:17'),
(1600, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 03:35:18', '2021-10-23 03:35:18'),
(1601, 1, 'admin/form-sr4s', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 03:35:27', '2021-10-23 03:35:27'),
(1602, 1, 'admin/form-sr6s', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 03:35:33', '2021-10-23 03:35:33'),
(1603, 1, 'admin/form-sr4s', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 03:35:35', '2021-10-23 03:35:35'),
(1604, 1, 'admin/form-sr4s/4', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 03:35:38', '2021-10-23 03:35:38'),
(1605, 1, 'admin/auth/logout', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 03:35:51', '2021-10-23 03:35:51'),
(1606, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 03:36:22', '2021-10-23 03:36:22'),
(1607, 1, 'admin/auth/logout', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 03:36:28', '2021-10-23 03:36:28'),
(1608, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 03:39:55', '2021-10-23 03:39:55'),
(1609, 1, 'admin/auth/logout', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 03:40:02', '2021-10-23 03:40:02'),
(1610, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 03:44:45', '2021-10-23 03:44:45'),
(1611, 1, 'admin/auth/logout', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 03:44:53', '2021-10-23 03:44:53'),
(1612, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 03:44:58', '2021-10-23 03:44:58'),
(1613, 1, 'admin/countries', 'GET', '::1', '[]', '2021-10-23 03:48:31', '2021-10-23 03:48:31'),
(1614, 1, 'admin/countries/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 03:48:53', '2021-10-23 03:48:53'),
(1615, 1, 'admin/cities', 'GET', '::1', '[]', '2021-10-23 03:49:41', '2021-10-23 03:49:41'),
(1616, 1, 'admin/cities/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 03:49:45', '2021-10-23 03:49:45'),
(1617, 1, 'admin/districts', 'GET', '::1', '[]', '2021-10-23 04:00:00', '2021-10-23 04:00:00'),
(1618, 1, 'admin/districts', 'GET', '::1', '[]', '2021-10-23 04:01:53', '2021-10-23 04:01:53'),
(1619, 1, 'admin/districts/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 04:02:02', '2021-10-23 04:02:02'),
(1620, 1, 'admin/districts/create', 'GET', '::1', '[]', '2021-10-23 04:02:43', '2021-10-23 04:02:43'),
(1621, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 04:10:35', '2021-10-23 04:10:35'),
(1622, 1, 'admin/districts', 'GET', '::1', '[]', '2021-10-23 04:10:48', '2021-10-23 04:10:48'),
(1623, 1, 'admin/districts/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 04:10:51', '2021-10-23 04:10:51'),
(1624, 1, 'admin/districts/create', 'GET', '::1', '[]', '2021-10-23 04:13:34', '2021-10-23 04:13:34'),
(1625, 1, 'admin/districts/create', 'GET', '::1', '[]', '2021-10-23 04:14:40', '2021-10-23 04:14:40'),
(1626, 1, 'admin/districts/create', 'GET', '::1', '[]', '2021-10-23 04:15:20', '2021-10-23 04:15:20'),
(1627, 1, 'admin/districts/create', 'GET', '::1', '[]', '2021-10-23 04:16:00', '2021-10-23 04:16:00'),
(1628, 1, 'admin/districts/create', 'GET', '::1', '[]', '2021-10-23 04:20:55', '2021-10-23 04:20:55'),
(1629, 1, 'admin/districts/create', 'GET', '::1', '[]', '2021-10-23 04:21:32', '2021-10-23 04:21:32'),
(1630, 1, 'admin/districts/create', 'GET', '::1', '[]', '2021-10-23 04:22:01', '2021-10-23 04:22:01'),
(1631, 1, 'admin/districts', 'POST', '::1', '{\"latitude\":null,\"longitude\":null,\"administrator_id\":null,\"name\":null,\"image\":null,\"details\":null,\"_token\":\"fNPwcvkmwfsjg9tS7RMcPe8K17c6lEoI9nzTYIKU\"}', '2021-10-23 04:22:30', '2021-10-23 04:22:30'),
(1632, 1, 'admin/districts/create', 'GET', '::1', '[]', '2021-10-23 04:22:31', '2021-10-23 04:22:31'),
(1633, 1, 'admin/districts/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 04:23:14', '2021-10-23 04:23:14'),
(1634, 1, 'admin/districts/create', 'GET', '::1', '[]', '2021-10-23 04:23:49', '2021-10-23 04:23:49'),
(1635, 1, 'admin/districts/create', 'GET', '::1', '[]', '2021-10-23 04:24:41', '2021-10-23 04:24:41'),
(1636, 1, 'admin/districts/create', 'GET', '::1', '[]', '2021-10-23 04:41:04', '2021-10-23 04:41:04'),
(1637, 1, 'admin/districts/create', 'GET', '::1', '[]', '2021-10-23 04:45:07', '2021-10-23 04:45:07'),
(1638, 1, 'admin/districts/create', 'GET', '::1', '[]', '2021-10-23 04:46:16', '2021-10-23 04:46:16'),
(1639, 1, 'admin/districts/create', 'GET', '::1', '[]', '2021-10-23 04:46:59', '2021-10-23 04:46:59'),
(1640, 1, 'admin/districts/create', 'GET', '::1', '[]', '2021-10-23 04:48:08', '2021-10-23 04:48:08'),
(1641, 1, 'admin/districts', 'POST', '::1', '{\"latitude\":\"89.9999974387347\",\"longitude\":\"90.00029001384974\",\"administrator_id\":\"1\",\"name\":\"kasese\",\"image\":null,\"details\":\"kampala\",\"_token\":\"fNPwcvkmwfsjg9tS7RMcPe8K17c6lEoI9nzTYIKU\"}', '2021-10-23 04:48:34', '2021-10-23 04:48:34'),
(1642, 1, 'admin/districts', 'GET', '::1', '[]', '2021-10-23 04:48:35', '2021-10-23 04:48:35'),
(1643, 1, 'admin/districts/1/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 04:48:38', '2021-10-23 04:48:38'),
(1644, 1, 'admin/districts/1/edit', 'GET', '::1', '[]', '2021-10-23 04:50:10', '2021-10-23 04:50:10'),
(1645, 1, 'admin/districts/1/edit', 'GET', '::1', '[]', '2021-10-23 04:53:42', '2021-10-23 04:53:42'),
(1646, 1, 'admin/districts/1/edit', 'GET', '::1', '[]', '2021-10-23 04:54:25', '2021-10-23 04:54:25'),
(1647, 1, 'admin/districts/1/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 04:56:03', '2021-10-23 04:56:03'),
(1648, 1, 'admin/districts/1/edit', 'GET', '::1', '[]', '2021-10-23 04:58:11', '2021-10-23 04:58:11'),
(1649, 1, 'admin/districts/1', 'PUT', '::1', '{\"name\":\"Kasese\",\"administrator_id\":\"2\",\"details\":\"kampala\",\"latitude\":\"0.1183366\",\"longitude\":\"29.7230851\",\"_token\":\"fNPwcvkmwfsjg9tS7RMcPe8K17c6lEoI9nzTYIKU\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-23 04:59:59', '2021-10-23 04:59:59'),
(1650, 1, 'admin/districts/1/edit', 'GET', '::1', '[]', '2021-10-23 04:59:59', '2021-10-23 04:59:59'),
(1651, 1, 'admin/districts/1/edit', 'GET', '::1', '[]', '2021-10-23 05:00:19', '2021-10-23 05:00:19'),
(1652, 1, 'admin/districts/1/edit', 'GET', '::1', '[]', '2021-10-23 05:01:16', '2021-10-23 05:01:16'),
(1653, 1, 'admin/districts/1/edit', 'GET', '::1', '[]', '2021-10-23 05:01:41', '2021-10-23 05:01:41'),
(1654, 1, 'admin/districts/1/edit', 'GET', '::1', '[]', '2021-10-23 05:03:38', '2021-10-23 05:03:38'),
(1655, 1, 'admin/districts/1/edit', 'GET', '::1', '[]', '2021-10-23 05:04:51', '2021-10-23 05:04:51'),
(1656, 1, 'admin/districts/1/edit', 'GET', '::1', '[]', '2021-10-23 05:05:30', '2021-10-23 05:05:30'),
(1657, 1, 'admin/districts/1/edit', 'GET', '::1', '[]', '2021-10-23 05:05:43', '2021-10-23 05:05:43'),
(1658, 1, 'admin/districts/1/edit', 'GET', '::1', '[]', '2021-10-23 05:05:58', '2021-10-23 05:05:58'),
(1659, 1, 'admin/districts/1/edit', 'GET', '::1', '[]', '2021-10-23 05:08:30', '2021-10-23 05:08:30'),
(1660, 1, 'admin/districts/1/edit', 'GET', '::1', '[]', '2021-10-23 05:11:03', '2021-10-23 05:11:03'),
(1661, 1, 'admin/districts/1', 'PUT', '::1', '{\"name\":\"Kasese\",\"administrator_id\":\"2\",\"details\":\"kampala\",\"latitude\":\"0.1183366\",\"longitude\":\"29.7230851\",\"_token\":\"fNPwcvkmwfsjg9tS7RMcPe8K17c6lEoI9nzTYIKU\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-23 05:11:17', '2021-10-23 05:11:17'),
(1662, 1, 'admin/districts/1/edit', 'GET', '::1', '[]', '2021-10-23 05:11:18', '2021-10-23 05:11:18'),
(1663, 1, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 05:12:11', '2021-10-23 05:12:11'),
(1664, 1, 'admin/auth/menu/12', 'DELETE', '::1', '{\"_method\":\"delete\",\"_token\":\"fNPwcvkmwfsjg9tS7RMcPe8K17c6lEoI9nzTYIKU\"}', '2021-10-23 05:12:23', '2021-10-23 05:12:23'),
(1665, 1, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 05:12:24', '2021-10-23 05:12:24'),
(1666, 1, 'admin/auth/menu', 'POST', '::1', '{\"_token\":\"fNPwcvkmwfsjg9tS7RMcPe8K17c6lEoI9nzTYIKU\",\"_order\":\"[{\\\"id\\\":1},{\\\"id\\\":2,\\\"children\\\":[{\\\"id\\\":3},{\\\"id\\\":4},{\\\"id\\\":5},{\\\"id\\\":6},{\\\"id\\\":7}]},{\\\"id\\\":10},{\\\"id\\\":8}]\"}', '2021-10-23 05:12:42', '2021-10-23 05:12:42'),
(1667, 1, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 05:12:43', '2021-10-23 05:12:43'),
(1668, 1, 'admin/auth/menu', 'POST', '::1', '{\"parent_id\":\"0\",\"title\":\"Districts\",\"icon\":\"fa-building\",\"uri\":\"districts\",\"roles\":[null],\"permission\":null,\"_token\":\"fNPwcvkmwfsjg9tS7RMcPe8K17c6lEoI9nzTYIKU\"}', '2021-10-23 05:13:25', '2021-10-23 05:13:25');
INSERT INTO `admin_operation_log` (`id`, `user_id`, `path`, `method`, `ip`, `input`, `created_at`, `updated_at`) VALUES
(1669, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 05:13:26', '2021-10-23 05:13:26'),
(1670, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 05:13:30', '2021-10-23 05:13:30'),
(1671, 1, 'admin/auth/menu', 'POST', '::1', '{\"parent_id\":\"0\",\"title\":null,\"icon\":\"fa-bars\",\"uri\":null,\"roles\":[null],\"permission\":null,\"_token\":\"fNPwcvkmwfsjg9tS7RMcPe8K17c6lEoI9nzTYIKU\"}', '2021-10-23 05:13:37', '2021-10-23 05:13:37'),
(1672, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 05:13:38', '2021-10-23 05:13:38'),
(1673, 1, 'admin/districts', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 05:13:41', '2021-10-23 05:13:41'),
(1674, 1, 'admin/districts', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 05:16:32', '2021-10-23 05:16:32'),
(1675, 1, 'admin/districts', 'GET', '::1', '[]', '2021-10-23 05:18:19', '2021-10-23 05:18:19'),
(1676, 1, 'admin/districts', 'GET', '::1', '[]', '2021-10-23 05:20:18', '2021-10-23 05:20:18'),
(1677, 1, 'admin/districts', 'GET', '::1', '[]', '2021-10-23 05:23:25', '2021-10-23 05:23:25'),
(1678, 1, 'admin/districts', 'GET', '::1', '[]', '2021-10-23 05:25:01', '2021-10-23 05:25:01'),
(1679, 1, 'admin/districts', 'GET', '::1', '[]', '2021-10-23 05:25:35', '2021-10-23 05:25:35'),
(1680, 1, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 05:32:08', '2021-10-23 05:32:08'),
(1681, 1, 'admin/auth/menu', 'POST', '::1', '{\"parent_id\":\"0\",\"title\":\"Laboratories\",\"icon\":\"fa-bars\",\"uri\":\"labs\",\"roles\":[null],\"permission\":null,\"_token\":\"fNPwcvkmwfsjg9tS7RMcPe8K17c6lEoI9nzTYIKU\"}', '2021-10-23 05:32:33', '2021-10-23 05:32:33'),
(1682, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 05:32:33', '2021-10-23 05:32:33'),
(1683, 1, 'admin/labs', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 05:34:32', '2021-10-23 05:34:32'),
(1684, 1, 'admin/labs', 'GET', '::1', '[]', '2021-10-23 05:34:36', '2021-10-23 05:34:36'),
(1685, 1, 'admin/labs', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 05:34:40', '2021-10-23 05:34:40'),
(1686, 1, 'admin/labs', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 05:34:43', '2021-10-23 05:34:43'),
(1687, 1, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 05:34:44', '2021-10-23 05:34:44'),
(1688, 1, 'admin/auth/menu/17/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 05:34:49', '2021-10-23 05:34:49'),
(1689, 1, 'admin/auth/menu/17', 'PUT', '::1', '{\"parent_id\":\"0\",\"title\":\"Laboratories\",\"icon\":\"fa-gitlab\",\"uri\":\"labs\",\"roles\":[null],\"permission\":null,\"_token\":\"fNPwcvkmwfsjg9tS7RMcPe8K17c6lEoI9nzTYIKU\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/auth\\/menu\"}', '2021-10-23 05:35:07', '2021-10-23 05:35:07'),
(1690, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 05:35:07', '2021-10-23 05:35:07'),
(1691, 1, 'admin/labs', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 05:35:11', '2021-10-23 05:35:11'),
(1692, 1, 'admin/labs', 'GET', '::1', '[]', '2021-10-23 05:35:12', '2021-10-23 05:35:12'),
(1693, 1, 'admin/labs/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 05:35:17', '2021-10-23 05:35:17'),
(1694, 1, 'admin/labs/create', 'GET', '::1', '[]', '2021-10-23 05:39:41', '2021-10-23 05:39:41'),
(1695, 1, 'admin/labs/create', 'GET', '::1', '[]', '2021-10-23 05:40:22', '2021-10-23 05:40:22'),
(1696, 1, 'admin/labs/create', 'GET', '::1', '[]', '2021-10-23 05:41:23', '2021-10-23 05:41:23'),
(1697, 1, 'admin/labs/create', 'GET', '::1', '[]', '2021-10-23 05:43:39', '2021-10-23 05:43:39'),
(1698, 1, 'admin/labs', 'POST', '::1', '{\"name\":\"Nansana lab\",\"district_id\":\"1\",\"administrator_id\":\"2\",\"address\":\"lab full disrtict\",\"details\":\"text\",\"latitude\":\"0.3679815408762197\",\"longitude\":\"32.52343644354454\",\"_token\":\"fNPwcvkmwfsjg9tS7RMcPe8K17c6lEoI9nzTYIKU\",\"after-save\":\"1\"}', '2021-10-23 05:46:20', '2021-10-23 05:46:20'),
(1699, 1, 'admin/labs/1/edit', 'GET', '::1', '[]', '2021-10-23 05:46:21', '2021-10-23 05:46:21'),
(1700, 1, 'admin/labs/1', 'PUT', '::1', '{\"name\":\"Nansana lab\",\"district_id\":\"1\",\"administrator_id\":\"2\",\"address\":\"lab full disrtict\",\"details\":\"text\",\"latitude\":\"0.3679815408762197\",\"longitude\":\"32.52343644354454\",\"_token\":\"fNPwcvkmwfsjg9tS7RMcPe8K17c6lEoI9nzTYIKU\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/labs\\/create\"}', '2021-10-23 05:50:12', '2021-10-23 05:50:12'),
(1701, 1, 'admin/labs/1/edit', 'GET', '::1', '[]', '2021-10-23 05:50:13', '2021-10-23 05:50:13'),
(1702, 1, 'admin/labs', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 05:50:24', '2021-10-23 05:50:24'),
(1703, 1, 'admin/labs', 'GET', '::1', '[]', '2021-10-23 05:58:19', '2021-10-23 05:58:19'),
(1704, 1, 'admin/labs', 'GET', '::1', '[]', '2021-10-23 05:58:28', '2021-10-23 05:58:28'),
(1705, 1, 'admin/districts', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 05:58:47', '2021-10-23 05:58:47'),
(1706, 1, 'admin/labs', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 05:58:49', '2021-10-23 05:58:49'),
(1707, 1, 'admin/labs/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:08:09', '2021-10-23 06:08:09'),
(1708, 1, 'admin/districts', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:08:20', '2021-10-23 06:08:20'),
(1709, 1, 'admin/districts', 'GET', '::1', '[]', '2021-10-23 06:08:22', '2021-10-23 06:08:22'),
(1710, 1, 'admin/districts', 'GET', '::1', '[]', '2021-10-23 06:08:37', '2021-10-23 06:08:37'),
(1711, 1, 'admin/districts', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:08:39', '2021-10-23 06:08:39'),
(1712, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 06:09:04', '2021-10-23 06:09:04'),
(1713, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 06:09:58', '2021-10-23 06:09:58'),
(1714, 1, 'admin', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:11:20', '2021-10-23 06:11:20'),
(1715, 1, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:11:29', '2021-10-23 06:11:29'),
(1716, 1, 'admin/auth/menu', 'POST', '::1', '{\"parent_id\":\"0\",\"title\":\"stock-records\",\"icon\":\"fa-dropbox\",\"uri\":\"stock-records\",\"roles\":[null],\"permission\":null,\"_token\":\"fNPwcvkmwfsjg9tS7RMcPe8K17c6lEoI9nzTYIKU\"}', '2021-10-23 06:12:14', '2021-10-23 06:12:14'),
(1717, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 06:12:15', '2021-10-23 06:12:15'),
(1718, 1, 'admin/auth/menu', 'POST', '::1', '{\"_token\":\"fNPwcvkmwfsjg9tS7RMcPe8K17c6lEoI9nzTYIKU\",\"_order\":\"[{\\\"id\\\":16},{\\\"id\\\":17},{\\\"id\\\":18},{\\\"id\\\":1},{\\\"id\\\":2,\\\"children\\\":[{\\\"id\\\":3},{\\\"id\\\":4},{\\\"id\\\":5},{\\\"id\\\":6},{\\\"id\\\":7}]},{\\\"id\\\":10},{\\\"id\\\":8}]\"}', '2021-10-23 06:12:21', '2021-10-23 06:12:21'),
(1719, 1, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:12:23', '2021-10-23 06:12:23'),
(1720, 1, 'admin/auth/menu', 'POST', '::1', '{\"_token\":\"fNPwcvkmwfsjg9tS7RMcPe8K17c6lEoI9nzTYIKU\",\"_order\":\"[{\\\"id\\\":16},{\\\"id\\\":17},{\\\"id\\\":18},{\\\"id\\\":1},{\\\"id\\\":2,\\\"children\\\":[{\\\"id\\\":3},{\\\"id\\\":4},{\\\"id\\\":5},{\\\"id\\\":6},{\\\"id\\\":7}]},{\\\"id\\\":10},{\\\"id\\\":8}]\"}', '2021-10-23 06:13:08', '2021-10-23 06:13:08'),
(1721, 1, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:13:09', '2021-10-23 06:13:09'),
(1722, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 06:13:11', '2021-10-23 06:13:11'),
(1723, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 06:15:23', '2021-10-23 06:15:23'),
(1724, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 06:16:32', '2021-10-23 06:16:32'),
(1725, 1, 'admin/stock-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:16:42', '2021-10-23 06:16:42'),
(1726, 1, 'admin/stock-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:16:46', '2021-10-23 06:16:46'),
(1727, 1, 'admin/stock-records/create', 'GET', '::1', '[]', '2021-10-23 06:21:05', '2021-10-23 06:21:05'),
(1728, 1, 'admin/stock-records/create', 'GET', '::1', '[]', '2021-10-23 06:21:21', '2021-10-23 06:21:21'),
(1729, 1, 'admin/stock-records/create', 'GET', '::1', '[]', '2021-10-23 06:23:41', '2021-10-23 06:23:41'),
(1730, 1, 'admin/stock-records/create', 'GET', '::1', '[]', '2021-10-23 06:25:09', '2021-10-23 06:25:09'),
(1731, 1, 'admin/stock-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:25:19', '2021-10-23 06:25:19'),
(1732, 1, 'admin/stock-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:25:25', '2021-10-23 06:25:25'),
(1733, 1, 'admin/stock-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:25:54', '2021-10-23 06:25:54'),
(1734, 1, 'admin/stock-records', 'POST', '::1', '{\"administrator_id\":\"1\",\"lab_id\":\"1\",\"name\":\"Johnsonjons\",\"type\":\"First dose\",\"amount\":\"10\",\"_token\":\"fNPwcvkmwfsjg9tS7RMcPe8K17c6lEoI9nzTYIKU\"}', '2021-10-23 06:26:24', '2021-10-23 06:26:24'),
(1735, 1, 'admin/stock-records', 'GET', '::1', '[]', '2021-10-23 06:26:25', '2021-10-23 06:26:25'),
(1736, 1, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:27:20', '2021-10-23 06:27:20'),
(1737, 1, 'admin/auth/menu/18/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:27:28', '2021-10-23 06:27:28'),
(1738, 1, 'admin/auth/menu/18', 'PUT', '::1', '{\"parent_id\":\"0\",\"title\":\"stock-records\",\"icon\":\"fa-dropbox\",\"uri\":\"Stock records\",\"roles\":[null],\"permission\":null,\"_token\":\"fNPwcvkmwfsjg9tS7RMcPe8K17c6lEoI9nzTYIKU\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/auth\\/menu\"}', '2021-10-23 06:27:39', '2021-10-23 06:27:39'),
(1739, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 06:27:39', '2021-10-23 06:27:39'),
(1740, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 06:27:49', '2021-10-23 06:27:49'),
(1741, 1, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:28:15', '2021-10-23 06:28:15'),
(1742, 1, 'admin/auth/menu/18/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:28:20', '2021-10-23 06:28:20'),
(1743, 1, 'admin/auth/menu/18', 'PUT', '::1', '{\"parent_id\":\"0\",\"title\":\"Stock records\",\"icon\":\"fa-dropbox\",\"uri\":\"stock-records\",\"roles\":[null],\"permission\":null,\"_token\":\"fNPwcvkmwfsjg9tS7RMcPe8K17c6lEoI9nzTYIKU\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/auth\\/menu\"}', '2021-10-23 06:28:30', '2021-10-23 06:28:30'),
(1744, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 06:28:31', '2021-10-23 06:28:31'),
(1745, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 06:28:34', '2021-10-23 06:28:34'),
(1746, 1, 'admin/stock-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:28:39', '2021-10-23 06:28:39'),
(1747, 1, 'admin/stock-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:29:13', '2021-10-23 06:29:13'),
(1748, 1, 'admin/stock-records', 'GET', '::1', '[]', '2021-10-23 06:29:45', '2021-10-23 06:29:45'),
(1749, 1, 'admin/stock-records', 'GET', '::1', '[]', '2021-10-23 06:30:45', '2021-10-23 06:30:45'),
(1750, 1, 'admin/stock-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:30:50', '2021-10-23 06:30:50'),
(1751, 1, 'admin/stock-records', 'GET', '::1', '[]', '2021-10-23 06:30:54', '2021-10-23 06:30:54'),
(1752, 1, 'admin/stock-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:31:43', '2021-10-23 06:31:43'),
(1753, 1, 'admin/stock-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:32:13', '2021-10-23 06:32:13'),
(1754, 1, 'admin/stock-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:32:50', '2021-10-23 06:32:50'),
(1755, 1, 'admin/districts', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:34:03', '2021-10-23 06:34:03'),
(1756, 1, 'admin/labs', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:34:04', '2021-10-23 06:34:04'),
(1757, 1, 'admin/stock-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:34:06', '2021-10-23 06:34:06'),
(1758, 1, 'admin/stock-records/1', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:34:11', '2021-10-23 06:34:11'),
(1759, 1, 'admin/stock-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:34:13', '2021-10-23 06:34:13'),
(1760, 1, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:46:32', '2021-10-23 06:46:32'),
(1761, 1, 'admin/auth/menu', 'POST', '::1', '{\"parent_id\":\"0\",\"title\":\"Vaccination records\",\"icon\":\"fa-book\",\"uri\":\"vaccination-records\",\"roles\":[null],\"permission\":null,\"_token\":\"fNPwcvkmwfsjg9tS7RMcPe8K17c6lEoI9nzTYIKU\"}', '2021-10-23 06:48:23', '2021-10-23 06:48:23'),
(1762, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 06:48:23', '2021-10-23 06:48:23'),
(1763, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 06:48:26', '2021-10-23 06:48:26'),
(1764, 1, 'admin/auth/menu', 'POST', '::1', '{\"_token\":\"fNPwcvkmwfsjg9tS7RMcPe8K17c6lEoI9nzTYIKU\",\"_order\":\"[{\\\"id\\\":16},{\\\"id\\\":17},{\\\"id\\\":18},{\\\"id\\\":19},{\\\"id\\\":1},{\\\"id\\\":2,\\\"children\\\":[{\\\"id\\\":3},{\\\"id\\\":4},{\\\"id\\\":5},{\\\"id\\\":6},{\\\"id\\\":7}]},{\\\"id\\\":10},{\\\"id\\\":8}]\"}', '2021-10-23 06:48:56', '2021-10-23 06:48:56'),
(1765, 1, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:48:56', '2021-10-23 06:48:56'),
(1766, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 06:48:59', '2021-10-23 06:48:59'),
(1767, 1, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:49:11', '2021-10-23 06:49:11'),
(1768, 1, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 06:49:16', '2021-10-23 06:49:16'),
(1769, 1, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 09:21:59', '2021-10-23 09:21:59'),
(1770, 1, 'admin/auth/setting', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 09:33:28', '2021-10-23 09:33:28'),
(1771, 1, 'admin/auth/users', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 09:33:31', '2021-10-23 09:33:31'),
(1772, 1, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 09:33:33', '2021-10-23 09:33:33'),
(1773, 1, 'admin/auth/menu', 'POST', '::1', '{\"parent_id\":\"0\",\"title\":\"Doctors\",\"icon\":\"fa-user-md\",\"uri\":\"doctors\",\"roles\":[null],\"permission\":null,\"_token\":\"WUJKeXmmn3DvXMy23ImN7OArvInEUV9UXUVASJXx\"}', '2021-10-23 09:34:07', '2021-10-23 09:34:07'),
(1774, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 09:34:07', '2021-10-23 09:34:07'),
(1775, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 09:34:21', '2021-10-23 09:34:21'),
(1776, 1, 'admin/auth/menu', 'POST', '::1', '{\"_token\":\"WUJKeXmmn3DvXMy23ImN7OArvInEUV9UXUVASJXx\",\"_order\":\"[{\\\"id\\\":16},{\\\"id\\\":17},{\\\"id\\\":18},{\\\"id\\\":20},{\\\"id\\\":19},{\\\"id\\\":1},{\\\"id\\\":2,\\\"children\\\":[{\\\"id\\\":3},{\\\"id\\\":4},{\\\"id\\\":5},{\\\"id\\\":6},{\\\"id\\\":7}]},{\\\"id\\\":10},{\\\"id\\\":8}]\"}', '2021-10-23 09:34:38', '2021-10-23 09:34:38'),
(1777, 1, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 09:34:39', '2021-10-23 09:34:39'),
(1778, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 09:34:41', '2021-10-23 09:34:41'),
(1779, 1, 'admin/doctors', 'GET', '::1', '[]', '2021-10-23 09:36:00', '2021-10-23 09:36:00'),
(1780, 1, 'admin/doctors/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 09:36:05', '2021-10-23 09:36:05'),
(1781, 1, 'admin/doctors/create', 'GET', '::1', '[]', '2021-10-23 09:37:20', '2021-10-23 09:37:20'),
(1782, 1, 'admin/doctors/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 09:39:35', '2021-10-23 09:39:35'),
(1783, 1, 'admin/doctors/create', 'GET', '::1', '[]', '2021-10-23 09:39:53', '2021-10-23 09:39:53'),
(1784, 1, 'admin/doctors/create', 'GET', '::1', '[]', '2021-10-23 09:40:38', '2021-10-23 09:40:38'),
(1785, 1, 'admin/doctors/create', 'GET', '::1', '[]', '2021-10-23 09:41:31', '2021-10-23 09:41:31'),
(1786, 1, 'admin/doctors/create', 'GET', '::1', '[]', '2021-10-23 09:43:06', '2021-10-23 09:43:06'),
(1787, 1, 'admin/doctors/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 09:44:10', '2021-10-23 09:44:10'),
(1788, 1, 'admin/doctors/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 09:44:26', '2021-10-23 09:44:26'),
(1789, 1, 'admin/doctors/create', 'GET', '::1', '[]', '2021-10-23 09:45:20', '2021-10-23 09:45:20'),
(1790, 1, 'admin/doctors', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 09:45:51', '2021-10-23 09:45:51'),
(1791, 1, 'admin/doctors/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 09:45:54', '2021-10-23 09:45:54'),
(1792, 1, 'admin/doctors/create', 'GET', '::1', '[]', '2021-10-23 09:48:00', '2021-10-23 09:48:00'),
(1793, 1, 'admin/doctors/create', 'GET', '::1', '[]', '2021-10-23 09:49:23', '2021-10-23 09:49:23'),
(1794, 1, 'admin/doctors/create', 'GET', '::1', '[]', '2021-10-23 09:49:37', '2021-10-23 09:49:37'),
(1795, 1, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 09:49:48', '2021-10-23 09:49:48'),
(1796, 1, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 09:49:50', '2021-10-23 09:49:50'),
(1797, 1, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-23 09:50:48', '2021-10-23 09:50:48'),
(1798, 1, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-23 09:52:52', '2021-10-23 09:52:52'),
(1799, 1, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-23 09:54:25', '2021-10-23 09:54:25'),
(1800, 1, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-23 09:57:57', '2021-10-23 09:57:57'),
(1801, 1, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-23 09:59:51', '2021-10-23 09:59:51'),
(1802, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 09:59:53', '2021-10-23 09:59:53'),
(1803, 1, 'admin/doctors', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:00:05', '2021-10-23 10:00:05'),
(1804, 1, 'admin/doctors/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:00:08', '2021-10-23 10:00:08'),
(1805, 1, 'admin/doctors', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:00:14', '2021-10-23 10:00:14'),
(1806, 1, 'admin/doctors/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:00:17', '2021-10-23 10:00:17'),
(1807, 1, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:00:26', '2021-10-23 10:00:26'),
(1808, 1, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:00:29', '2021-10-23 10:00:29'),
(1809, 1, 'admin/vaccination-records', 'GET', '::1', '[]', '2021-10-23 10:00:30', '2021-10-23 10:00:30'),
(1810, 1, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:00:35', '2021-10-23 10:00:35'),
(1811, 1, 'admin/vaccination-records', 'GET', '::1', '[]', '2021-10-23 10:00:36', '2021-10-23 10:00:36'),
(1812, 1, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:00:45', '2021-10-23 10:00:45'),
(1813, 1, 'admin/vaccination-records', 'GET', '::1', '[]', '2021-10-23 10:00:45', '2021-10-23 10:00:45'),
(1814, 1, 'admin/vaccination-records', 'GET', '::1', '[]', '2021-10-23 10:03:01', '2021-10-23 10:03:01'),
(1815, 1, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:03:03', '2021-10-23 10:03:03'),
(1816, 1, 'admin/vaccination-records', 'GET', '::1', '[]', '2021-10-23 10:03:04', '2021-10-23 10:03:04'),
(1817, 1, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:03:28', '2021-10-23 10:03:28'),
(1818, 1, 'admin/vaccination-records', 'GET', '::1', '[]', '2021-10-23 10:03:28', '2021-10-23 10:03:28'),
(1819, 1, 'admin/doctors', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:04:07', '2021-10-23 10:04:07'),
(1820, 1, 'admin/doctors/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:04:09', '2021-10-23 10:04:09'),
(1821, 1, 'admin/doctors', 'POST', '::1', '{\"administrator_id\":\"1\",\"lab_id\":\"1\",\"age\":\"29\",\"gender\":\"Male\",\"phone_number\":\"+8801632257609\",\"address\":\"Kibuli, Kampala, Uganda\",\"nin_number\":\"10299100093\",\"_token\":\"WUJKeXmmn3DvXMy23ImN7OArvInEUV9UXUVASJXx\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/doctors\"}', '2021-10-23 10:04:35', '2021-10-23 10:04:35'),
(1822, 1, 'admin/doctors', 'GET', '::1', '[]', '2021-10-23 10:04:36', '2021-10-23 10:04:36'),
(1823, 1, 'admin/doctors', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:04:39', '2021-10-23 10:04:39'),
(1824, 1, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:04:42', '2021-10-23 10:04:42'),
(1825, 1, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:04:44', '2021-10-23 10:04:44'),
(1826, 1, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:06:28', '2021-10-23 10:06:28'),
(1827, 1, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-23 10:08:14', '2021-10-23 10:08:14'),
(1828, 1, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-23 10:09:20', '2021-10-23 10:09:20'),
(1829, 1, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-23 10:10:04', '2021-10-23 10:10:04'),
(1830, 1, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:11:33', '2021-10-23 10:11:33'),
(1831, 1, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-23 10:13:40', '2021-10-23 10:13:40'),
(1832, 1, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-23 10:15:09', '2021-10-23 10:15:09'),
(1833, 1, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:17:10', '2021-10-23 10:17:10'),
(1834, 1, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:19:44', '2021-10-23 10:19:44'),
(1835, 1, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:20:45', '2021-10-23 10:20:45'),
(1836, 1, 'admin/vaccination-records', 'POST', '::1', '{\"administrator_id\":\"1\",\"lab_id\":\"1\",\"full_name\":\"Muhindo Mubaraka\",\"age\":\"30\",\"gender\":\"Male\",\"address\":\"Kibuli, Kampala, Uganda\",\"phone_number\":\"+256706638494\",\"nin_number\":\"10299100093\",\"type\":\"First dose\",\"next_vaccination\":\"2021-10-25 13:20:45\",\"_token\":\"WUJKeXmmn3DvXMy23ImN7OArvInEUV9UXUVASJXx\"}', '2021-10-23 10:22:01', '2021-10-23 10:22:01'),
(1837, 1, 'admin/vaccination-records', 'GET', '::1', '[]', '2021-10-23 10:22:01', '2021-10-23 10:22:01'),
(1838, 1, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:25:34', '2021-10-23 10:25:34'),
(1839, 1, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:25:55', '2021-10-23 10:25:55'),
(1840, 1, 'admin/vaccination-records', 'GET', '::1', '[]', '2021-10-23 10:26:41', '2021-10-23 10:26:41'),
(1841, 1, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:26:46', '2021-10-23 10:26:46'),
(1842, 1, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:27:32', '2021-10-23 10:27:32'),
(1843, 1, 'admin/vaccination-records', 'GET', '::1', '[]', '2021-10-23 10:28:49', '2021-10-23 10:28:49'),
(1844, 1, 'admin/vaccination-records', 'GET', '::1', '[]', '2021-10-23 10:32:15', '2021-10-23 10:32:15'),
(1845, 1, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:32:37', '2021-10-23 10:32:37'),
(1846, 1, 'admin/vaccination-records', 'GET', '::1', '[]', '2021-10-23 10:32:45', '2021-10-23 10:32:45'),
(1847, 1, 'admin/vaccination-records', 'GET', '::1', '[]', '2021-10-23 10:33:18', '2021-10-23 10:33:18'),
(1848, 1, 'admin/vaccination-records', 'GET', '::1', '[]', '2021-10-23 10:34:28', '2021-10-23 10:34:28'),
(1849, 1, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:34:33', '2021-10-23 10:34:33'),
(1850, 1, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:34:35', '2021-10-23 10:34:35'),
(1851, 1, 'admin/vaccination-records', 'GET', '::1', '[]', '2021-10-23 10:35:02', '2021-10-23 10:35:02'),
(1852, 1, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:35:13', '2021-10-23 10:35:13'),
(1853, 1, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:36:55', '2021-10-23 10:36:55'),
(1854, 1, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:37:06', '2021-10-23 10:37:06'),
(1855, 1, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:37:13', '2021-10-23 10:37:13'),
(1856, 1, 'admin/vaccination-records-2', 'GET', '::1', '[]', '2021-10-23 10:38:45', '2021-10-23 10:38:45'),
(1857, 1, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:39:10', '2021-10-23 10:39:10'),
(1858, 1, 'admin/auth/menu', 'POST', '::1', '{\"parent_id\":\"0\",\"title\":\"Vaccination - 2nd Dose\",\"icon\":\"fa-check\",\"uri\":\"vaccination-records-2\",\"roles\":[null],\"permission\":null,\"_token\":\"WUJKeXmmn3DvXMy23ImN7OArvInEUV9UXUVASJXx\"}', '2021-10-23 10:40:12', '2021-10-23 10:40:12'),
(1859, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 10:40:13', '2021-10-23 10:40:13'),
(1860, 1, 'admin/auth/menu', 'POST', '::1', '{\"parent_id\":\"0\",\"title\":null,\"icon\":\"fa-bars\",\"uri\":null,\"roles\":[null],\"permission\":null,\"_token\":\"WUJKeXmmn3DvXMy23ImN7OArvInEUV9UXUVASJXx\"}', '2021-10-23 10:40:20', '2021-10-23 10:40:20'),
(1861, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 10:40:21', '2021-10-23 10:40:21'),
(1862, 1, 'admin/auth/menu', 'POST', '::1', '{\"_token\":\"WUJKeXmmn3DvXMy23ImN7OArvInEUV9UXUVASJXx\",\"_order\":\"[{\\\"id\\\":16},{\\\"id\\\":17},{\\\"id\\\":18},{\\\"id\\\":20},{\\\"id\\\":19},{\\\"id\\\":21},{\\\"id\\\":1},{\\\"id\\\":2,\\\"children\\\":[{\\\"id\\\":3},{\\\"id\\\":4},{\\\"id\\\":5},{\\\"id\\\":6},{\\\"id\\\":7}]},{\\\"id\\\":10},{\\\"id\\\":8}]\"}', '2021-10-23 10:40:33', '2021-10-23 10:40:33'),
(1863, 1, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:40:35', '2021-10-23 10:40:35'),
(1864, 1, 'admin/auth/menu/19/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:40:43', '2021-10-23 10:40:43'),
(1865, 1, 'admin/auth/menu/19', 'PUT', '::1', '{\"parent_id\":\"0\",\"title\":\"Vaccination - 1st dose\",\"icon\":\"fa-book\",\"uri\":\"vaccination-records\",\"roles\":[null],\"permission\":null,\"_token\":\"WUJKeXmmn3DvXMy23ImN7OArvInEUV9UXUVASJXx\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/auth\\/menu\"}', '2021-10-23 10:40:57', '2021-10-23 10:40:57'),
(1866, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 10:40:57', '2021-10-23 10:40:57'),
(1867, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 10:41:02', '2021-10-23 10:41:02'),
(1868, 1, 'admin/vaccination-records-2', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:41:05', '2021-10-23 10:41:05'),
(1869, 1, 'admin/vaccination-records-2', 'GET', '::1', '[]', '2021-10-23 10:42:02', '2021-10-23 10:42:02'),
(1870, 1, 'admin/vaccination-records-2', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:42:18', '2021-10-23 10:42:18'),
(1871, 1, 'admin/vaccination-records-2', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:43:17', '2021-10-23 10:43:17'),
(1872, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:43:29', '2021-10-23 10:43:29'),
(1873, 1, 'admin/vaccination-records-2', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:43:31', '2021-10-23 10:43:31'),
(1874, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:43:34', '2021-10-23 10:43:34'),
(1875, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '[]', '2021-10-23 10:44:08', '2021-10-23 10:44:08'),
(1876, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:49:34', '2021-10-23 10:49:34'),
(1877, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:50:01', '2021-10-23 10:50:01'),
(1878, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:50:26', '2021-10-23 10:50:26'),
(1879, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '[]', '2021-10-23 10:52:29', '2021-10-23 10:52:29'),
(1880, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:53:58', '2021-10-23 10:53:58'),
(1881, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '[]', '2021-10-23 10:58:04', '2021-10-23 10:58:04'),
(1882, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '[]', '2021-10-23 10:58:21', '2021-10-23 10:58:21'),
(1883, 1, 'admin/vaccination-records-2', 'POST', '::1', '{\"administrator_id\":\"1\",\"lab_id\":\"1\",\"full_name\":\"1\",\"type\":\"Second dose\",\"next_vaccination\":\"2021-10-23 13:58:21\",\"_token\":\"WUJKeXmmn3DvXMy23ImN7OArvInEUV9UXUVASJXx\",\"after-save\":\"1\"}', '2021-10-23 10:58:28', '2021-10-23 10:58:28'),
(1884, 1, 'admin/vaccination-records-2/2/edit', 'GET', '::1', '[]', '2021-10-23 10:58:28', '2021-10-23 10:58:28'),
(1885, 1, 'admin/vaccination-records-2', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:58:36', '2021-10-23 10:58:36'),
(1886, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:58:38', '2021-10-23 10:58:38'),
(1887, 1, 'admin/vaccination-records-2', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:58:46', '2021-10-23 10:58:46'),
(1888, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:58:50', '2021-10-23 10:58:50'),
(1889, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 10:58:57', '2021-10-23 10:58:57'),
(1890, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '[]', '2021-10-23 10:59:01', '2021-10-23 10:59:01'),
(1891, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '[]', '2021-10-23 10:59:25', '2021-10-23 10:59:25'),
(1892, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '[]', '2021-10-23 11:00:01', '2021-10-23 11:00:01'),
(1893, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '[]', '2021-10-23 11:00:55', '2021-10-23 11:00:55'),
(1894, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '[]', '2021-10-23 11:01:54', '2021-10-23 11:01:54'),
(1895, 1, 'admin', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 11:02:22', '2021-10-23 11:02:22'),
(1896, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 11:02:24', '2021-10-23 11:02:24'),
(1897, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '[]', '2021-10-23 11:02:27', '2021-10-23 11:02:27'),
(1898, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '[]', '2021-10-23 11:02:46', '2021-10-23 11:02:46'),
(1899, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '[]', '2021-10-23 11:03:19', '2021-10-23 11:03:19'),
(1900, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '[]', '2021-10-23 11:03:38', '2021-10-23 11:03:38'),
(1901, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '[]', '2021-10-23 11:04:02', '2021-10-23 11:04:02'),
(1902, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '[]', '2021-10-23 11:04:54', '2021-10-23 11:04:54'),
(1903, 1, 'admin/vaccination-records-2/create', 'GET', '::1', '[]', '2021-10-23 11:05:02', '2021-10-23 11:05:02'),
(1904, 1, 'admin/doctors', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 11:05:11', '2021-10-23 11:05:11'),
(1905, 1, 'admin/vaccination-records-2', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 11:05:12', '2021-10-23 11:05:12'),
(1906, 1, 'admin/vaccination-records-2', 'GET', '::1', '[]', '2021-10-23 11:07:25', '2021-10-23 11:07:25'),
(1907, 1, 'admin/vaccination-records-2', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 11:07:38', '2021-10-23 11:07:38'),
(1908, 1, 'admin/vaccination-records-2', 'GET', '::1', '[]', '2021-10-23 11:07:59', '2021-10-23 11:07:59'),
(1909, 1, 'admin', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 11:08:48', '2021-10-23 11:08:48'),
(1910, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 11:08:48', '2021-10-23 11:08:48'),
(1911, 1, 'admin/vaccination-records-2', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 11:08:49', '2021-10-23 11:08:49'),
(1912, 1, 'admin/vaccination-records-2', 'GET', '::1', '[]', '2021-10-23 11:08:50', '2021-10-23 11:08:50'),
(1913, 1, 'admin/vaccination-records-2', 'GET', '::1', '[]', '2021-10-23 11:09:13', '2021-10-23 11:09:13'),
(1914, 1, 'admin/vaccination-records-2', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 11:09:23', '2021-10-23 11:09:23'),
(1915, 1, 'admin/vaccination-records-2', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 11:09:31', '2021-10-23 11:09:31'),
(1916, 1, 'admin', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 11:09:33', '2021-10-23 11:09:33'),
(1917, 1, 'admin/vaccination-records-2', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 11:09:39', '2021-10-23 11:09:39'),
(1918, 1, 'admin/vaccination-records-2', 'GET', '::1', '[]', '2021-10-23 12:24:47', '2021-10-23 12:24:47'),
(1919, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 14:49:11', '2021-10-23 14:49:11'),
(1920, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:02:34', '2021-10-23 15:02:34'),
(1921, 1, 'admin', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:04:44', '2021-10-23 15:04:44'),
(1922, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:13:03', '2021-10-23 15:13:03'),
(1923, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:13:27', '2021-10-23 15:13:27'),
(1924, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:13:38', '2021-10-23 15:13:38'),
(1925, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:13:48', '2021-10-23 15:13:48'),
(1926, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:14:09', '2021-10-23 15:14:09'),
(1927, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:15:47', '2021-10-23 15:15:47'),
(1928, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:16:24', '2021-10-23 15:16:24'),
(1929, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:18:11', '2021-10-23 15:18:11'),
(1930, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:18:25', '2021-10-23 15:18:25'),
(1931, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:20:56', '2021-10-23 15:20:56'),
(1932, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:21:17', '2021-10-23 15:21:17'),
(1933, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:22:33', '2021-10-23 15:22:33'),
(1934, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:23:05', '2021-10-23 15:23:05'),
(1935, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:25:14', '2021-10-23 15:25:14'),
(1936, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:27:22', '2021-10-23 15:27:22'),
(1937, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:27:34', '2021-10-23 15:27:34'),
(1938, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:28:07', '2021-10-23 15:28:07'),
(1939, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:28:30', '2021-10-23 15:28:30'),
(1940, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:28:47', '2021-10-23 15:28:47'),
(1941, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:28:59', '2021-10-23 15:28:59'),
(1942, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 15:29:13', '2021-10-23 15:29:13'),
(1943, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:29:49', '2021-10-23 15:29:49'),
(1944, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:29:58', '2021-10-23 15:29:58'),
(1945, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:30:45', '2021-10-23 15:30:45'),
(1946, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:31:15', '2021-10-23 15:31:15'),
(1947, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:31:49', '2021-10-23 15:31:49'),
(1948, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:32:40', '2021-10-23 15:32:40'),
(1949, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:33:48', '2021-10-23 15:33:48'),
(1950, 1, 'admin/users', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:34:06', '2021-10-23 15:34:06'),
(1951, 1, 'admin', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:34:08', '2021-10-23 15:34:08'),
(1952, 1, 'admin/auth/users', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:34:16', '2021-10-23 15:34:16'),
(1953, 1, 'admin', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:34:20', '2021-10-23 15:34:20'),
(1954, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:34:27', '2021-10-23 15:34:27'),
(1955, 1, 'admin/auth/users', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:34:29', '2021-10-23 15:34:29'),
(1956, 1, 'admin', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:34:32', '2021-10-23 15:34:32'),
(1957, 1, 'admin/districts', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:34:33', '2021-10-23 15:34:33'),
(1958, 1, 'admin', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:34:35', '2021-10-23 15:34:35'),
(1959, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:37:01', '2021-10-23 15:37:01'),
(1960, 1, 'admin/districts', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:37:14', '2021-10-23 15:37:14'),
(1961, 1, 'admin/districts/1/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:37:19', '2021-10-23 15:37:19'),
(1962, 1, 'admin/districts/1/edit', 'GET', '::1', '[]', '2021-10-23 15:38:33', '2021-10-23 15:38:33'),
(1963, 1, 'admin/districts/1/edit', 'GET', '::1', '[]', '2021-10-23 15:38:51', '2021-10-23 15:38:51'),
(1964, 1, 'admin/districts/1', 'PUT', '::1', '{\"name\":\"Kasese\",\"administrator_id\":\"2\",\"population\":\"2000000\",\"details\":\"kampala\",\"latitude\":\"0.1183366\",\"longitude\":\"29.7230851\",\"_token\":\"WUJKeXmmn3DvXMy23ImN7OArvInEUV9UXUVASJXx\",\"_method\":\"PUT\"}', '2021-10-23 15:39:12', '2021-10-23 15:39:12'),
(1965, 1, 'admin/districts', 'GET', '::1', '[]', '2021-10-23 15:39:12', '2021-10-23 15:39:12'),
(1966, 1, 'admin/districts', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:39:16', '2021-10-23 15:39:16'),
(1967, 1, 'admin', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:39:20', '2021-10-23 15:39:20'),
(1968, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:39:50', '2021-10-23 15:39:50'),
(1969, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:41:44', '2021-10-23 15:41:44'),
(1970, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:42:24', '2021-10-23 15:42:24'),
(1971, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:42:35', '2021-10-23 15:42:35'),
(1972, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:43:31', '2021-10-23 15:43:31'),
(1973, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:43:35', '2021-10-23 15:43:35'),
(1974, 1, 'admin', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:43:48', '2021-10-23 15:43:48'),
(1975, 1, 'admin', 'GET', '::1', '[]', '2021-10-23 15:44:35', '2021-10-23 15:44:35'),
(1976, 1, 'admin', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:44:39', '2021-10-23 15:44:39'),
(1977, 1, 'admin/vaccination-records-2', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:44:52', '2021-10-23 15:44:52'),
(1978, 1, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:45:00', '2021-10-23 15:45:00'),
(1979, 1, 'admin/districts', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:45:16', '2021-10-23 15:45:16'),
(1980, 1, 'admin/districts', 'GET', '::1', '[]', '2021-10-23 15:45:28', '2021-10-23 15:45:28'),
(1981, 1, 'admin/doctors', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:45:33', '2021-10-23 15:45:33'),
(1982, 1, 'admin/doctors', 'GET', '::1', '[]', '2021-10-23 15:46:20', '2021-10-23 15:46:20'),
(1983, 1, 'admin/doctors', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:46:43', '2021-10-23 15:46:43'),
(1984, 1, 'admin/doctors', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:47:24', '2021-10-23 15:47:24'),
(1985, 1, 'admin/doctors', 'GET', '::1', '[]', '2021-10-23 15:47:51', '2021-10-23 15:47:51'),
(1986, 1, 'admin/doctors/1/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:47:58', '2021-10-23 15:47:58'),
(1987, 1, 'admin/doctors', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:48:05', '2021-10-23 15:48:05'),
(1988, 1, 'admin/districts', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:48:12', '2021-10-23 15:48:12'),
(1989, 1, 'admin/doctors', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:48:21', '2021-10-23 15:48:21'),
(1990, 1, 'admin/doctors', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:48:36', '2021-10-23 15:48:36'),
(1991, 1, 'admin/doctors/1/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:48:39', '2021-10-23 15:48:39'),
(1992, 1, 'admin/doctors/1', 'PUT', '::1', '{\"administrator_id\":\"1\",\"lab_id\":\"1\",\"age\":\"29\",\"gender\":\"Male\",\"phone_number\":\"+8801632257609\",\"address\":\"Kibuli, Kampala, Uganda\",\"nin_number\":\"10299100093\",\"_token\":\"WUJKeXmmn3DvXMy23ImN7OArvInEUV9UXUVASJXx\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/doctors\"}', '2021-10-23 15:48:49', '2021-10-23 15:48:49'),
(1993, 1, 'admin/doctors/1/edit', 'GET', '::1', '[]', '2021-10-23 15:48:50', '2021-10-23 15:48:50'),
(1994, 1, 'admin/doctors', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:49:09', '2021-10-23 15:49:09'),
(1995, 1, 'admin/doctors', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:49:44', '2021-10-23 15:49:44'),
(1996, 1, 'admin/doctors/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:49:47', '2021-10-23 15:49:47'),
(1997, 1, 'admin/doctors/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:49:58', '2021-10-23 15:49:58'),
(1998, 1, 'admin/auth/roles', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:50:48', '2021-10-23 15:50:48'),
(1999, 1, 'admin/auth/roles/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:51:09', '2021-10-23 15:51:09'),
(2000, 1, 'admin/auth/roles', 'POST', '::1', '{\"slug\":\"doctor\",\"name\":\"doctor\",\"permissions\":[\"1\",null],\"_token\":\"WUJKeXmmn3DvXMy23ImN7OArvInEUV9UXUVASJXx\",\"after-save\":\"1\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/auth\\/roles\"}', '2021-10-23 15:51:39', '2021-10-23 15:51:39'),
(2001, 1, 'admin/auth/roles/5/edit', 'GET', '::1', '[]', '2021-10-23 15:51:39', '2021-10-23 15:51:39'),
(2002, 1, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:52:59', '2021-10-23 15:52:59'),
(2003, 1, 'admin/auth/menu/16/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:53:08', '2021-10-23 15:53:08'),
(2004, 1, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:53:14', '2021-10-23 15:53:14'),
(2005, 1, 'admin/districts', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:53:17', '2021-10-23 15:53:17'),
(2006, 1, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:53:31', '2021-10-23 15:53:31'),
(2007, 1, 'admin/auth/menu/16/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:53:35', '2021-10-23 15:53:35'),
(2008, 1, 'admin/auth/menu/16', 'PUT', '::1', '{\"parent_id\":\"0\",\"title\":\"Districts\",\"icon\":\"fa-building\",\"uri\":\"districts\",\"roles\":[\"1\",\"2\",null],\"permission\":null,\"_token\":\"WUJKeXmmn3DvXMy23ImN7OArvInEUV9UXUVASJXx\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/auth\\/menu\"}', '2021-10-23 15:53:47', '2021-10-23 15:53:47'),
(2009, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 15:53:48', '2021-10-23 15:53:48'),
(2010, 1, 'admin/auth/menu/17/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:53:52', '2021-10-23 15:53:52'),
(2011, 1, 'admin/auth/menu/17', 'PUT', '::1', '{\"parent_id\":\"0\",\"title\":\"Laboratories\",\"icon\":\"fa-gitlab\",\"uri\":\"labs\",\"roles\":[\"1\",\"2\",null],\"permission\":null,\"_token\":\"WUJKeXmmn3DvXMy23ImN7OArvInEUV9UXUVASJXx\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/auth\\/menu\"}', '2021-10-23 15:54:04', '2021-10-23 15:54:04'),
(2012, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 15:54:05', '2021-10-23 15:54:05'),
(2013, 1, 'admin/auth/menu/18/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:54:11', '2021-10-23 15:54:11'),
(2014, 1, 'admin/auth/menu/18', 'PUT', '::1', '{\"parent_id\":\"0\",\"title\":\"Stock records\",\"icon\":\"fa-dropbox\",\"uri\":\"stock-records\",\"roles\":[\"1\",\"2\",null],\"permission\":null,\"_token\":\"WUJKeXmmn3DvXMy23ImN7OArvInEUV9UXUVASJXx\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/auth\\/menu\"}', '2021-10-23 15:54:31', '2021-10-23 15:54:31'),
(2015, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 15:54:31', '2021-10-23 15:54:31'),
(2016, 1, 'admin/auth/menu/20/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:54:37', '2021-10-23 15:54:37'),
(2017, 1, 'admin/auth/menu/20', 'PUT', '::1', '{\"parent_id\":\"0\",\"title\":\"Doctors\",\"icon\":\"fa-user-md\",\"uri\":\"doctors\",\"roles\":[\"1\",\"2\",null],\"permission\":null,\"_token\":\"WUJKeXmmn3DvXMy23ImN7OArvInEUV9UXUVASJXx\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/auth\\/menu\"}', '2021-10-23 15:54:47', '2021-10-23 15:54:47'),
(2018, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 15:54:47', '2021-10-23 15:54:47'),
(2019, 1, 'admin/auth/menu/2/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:54:57', '2021-10-23 15:54:57'),
(2020, 1, 'admin/auth/menu/2', 'PUT', '::1', '{\"parent_id\":\"0\",\"title\":\"Admin\",\"icon\":\"fa-tasks\",\"uri\":null,\"roles\":[\"1\",\"2\",null],\"permission\":null,\"_token\":\"WUJKeXmmn3DvXMy23ImN7OArvInEUV9UXUVASJXx\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/auth\\/menu\"}', '2021-10-23 15:55:03', '2021-10-23 15:55:03'),
(2021, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-23 15:55:04', '2021-10-23 15:55:04'),
(2022, 1, 'admin/auth/menu/8/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:55:09', '2021-10-23 15:55:09'),
(2023, 1, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:55:13', '2021-10-23 15:55:13'),
(2024, 1, 'admin/auth/users', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:55:23', '2021-10-23 15:55:23'),
(2025, 1, 'admin/auth/users/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:55:27', '2021-10-23 15:55:27'),
(2026, 1, 'admin/auth/users', 'POST', '::1', '{\"username\":\"doctor\",\"name\":\"Kule John\",\"password\":\"4321\",\"password_confirmation\":\"4321\",\"roles\":[\"5\",null],\"permissions\":[null],\"_token\":\"WUJKeXmmn3DvXMy23ImN7OArvInEUV9UXUVASJXx\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/auth\\/users\"}', '2021-10-23 15:56:03', '2021-10-23 15:56:03'),
(2027, 1, 'admin/auth/users', 'GET', '::1', '[]', '2021-10-23 15:56:04', '2021-10-23 15:56:04'),
(2028, 1, 'admin/auth/users', 'GET', '::1', '[]', '2021-10-23 15:56:29', '2021-10-23 15:56:29'),
(2029, 1, 'admin/auth/logout', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:56:33', '2021-10-23 15:56:33'),
(2030, 5, 'admin', 'GET', '::1', '[]', '2021-10-23 15:56:47', '2021-10-23 15:56:47'),
(2031, 5, 'admin/auth/setting', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:57:00', '2021-10-23 15:57:00'),
(2032, 1, 'admin/auth/users', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:57:55', '2021-10-23 15:57:55'),
(2033, 1, 'admin/auth/users', 'GET', '::1', '[]', '2021-10-23 15:57:59', '2021-10-23 15:57:59'),
(2034, 5, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:58:14', '2021-10-23 15:58:14'),
(2035, 5, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:58:16', '2021-10-23 15:58:16'),
(2036, 5, 'admin/vaccination-records', 'GET', '::1', '[]', '2021-10-23 15:58:16', '2021-10-23 15:58:16'),
(2037, 5, 'admin/auth/logout', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:58:38', '2021-10-23 15:58:38'),
(2038, 1, 'admin/auth/logout', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 15:58:57', '2021-10-23 15:58:57'),
(2039, 5, 'admin', 'GET', '::1', '[]', '2021-10-23 16:14:27', '2021-10-23 16:14:27'),
(2040, 5, 'admin/auth/setting', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 16:14:42', '2021-10-23 16:14:42'),
(2041, 5, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 16:18:03', '2021-10-23 16:18:03'),
(2042, 5, 'admin/auth/setting', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 16:18:05', '2021-10-23 16:18:05');
INSERT INTO `admin_operation_log` (`id`, `user_id`, `path`, `method`, `ip`, `input`, `created_at`, `updated_at`) VALUES
(2043, 5, 'admin/auth/setting', 'PUT', '::1', '{\"name\":\"Kule John\",\"password\":\"4321\",\"password_confirmation\":\"4321\",\"_token\":\"gKsCheiYShyRXHfHTKdWmTOClU8fRkUXTtQIUAGP\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/vaccination-records\"}', '2021-10-23 16:18:36', '2021-10-23 16:18:36'),
(2044, 5, 'admin/auth/setting', 'GET', '::1', '[]', '2021-10-23 16:18:37', '2021-10-23 16:18:37'),
(2045, 5, 'admin/auth/setting', 'PUT', '::1', '{\"name\":\"Kule John\",\"password\":\"$2y$10$wFX3LtxO7lBGfzZCYvmFmOMBycz98zB9kDVk5.Dh.VswhdvKvlmji\",\"password_confirmation\":\"$2y$10$wFX3LtxO7lBGfzZCYvmFmOMBycz98zB9kDVk5.Dh.VswhdvKvlmji\",\"_token\":\"gKsCheiYShyRXHfHTKdWmTOClU8fRkUXTtQIUAGP\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-23 16:19:25', '2021-10-23 16:19:25'),
(2046, 5, 'admin/auth/setting', 'GET', '::1', '[]', '2021-10-23 16:19:25', '2021-10-23 16:19:25'),
(2047, 5, 'admin/auth/setting', 'PUT', '::1', '{\"name\":\"Kule John\",\"password\":\"$2y$10$YYPDXRbemvd\\/Kh8aXW0B5.Q5UnE\\/UtHg6vLKHljJSnGg5qgKrJM2q\",\"password_confirmation\":\"$2y$10$YYPDXRbemvd\\/Kh8aXW0B5.Q5UnE\\/UtHg6vLKHljJSnGg5qgKrJM2q\",\"_token\":\"gKsCheiYShyRXHfHTKdWmTOClU8fRkUXTtQIUAGP\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\"}', '2021-10-23 16:22:50', '2021-10-23 16:22:50'),
(2048, 5, 'admin/auth/setting', 'GET', '::1', '[]', '2021-10-23 16:22:51', '2021-10-23 16:22:51'),
(2049, 5, 'admin/auth/setting', 'PUT', '::1', '{\"name\":\"Kule John\",\"password\":\"$2y$10$wFX3LtxO7lBGfzZCYvmFmOMBycz98zB9kDVk5.Dh.VswhdvKvlmji\",\"password_confirmation\":\"$2y$10$wFX3LtxO7lBGfzZCYvmFmOMBycz98zB9kDVk5.Dh.VswhdvKvlmji\",\"_token\":\"gKsCheiYShyRXHfHTKdWmTOClU8fRkUXTtQIUAGP\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-23 16:25:08', '2021-10-23 16:25:08'),
(2050, 5, 'admin/auth/setting', 'GET', '::1', '[]', '2021-10-23 16:25:09', '2021-10-23 16:25:09'),
(2051, 5, 'admin/auth/setting', 'PUT', '::1', '{\"name\":\"Kule John\",\"password\":\"$2y$10$glaQ7Udf7hymmJcN3nXk3O3bZpxvzmnzgaAjPtYfgIjdOL\\/8Ic.qe\",\"password_confirmation\":\"$2y$10$glaQ7Udf7hymmJcN3nXk3O3bZpxvzmnzgaAjPtYfgIjdOL\\/8Ic.qe\",\"_token\":\"gKsCheiYShyRXHfHTKdWmTOClU8fRkUXTtQIUAGP\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-23 16:25:57', '2021-10-23 16:25:57'),
(2052, 5, 'admin/auth/setting', 'GET', '::1', '[]', '2021-10-23 16:25:58', '2021-10-23 16:25:58'),
(2053, 5, 'admin/auth/setting', 'PUT', '::1', '{\"name\":\"Kule John\",\"password\":\"$2y$10$glaQ7Udf7hymmJcN3nXk3O3bZpxvzmnzgaAjPtYfgIjdOL\\/8Ic.qe\",\"password_confirmation\":\"$2y$10$glaQ7Udf7hymmJcN3nXk3O3bZpxvzmnzgaAjPtYfgIjdOL\\/8Ic.qe\",\"_token\":\"gKsCheiYShyRXHfHTKdWmTOClU8fRkUXTtQIUAGP\",\"_method\":\"PUT\"}', '2021-10-23 16:27:31', '2021-10-23 16:27:31'),
(2054, 5, 'admin/auth/setting', 'GET', '::1', '[]', '2021-10-23 16:27:32', '2021-10-23 16:27:32'),
(2055, 5, 'admin/auth/setting', 'PUT', '::1', '{\"name\":\"Kule John\",\"password\":\"$2y$10$glaQ7Udf7hymmJcN3nXk3O3bZpxvzmnzgaAjPtYfgIjdOL\\/8Ic.qe\",\"password_confirmation\":\"$2y$10$glaQ7Udf7hymmJcN3nXk3O3bZpxvzmnzgaAjPtYfgIjdOL\\/8Ic.qe\",\"_token\":\"gKsCheiYShyRXHfHTKdWmTOClU8fRkUXTtQIUAGP\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-23 16:29:34', '2021-10-23 16:29:34'),
(2056, 5, 'admin/auth/setting', 'GET', '::1', '[]', '2021-10-23 16:29:34', '2021-10-23 16:29:34'),
(2057, 5, 'admin/auth/setting', 'GET', '::1', '[]', '2021-10-23 16:29:54', '2021-10-23 16:29:54'),
(2058, 5, 'admin/auth/setting', 'PUT', '::1', '{\"name\":\"Kule John\",\"password\":\"$2y$10$glaQ7Udf7hymmJcN3nXk3O3bZpxvzmnzgaAjPtYfgIjdOL\\/8Ic.qe\",\"password_confirmation\":\"$2y$10$glaQ7Udf7hymmJcN3nXk3O3bZpxvzmnzgaAjPtYfgIjdOL\\/8Ic.qe\",\"_token\":\"gKsCheiYShyRXHfHTKdWmTOClU8fRkUXTtQIUAGP\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\"}', '2021-10-23 16:30:05', '2021-10-23 16:30:05'),
(2059, 5, 'admin/auth/setting', 'GET', '::1', '[]', '2021-10-23 16:30:05', '2021-10-23 16:30:05'),
(2060, 5, 'admin/auth/setting', 'GET', '::1', '[]', '2021-10-23 16:31:04', '2021-10-23 16:31:04'),
(2061, 5, 'admin/auth/setting', 'PUT', '::1', '{\"name\":\"Kule John\",\"password\":\"$2y$10$glaQ7Udf7hymmJcN3nXk3O3bZpxvzmnzgaAjPtYfgIjdOL\\/8Ic.qe\",\"password_confirmation\":\"$2y$10$glaQ7Udf7hymmJcN3nXk3O3bZpxvzmnzgaAjPtYfgIjdOL\\/8Ic.qe\",\"_token\":\"gKsCheiYShyRXHfHTKdWmTOClU8fRkUXTtQIUAGP\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-23 16:31:14', '2021-10-23 16:31:14'),
(2062, 5, 'admin/auth/setting', 'GET', '::1', '[]', '2021-10-23 16:31:14', '2021-10-23 16:31:14'),
(2063, 5, 'admin/auth/setting', 'PUT', '::1', '{\"name\":\"Kule John\",\"password\":\"$2y$10$glaQ7Udf7hymmJcN3nXk3O3bZpxvzmnzgaAjPtYfgIjdOL\\/8Ic.qe\",\"password_confirmation\":\"$2y$10$glaQ7Udf7hymmJcN3nXk3O3bZpxvzmnzgaAjPtYfgIjdOL\\/8Ic.qe\",\"_token\":\"gKsCheiYShyRXHfHTKdWmTOClU8fRkUXTtQIUAGP\",\"after-save\":\"1\",\"_method\":\"PUT\"}', '2021-10-23 16:31:54', '2021-10-23 16:31:54'),
(2064, 5, 'admin/auth/setting', 'GET', '::1', '[]', '2021-10-23 16:31:54', '2021-10-23 16:31:54'),
(2065, 5, 'admin/auth/setting', 'GET', '::1', '[]', '2021-10-23 16:32:25', '2021-10-23 16:32:25'),
(2066, 5, 'admin/auth/setting', 'PUT', '::1', '{\"name\":\"Kule John\",\"password\":\"$2y$10$glaQ7Udf7hymmJcN3nXk3O3bZpxvzmnzgaAjPtYfgIjdOL\\/8Ic.qe\",\"password_confirmation\":\"$2y$10$glaQ7Udf7hymmJcN3nXk3O3bZpxvzmnzgaAjPtYfgIjdOL\\/8Ic.qe\",\"_token\":\"gKsCheiYShyRXHfHTKdWmTOClU8fRkUXTtQIUAGP\",\"_method\":\"PUT\"}', '2021-10-23 16:32:37', '2021-10-23 16:32:37'),
(2067, 5, 'admin/auth/setting', 'GET', '::1', '[]', '2021-10-23 16:32:37', '2021-10-23 16:32:37'),
(2068, 5, 'admin/auth/logout', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 16:35:18', '2021-10-23 16:35:18'),
(2069, 2, 'admin', 'GET', '::1', '[]', '2021-10-23 16:35:49', '2021-10-23 16:35:49'),
(2070, 2, 'admin/auth/setting', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 16:35:57', '2021-10-23 16:35:57'),
(2071, 2, 'admin/doctors', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 16:36:01', '2021-10-23 16:36:01'),
(2072, 2, 'admin/doctors/1/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-23 16:36:04', '2021-10-23 16:36:04'),
(2073, 2, 'admin/doctors/1', 'PUT', '::1', '{\"administrator_id\":\"1\",\"lab_id\":\"1\",\"age\":\"29\",\"gender\":\"Male\",\"phone_number\":\"+8801632257609\",\"address\":\"Kibuli, Kampala, Uganda\",\"nin_number\":\"10299100093\",\"_token\":\"J8DYotgXEbiHnI4rQVUl6pvafv9B0NNPqJBvvC2S\",\"after-save\":\"1\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/doctors\"}', '2021-10-23 16:36:14', '2021-10-23 16:36:14'),
(2074, 2, 'admin/doctors/1/edit', 'GET', '::1', '[]', '2021-10-23 16:36:14', '2021-10-23 16:36:14'),
(2075, 2, 'admin/auth/setting', 'GET', '::1', '[]', '2021-10-24 09:19:39', '2021-10-24 09:19:39'),
(2076, 2, 'admin', 'GET', '::1', '[]', '2021-10-24 10:17:23', '2021-10-24 10:17:23'),
(2077, 2, 'admin', 'GET', '::1', '[]', '2021-10-24 10:39:52', '2021-10-24 10:39:52'),
(2078, 2, 'admin/form-sr6s/create', 'GET', '::1', '[]', '2021-10-24 10:40:02', '2021-10-24 10:40:02'),
(2079, 2, 'admin/form-sr6s/create', 'GET', '::1', '[]', '2021-10-24 10:40:04', '2021-10-24 10:40:04'),
(2080, 3, 'admin', 'GET', '::1', '[]', '2021-10-26 01:41:24', '2021-10-26 01:41:24'),
(2081, 3, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 01:41:35', '2021-10-26 01:41:35'),
(2082, 3, 'admin/vaccination-records-2', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 01:41:38', '2021-10-26 01:41:38'),
(2083, 3, 'admin', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 01:41:40', '2021-10-26 01:41:40'),
(2084, 3, 'admin/auth/setting', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 01:41:44', '2021-10-26 01:41:44'),
(2085, 3, 'admin', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 01:41:46', '2021-10-26 01:41:46'),
(2086, 3, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 01:41:58', '2021-10-26 01:41:58'),
(2087, 3, 'admin/vaccination-records/1', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 01:42:03', '2021-10-26 01:42:03'),
(2088, 2, 'admin', 'GET', '::1', '[]', '2021-10-26 04:27:51', '2021-10-26 04:27:51'),
(2089, 2, 'admin', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:28:24', '2021-10-26 04:28:24'),
(2090, 2, 'admin/auth/setting', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:28:28', '2021-10-26 04:28:28'),
(2091, 2, 'admin', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:28:35', '2021-10-26 04:28:35'),
(2092, 2, 'admin/districts', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:29:52', '2021-10-26 04:29:52'),
(2093, 2, 'admin/districts/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:30:32', '2021-10-26 04:30:32'),
(2094, 2, 'admin/doctors', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:31:01', '2021-10-26 04:31:01'),
(2095, 2, 'admin/doctors/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:31:06', '2021-10-26 04:31:06'),
(2096, 2, 'admin/auth/users', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:31:24', '2021-10-26 04:31:24'),
(2097, 2, 'admin/auth/users/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:31:37', '2021-10-26 04:31:37'),
(2098, 2, 'admin/auth/users', 'POST', '::1', '{\"username\":\"inspector2\",\"name\":\"Biirah Halima\",\"password\":\"4321\",\"password_confirmation\":\"4321\",\"roles\":[\"4\",null],\"permissions\":[null],\"_token\":\"Uv3v5wBkKuN2bfnz9sRUV6uPCYLuO2Lpki7Z7DTy\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/auth\\/users\"}', '2021-10-26 04:32:27', '2021-10-26 04:32:27'),
(2099, 2, 'admin/auth/users', 'GET', '::1', '[]', '2021-10-26 04:32:28', '2021-10-26 04:32:28'),
(2100, 2, 'admin/districts', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:32:40', '2021-10-26 04:32:40'),
(2101, 2, 'admin/districts/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:32:43', '2021-10-26 04:32:43'),
(2102, 2, 'admin/districts', 'POST', '::1', '{\"name\":\"Kampala\",\"administrator_id\":\"6\",\"population\":\"500000\",\"details\":\"Kampala is Uganda\'s national and commercial capital bordering Lake Victoria, Africa\'s largest lake. Hills covered with red-tile villas and trees surround an urban centre of contemporary skyscrapers. In this downtown area, the Uganda Museum explores the country\'s tribal heritage through an extensive collection of artefacts. On nearby Mengo Hill is Lubiri Palace, the former seat of the Buganda Kingdom. \\u2015 Google\",\"latitude\":\"0.3137585499384947\",\"longitude\":\"32.525040964081654\",\"_token\":\"Uv3v5wBkKuN2bfnz9sRUV6uPCYLuO2Lpki7Z7DTy\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/districts\"}', '2021-10-26 04:34:31', '2021-10-26 04:34:31'),
(2103, 2, 'admin/districts', 'GET', '::1', '[]', '2021-10-26 04:34:31', '2021-10-26 04:34:31'),
(2104, 2, 'admin/districts/2', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:34:54', '2021-10-26 04:34:54'),
(2105, 2, 'admin/districts', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:34:59', '2021-10-26 04:34:59'),
(2106, 2, 'admin', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:35:10', '2021-10-26 04:35:10'),
(2107, 2, 'admin/districts', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:35:18', '2021-10-26 04:35:18'),
(2108, 2, 'admin/districts/2/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:35:24', '2021-10-26 04:35:24'),
(2109, 2, 'admin/districts/2', 'PUT', '::1', '{\"name\":\"Kampala\",\"administrator_id\":\"6\",\"population\":\"5000000\",\"details\":\"Kampala is Uganda\'s national and commercial capital bordering Lake Victoria, Africa\'s largest lake. Hills covered with red-tile villas and trees surround an urban centre of contemporary skyscrapers. In this downtown area, the Uganda Museum explores the country\'s tribal heritage through an extensive collection of artefacts. On nearby Mengo Hill is Lubiri Palace, the former seat of the Buganda Kingdom. \\u2015 Google\",\"latitude\":\"0.3137585499384947\",\"longitude\":\"32.525040964081654\",\"_token\":\"Uv3v5wBkKuN2bfnz9sRUV6uPCYLuO2Lpki7Z7DTy\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/districts\"}', '2021-10-26 04:35:30', '2021-10-26 04:35:30'),
(2110, 2, 'admin/districts', 'GET', '::1', '[]', '2021-10-26 04:35:31', '2021-10-26 04:35:31'),
(2111, 2, 'admin', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:35:33', '2021-10-26 04:35:33'),
(2112, 2, 'admin/districts', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:35:40', '2021-10-26 04:35:40'),
(2113, 2, 'admin/labs', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:35:58', '2021-10-26 04:35:58'),
(2114, 2, 'admin/labs/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:36:07', '2021-10-26 04:36:07'),
(2115, 2, 'admin/labs', 'POST', '::1', '{\"name\":\"Makerere University\",\"district_id\":\"2\",\"administrator_id\":\"6\",\"address\":\"Kibuli, Kampala, Uganda\",\"details\":\"details....\",\"latitude\":\"0.3109262793055018\",\"longitude\":\"32.52653193701781\",\"_token\":\"Uv3v5wBkKuN2bfnz9sRUV6uPCYLuO2Lpki7Z7DTy\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/labs\"}', '2021-10-26 04:37:52', '2021-10-26 04:37:52'),
(2116, 2, 'admin/labs', 'GET', '::1', '[]', '2021-10-26 04:37:53', '2021-10-26 04:37:53'),
(2117, 2, 'admin/labs/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:37:59', '2021-10-26 04:37:59'),
(2118, 2, 'admin/labs', 'POST', '::1', '{\"name\":\"Case clinic\",\"district_id\":\"2\",\"administrator_id\":\"6\",\"address\":\"Magdalene Lane Opposite Ndere Cultural Centre, Ntinda - Kisaasi Rd, Kampala\",\"details\":\"case details...\",\"latitude\":\"0.3107280497082879\",\"longitude\":\"32.541718385471064\",\"_token\":\"Uv3v5wBkKuN2bfnz9sRUV6uPCYLuO2Lpki7Z7DTy\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/labs\"}', '2021-10-26 04:38:53', '2021-10-26 04:38:53'),
(2119, 2, 'admin/labs', 'GET', '::1', '[]', '2021-10-26 04:38:53', '2021-10-26 04:38:53'),
(2120, 2, 'admin/stock-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:40:45', '2021-10-26 04:40:45'),
(2121, 2, 'admin/stock-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:40:57', '2021-10-26 04:40:57'),
(2122, 2, 'admin/stock-records', 'POST', '::1', '{\"administrator_id\":\"2\",\"lab_id\":\"2\",\"name\":\"johnson and johnson vaccine\",\"type\":\"First dose\",\"amount\":\"1000000\",\"_token\":\"Uv3v5wBkKuN2bfnz9sRUV6uPCYLuO2Lpki7Z7DTy\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/stock-records\"}', '2021-10-26 04:41:47', '2021-10-26 04:41:47'),
(2123, 2, 'admin/stock-records', 'GET', '::1', '[]', '2021-10-26 04:41:49', '2021-10-26 04:41:49'),
(2124, 2, 'admin/stock-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:41:59', '2021-10-26 04:41:59'),
(2125, 2, 'admin/stock-records', 'POST', '::1', '{\"administrator_id\":\"2\",\"lab_id\":\"3\",\"name\":\"johnson and johnson vaccine\",\"type\":\"First dose\",\"amount\":\"12000\",\"_token\":\"Uv3v5wBkKuN2bfnz9sRUV6uPCYLuO2Lpki7Z7DTy\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/stock-records\"}', '2021-10-26 04:42:20', '2021-10-26 04:42:20'),
(2126, 2, 'admin/stock-records', 'GET', '::1', '[]', '2021-10-26 04:42:21', '2021-10-26 04:42:21'),
(2127, 2, 'admin/doctors', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:43:00', '2021-10-26 04:43:00'),
(2128, 2, 'admin/doctors/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:43:06', '2021-10-26 04:43:06'),
(2129, 2, 'admin/auth/users', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:43:58', '2021-10-26 04:43:58'),
(2130, 2, 'admin/auth/users/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:44:05', '2021-10-26 04:44:05'),
(2131, 2, 'admin/auth/users', 'POST', '::1', '{\"username\":\"doctor2\",\"name\":\"Betty Namagembe\",\"password\":\"4321\",\"password_confirmation\":\"4321\",\"roles\":[\"5\",null],\"permissions\":[null],\"_token\":\"Uv3v5wBkKuN2bfnz9sRUV6uPCYLuO2Lpki7Z7DTy\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/auth\\/users\"}', '2021-10-26 04:45:07', '2021-10-26 04:45:07'),
(2132, 2, 'admin/auth/users', 'GET', '::1', '[]', '2021-10-26 04:45:08', '2021-10-26 04:45:08'),
(2133, 2, 'admin/doctors', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:45:31', '2021-10-26 04:45:31'),
(2134, 2, 'admin/doctors/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:45:35', '2021-10-26 04:45:35'),
(2135, 2, 'admin/doctors', 'POST', '::1', '{\"administrator_id\":\"3\",\"lab_id\":\"2\",\"age\":\"30\",\"gender\":\"Female\",\"phone_number\":\"0123456789\",\"address\":\"Kibuli, Kampala, Uganda\",\"nin_number\":\"10299100096\",\"_token\":\"Uv3v5wBkKuN2bfnz9sRUV6uPCYLuO2Lpki7Z7DTy\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/doctors\"}', '2021-10-26 04:46:34', '2021-10-26 04:46:34'),
(2136, 2, 'admin/doctors', 'GET', '::1', '[]', '2021-10-26 04:46:34', '2021-10-26 04:46:34'),
(2137, 2, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:46:58', '2021-10-26 04:46:58'),
(2138, 2, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:47:00', '2021-10-26 04:47:00'),
(2139, 2, 'admin/vaccination-records', 'GET', '::1', '[]', '2021-10-26 04:47:01', '2021-10-26 04:47:01'),
(2140, 2, 'admin/auth/logout', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:47:25', '2021-10-26 04:47:25'),
(2141, 7, 'admin', 'GET', '::1', '[]', '2021-10-26 04:47:40', '2021-10-26 04:47:40'),
(2142, 7, 'admin', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:47:56', '2021-10-26 04:47:56'),
(2143, 7, 'admin/auth/setting', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:48:01', '2021-10-26 04:48:01'),
(2144, 7, 'admin', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:48:14', '2021-10-26 04:48:14'),
(2145, 7, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:48:27', '2021-10-26 04:48:27'),
(2146, 7, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:48:32', '2021-10-26 04:48:32'),
(2147, 7, 'admin/vaccination-records', 'GET', '::1', '[]', '2021-10-26 04:48:33', '2021-10-26 04:48:33'),
(2148, 2, 'admin', 'GET', '::1', '[]', '2021-10-26 04:49:14', '2021-10-26 04:49:14'),
(2149, 2, 'admin/doctors', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:49:18', '2021-10-26 04:49:18'),
(2150, 2, 'admin/doctors/2/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:49:24', '2021-10-26 04:49:24'),
(2151, 2, 'admin/auth/users', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:49:40', '2021-10-26 04:49:40'),
(2152, 2, 'admin/auth/users/3/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:49:56', '2021-10-26 04:49:56'),
(2153, 2, 'admin/auth/users/3', 'PUT', '::1', '{\"username\":\"basic-user\",\"name\":\"Betty Namagembe\",\"password\":\"$2y$10$cBUNI05M8a7AUXSEgLr4cudiDW3nFZ2McpfuAQOf4HIfjUF.6Viha\",\"password_confirmation\":\"$2y$10$cBUNI05M8a7AUXSEgLr4cudiDW3nFZ2McpfuAQOf4HIfjUF.6Viha\",\"roles\":[\"5\",null],\"permissions\":[null],\"_token\":\"n4dgNU2kdYyJB9XicTz834SaslWIFgQzRa2wG9aS\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/auth\\/users\"}', '2021-10-26 04:50:03', '2021-10-26 04:50:03'),
(2154, 2, 'admin/auth/users', 'GET', '::1', '[]', '2021-10-26 04:50:04', '2021-10-26 04:50:04'),
(2155, 7, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:50:13', '2021-10-26 04:50:13'),
(2156, 7, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:50:15', '2021-10-26 04:50:15'),
(2157, 7, 'admin/vaccination-records', 'GET', '::1', '[]', '2021-10-26 04:50:16', '2021-10-26 04:50:16'),
(2158, 2, 'admin/auth/users', 'GET', '::1', '[]', '2021-10-26 04:52:05', '2021-10-26 04:52:05'),
(2159, 7, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:52:10', '2021-10-26 04:52:10'),
(2160, 7, 'admin/vaccination-records', 'GET', '::1', '[]', '2021-10-26 04:52:10', '2021-10-26 04:52:10'),
(2161, 2, 'admin/auth/users/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:52:32', '2021-10-26 04:52:32'),
(2162, 7, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:52:40', '2021-10-26 04:52:40'),
(2163, 2, 'admin/auth/users/create', 'GET', '::1', '[]', '2021-10-26 04:53:13', '2021-10-26 04:53:13'),
(2164, 7, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-26 04:53:19', '2021-10-26 04:53:19'),
(2165, 7, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-26 04:54:30', '2021-10-26 04:54:30'),
(2166, 7, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-26 04:56:32', '2021-10-26 04:56:32'),
(2167, 7, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-26 04:58:38', '2021-10-26 04:58:38'),
(2168, 7, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-26 04:58:41', '2021-10-26 04:58:41'),
(2169, 7, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-26 04:58:43', '2021-10-26 04:58:43'),
(2170, 7, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-26 04:58:45', '2021-10-26 04:58:45'),
(2171, 7, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-26 04:58:47', '2021-10-26 04:58:47'),
(2172, 7, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-26 04:58:48', '2021-10-26 04:58:48'),
(2173, 7, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-26 04:58:50', '2021-10-26 04:58:50'),
(2174, 7, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-26 04:58:52', '2021-10-26 04:58:52'),
(2175, 7, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-26 04:58:54', '2021-10-26 04:58:54'),
(2176, 7, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-26 04:58:56', '2021-10-26 04:58:56'),
(2177, 7, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-26 04:58:59', '2021-10-26 04:58:59'),
(2178, 7, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-26 04:59:01', '2021-10-26 04:59:01'),
(2179, 7, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-26 04:59:03', '2021-10-26 04:59:03'),
(2180, 7, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-26 04:59:07', '2021-10-26 04:59:07'),
(2181, 2, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:59:23', '2021-10-26 04:59:23'),
(2182, 2, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 04:59:25', '2021-10-26 04:59:25'),
(2183, 2, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-26 05:01:27', '2021-10-26 05:01:27'),
(2184, 7, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-26 05:01:34', '2021-10-26 05:01:34'),
(2185, 2, 'admin/auth/users', 'GET', '::1', '[]', '2021-10-26 05:01:54', '2021-10-26 05:01:54'),
(2186, 2, 'admin/doctors', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 05:01:59', '2021-10-26 05:01:59'),
(2187, 2, 'admin/doctors/2/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 05:02:04', '2021-10-26 05:02:04'),
(2188, 2, 'admin/doctors/2/edit', 'GET', '::1', '[]', '2021-10-26 05:03:37', '2021-10-26 05:03:37'),
(2189, 2, 'admin/doctors/2/edit', 'GET', '::1', '[]', '2021-10-26 05:04:31', '2021-10-26 05:04:31'),
(2190, 2, 'admin/doctors/2/edit', 'GET', '::1', '[]', '2021-10-26 05:04:44', '2021-10-26 05:04:44'),
(2191, 2, 'admin/doctors/2/edit', 'GET', '::1', '[]', '2021-10-26 05:05:35', '2021-10-26 05:05:35'),
(2192, 7, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-26 05:06:19', '2021-10-26 05:06:19'),
(2193, 7, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-26 05:06:24', '2021-10-26 05:06:24'),
(2194, 7, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-26 05:06:27', '2021-10-26 05:06:27'),
(2195, 7, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-26 05:06:31', '2021-10-26 05:06:31'),
(2196, 7, 'admin/vaccination-records-2', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 05:06:35', '2021-10-26 05:06:35'),
(2197, 7, 'admin/vaccination-records/create', 'GET', '::1', '[]', '2021-10-26 05:06:35', '2021-10-26 05:06:35'),
(2198, 7, 'admin/vaccination-records-2', 'GET', '::1', '[]', '2021-10-26 05:06:40', '2021-10-26 05:06:40'),
(2199, 2, 'admin/doctors/2', 'PUT', '::1', '{\"administrator_id\":\"7\",\"lab_id\":\"2\",\"age\":\"30\",\"gender\":\"Female\",\"phone_number\":\"0123456789\",\"address\":\"Kibuli, Kampala, Uganda\",\"nin_number\":\"10299100096\",\"_token\":\"n4dgNU2kdYyJB9XicTz834SaslWIFgQzRa2wG9aS\",\"_method\":\"PUT\"}', '2021-10-26 05:06:53', '2021-10-26 05:06:53'),
(2200, 2, 'admin/doctors', 'GET', '::1', '[]', '2021-10-26 05:06:54', '2021-10-26 05:06:54'),
(2201, 2, 'admin/doctors/2/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 05:07:02', '2021-10-26 05:07:02'),
(2202, 7, 'admin/vaccination-records-2', 'GET', '::1', '[]', '2021-10-26 05:07:11', '2021-10-26 05:07:11'),
(2203, 7, 'admin/vaccination-records-2/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 05:07:15', '2021-10-26 05:07:15'),
(2204, 7, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 05:07:24', '2021-10-26 05:07:24'),
(2205, 7, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 05:07:31', '2021-10-26 05:07:31'),
(2206, 7, 'admin/vaccination-records', 'POST', '::1', '{\"administrator_id\":\"7\",\"lab_id\":\"2\",\"full_name\":\"Jane Doe\",\"age\":\"26\",\"gender\":\"Female\",\"address\":\"Kibuli, Kampala, Uganda\",\"phone_number\":\"+256706638494\",\"nin_number\":\"111222\",\"type\":\"First dose\",\"next_vaccination\":\"2021-11-24 08:07:31\",\"_token\":\"N6EX7LGroWZQ2PWpNL7S1fO6X2OkXTcR8Re6XkRH\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/vaccination-records\"}', '2021-10-26 05:09:03', '2021-10-26 05:09:03'),
(2207, 7, 'admin/vaccination-records', 'GET', '::1', '[]', '2021-10-26 05:09:04', '2021-10-26 05:09:04'),
(2208, 7, 'admin/vaccination-records-2', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 05:09:59', '2021-10-26 05:09:59'),
(2209, 7, 'admin/vaccination-records-2/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 05:10:06', '2021-10-26 05:10:06'),
(2210, 7, 'admin/vaccination-records-2', 'POST', '::1', '{\"administrator_id\":\"7\",\"lab_id\":\"2\",\"full_name\":\"3\",\"type\":\"Second dose\",\"next_vaccination\":\"2021-10-26 08:10:06\",\"_token\":\"N6EX7LGroWZQ2PWpNL7S1fO6X2OkXTcR8Re6XkRH\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/vaccination-records-2\"}', '2021-10-26 05:10:40', '2021-10-26 05:10:40'),
(2211, 7, 'admin/vaccination-records-2', 'GET', '::1', '[]', '2021-10-26 05:10:40', '2021-10-26 05:10:40'),
(2212, 7, 'admin/vaccination-records-2/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 05:10:44', '2021-10-26 05:10:44'),
(2213, 7, 'admin/vaccination-records-2', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 05:10:52', '2021-10-26 05:10:52'),
(2214, 7, 'admin/vaccination-records-2', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 05:10:57', '2021-10-26 05:10:57'),
(2215, 7, 'admin/vaccination-records-2', 'GET', '::1', '[]', '2021-10-26 05:10:58', '2021-10-26 05:10:58'),
(2216, 7, 'admin/auth/logout', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 05:11:17', '2021-10-26 05:11:17'),
(2217, 2, 'admin', 'GET', '::1', '[]', '2021-10-26 05:11:31', '2021-10-26 05:11:31'),
(2218, 2, 'admin/auth/logout', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 05:16:34', '2021-10-26 05:16:34'),
(2219, 2, 'admin', 'GET', '::1', '[]', '2021-10-26 05:16:51', '2021-10-26 05:16:51'),
(2220, 2, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-26 05:31:02', '2021-10-26 05:31:02'),
(2221, 2, 'admin/auth/menu/7', 'DELETE', '::1', '{\"_method\":\"delete\",\"_token\":\"WUMVsTNv4VfpWYpySSsLQxMjP4qNyOghoEkoRSHp\"}', '2021-10-26 05:31:08', '2021-10-26 05:31:08'),
(2222, 2, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 05:31:09', '2021-10-26 05:31:09'),
(2223, 2, 'admin/auth/menu/6', 'DELETE', '::1', '{\"_method\":\"delete\",\"_token\":\"WUMVsTNv4VfpWYpySSsLQxMjP4qNyOghoEkoRSHp\"}', '2021-10-26 05:31:14', '2021-10-26 05:31:14'),
(2224, 2, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 05:31:15', '2021-10-26 05:31:15'),
(2225, 2, 'admin/auth/menu/5', 'DELETE', '::1', '{\"_method\":\"delete\",\"_token\":\"WUMVsTNv4VfpWYpySSsLQxMjP4qNyOghoEkoRSHp\"}', '2021-10-26 05:31:18', '2021-10-26 05:31:18'),
(2226, 2, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 05:31:19', '2021-10-26 05:31:19'),
(2227, 2, 'admin/auth/menu/4', 'DELETE', '::1', '{\"_method\":\"delete\",\"_token\":\"WUMVsTNv4VfpWYpySSsLQxMjP4qNyOghoEkoRSHp\"}', '2021-10-26 05:31:24', '2021-10-26 05:31:24'),
(2228, 2, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 05:31:25', '2021-10-26 05:31:25'),
(2229, 2, 'admin/auth/menu', 'POST', '::1', '{\"_token\":\"WUMVsTNv4VfpWYpySSsLQxMjP4qNyOghoEkoRSHp\",\"_order\":\"[{\\\"id\\\":16},{\\\"id\\\":17},{\\\"id\\\":18},{\\\"id\\\":20},{\\\"id\\\":19},{\\\"id\\\":21},{\\\"id\\\":1},{\\\"id\\\":2,\\\"children\\\":[{\\\"id\\\":3}]},{\\\"id\\\":10},{\\\"id\\\":8}]\"}', '2021-10-26 05:31:30', '2021-10-26 05:31:30'),
(2230, 2, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 05:31:30', '2021-10-26 05:31:30'),
(2231, 2, 'admin/auth/menu', 'GET', '::1', '[]', '2021-10-26 05:31:34', '2021-10-26 05:31:34'),
(2232, 2, 'admin/auth/users', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 06:10:43', '2021-10-26 06:10:43'),
(2233, 2, 'admin/auth/logout', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-26 06:11:30', '2021-10-26 06:11:30'),
(2234, 2, 'admin', 'GET', '::1', '[]', '2021-10-29 17:19:53', '2021-10-29 17:19:53'),
(2235, 2, 'admin/districts', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:21:25', '2021-10-29 17:21:25'),
(2236, 2, 'admin/districts/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:21:37', '2021-10-29 17:21:37'),
(2237, 2, 'admin/districts', 'POST', '::1', '{\"name\":\"Gulu\",\"administrator_id\":\"5\",\"population\":\"1500000\",\"details\":\"details go here....\",\"latitude\":\"2.738940827520345\",\"longitude\":\"32.335535428737266\",\"_token\":\"Mi5B92tAM3dO9ZATyRW8omtmSl0XfLwJ60HEZnpY\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/districts\"}', '2021-10-29 17:24:34', '2021-10-29 17:24:34'),
(2238, 2, 'admin/districts', 'GET', '::1', '[]', '2021-10-29 17:24:35', '2021-10-29 17:24:35'),
(2239, 2, 'admin/labs', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:25:03', '2021-10-29 17:25:03'),
(2240, 2, 'admin/labs', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:25:20', '2021-10-29 17:25:20'),
(2241, 2, 'admin/labs/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:25:28', '2021-10-29 17:25:28'),
(2242, 2, 'admin/labs', 'POST', '::1', '{\"name\":\"Bwera Hospital\",\"district_id\":\"1\",\"administrator_id\":\"2\",\"address\":\"Bwera, Kasese, Uganda\",\"details\":\"lab details...\",\"latitude\":\"0.3263535976706369\",\"longitude\":\"32.505522798078026\",\"_token\":\"Mi5B92tAM3dO9ZATyRW8omtmSl0XfLwJ60HEZnpY\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/labs\"}', '2021-10-29 17:26:52', '2021-10-29 17:26:52'),
(2243, 2, 'admin/labs', 'GET', '::1', '[]', '2021-10-29 17:26:53', '2021-10-29 17:26:53'),
(2244, 2, 'admin/doctors', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:28:19', '2021-10-29 17:28:19'),
(2245, 2, 'admin/doctors/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:28:31', '2021-10-29 17:28:31'),
(2246, 2, 'admin/doctors', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:28:39', '2021-10-29 17:28:39'),
(2247, 2, 'admin/auth/users', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:28:42', '2021-10-29 17:28:42'),
(2248, 2, 'admin/auth/users/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:28:47', '2021-10-29 17:28:47'),
(2249, 2, 'admin/auth/users', 'POST', '::1', '{\"username\":\"doctor3\",\"name\":\"Joan Doe\",\"password\":\"4321\",\"password_confirmation\":\"4321\",\"roles\":[\"5\",null],\"permissions\":[null],\"_token\":\"Mi5B92tAM3dO9ZATyRW8omtmSl0XfLwJ60HEZnpY\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/auth\\/users\"}', '2021-10-29 17:30:06', '2021-10-29 17:30:06'),
(2250, 2, 'admin/auth/users', 'GET', '::1', '[]', '2021-10-29 17:30:07', '2021-10-29 17:30:07'),
(2251, 2, 'admin/doctors', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:30:22', '2021-10-29 17:30:22'),
(2252, 2, 'admin/doctors/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:30:25', '2021-10-29 17:30:25'),
(2253, 2, 'admin/doctors', 'POST', '::1', '{\"administrator_id\":\"8\",\"lab_id\":\"4\",\"age\":\"30\",\"gender\":\"Female\",\"phone_number\":\"01234567894\",\"address\":\"Kibuli, Kampala, Uganda\",\"nin_number\":\"1029910009355\",\"_token\":\"Mi5B92tAM3dO9ZATyRW8omtmSl0XfLwJ60HEZnpY\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/doctors\"}', '2021-10-29 17:31:18', '2021-10-29 17:31:18'),
(2254, 2, 'admin/doctors', 'GET', '::1', '[]', '2021-10-29 17:31:19', '2021-10-29 17:31:19'),
(2255, 2, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:31:41', '2021-10-29 17:31:41'),
(2256, 2, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:31:52', '2021-10-29 17:31:52'),
(2257, 2, 'admin/vaccination-records', 'GET', '::1', '[]', '2021-10-29 17:31:54', '2021-10-29 17:31:54'),
(2258, 2, 'admin/vaccination-records-2', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:32:13', '2021-10-29 17:32:13'),
(2259, 2, 'admin/vaccination-records-2/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:32:35', '2021-10-29 17:32:35'),
(2260, 2, 'admin/vaccination-records-2', 'GET', '::1', '[]', '2021-10-29 17:32:38', '2021-10-29 17:32:38'),
(2261, 2, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:33:20', '2021-10-29 17:33:20'),
(2262, 2, 'admin/auth/logout', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:33:34', '2021-10-29 17:33:34'),
(2263, 8, 'admin', 'GET', '::1', '[]', '2021-10-29 17:33:48', '2021-10-29 17:33:48'),
(2264, 8, 'admin/auth/setting', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:34:18', '2021-10-29 17:34:18'),
(2265, 8, 'admin', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:34:19', '2021-10-29 17:34:19'),
(2266, 8, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:34:25', '2021-10-29 17:34:25'),
(2267, 8, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:34:32', '2021-10-29 17:34:32'),
(2268, 8, 'admin/vaccination-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:34:40', '2021-10-29 17:34:40'),
(2269, 8, 'admin/vaccination-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:35:05', '2021-10-29 17:35:05'),
(2270, 8, 'admin/vaccination-records', 'POST', '::1', '{\"administrator_id\":\"8\",\"lab_id\":\"4\",\"full_name\":\"Landus Peter\",\"age\":\"26\",\"gender\":\"Male\",\"address\":\"Kasangati, Kampala, Uganda\",\"phone_number\":\"+256706638494\",\"nin_number\":\"111222333\",\"type\":\"First dose\",\"next_vaccination\":\"2021-10-29 20:35:05\",\"_token\":\"Q6emTTegaigZffVPE9WEDy5AiNpGOZYMI07myReH\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/vaccination-records\"}', '2021-10-29 17:36:20', '2021-10-29 17:36:20'),
(2271, 8, 'admin/vaccination-records', 'GET', '::1', '[]', '2021-10-29 17:36:21', '2021-10-29 17:36:21'),
(2272, 8, 'admin', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:37:04', '2021-10-29 17:37:04'),
(2273, 8, 'admin/vaccination-records-2', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:37:15', '2021-10-29 17:37:15'),
(2274, 8, 'admin/vaccination-records-2/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:37:22', '2021-10-29 17:37:22'),
(2275, 8, 'admin/vaccination-records-2', 'POST', '::1', '{\"administrator_id\":\"8\",\"lab_id\":\"4\",\"full_name\":\"5\",\"type\":\"Second dose\",\"next_vaccination\":\"2021-10-29 20:37:22\",\"_token\":\"Q6emTTegaigZffVPE9WEDy5AiNpGOZYMI07myReH\",\"_previous_\":\"http:\\/\\/localhost:8888\\/corona\\/admin\\/vaccination-records-2\"}', '2021-10-29 17:37:47', '2021-10-29 17:37:47'),
(2276, 8, 'admin/vaccination-records-2', 'GET', '::1', '[]', '2021-10-29 17:37:48', '2021-10-29 17:37:48'),
(2277, 8, 'admin/vaccination-records-2/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:37:56', '2021-10-29 17:37:56'),
(2278, 8, 'admin/vaccination-records-2', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:38:07', '2021-10-29 17:38:07'),
(2279, 8, 'admin/vaccination-records-2', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:38:10', '2021-10-29 17:38:10'),
(2280, 8, 'admin', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:38:11', '2021-10-29 17:38:11'),
(2281, 8, 'admin/auth/logout', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:38:31', '2021-10-29 17:38:31'),
(2282, 2, 'admin', 'GET', '::1', '[]', '2021-10-29 17:39:05', '2021-10-29 17:39:05'),
(2283, 2, 'admin/stock-records', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:39:12', '2021-10-29 17:39:12'),
(2284, 2, 'admin/stock-records/create', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:39:17', '2021-10-29 17:39:17'),
(2285, 2, 'admin/districts', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:39:42', '2021-10-29 17:39:42'),
(2286, 2, 'admin', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:39:44', '2021-10-29 17:39:44'),
(2287, 2, 'admin/auth/users', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2021-10-29 17:39:50', '2021-10-29 17:39:50');

-- --------------------------------------------------------

--
-- Table structure for table `admin_permissions`
--

CREATE TABLE `admin_permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `http_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `http_path` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_permissions`
--

INSERT INTO `admin_permissions` (`id`, `name`, `slug`, `http_method`, `http_path`, `created_at`, `updated_at`) VALUES
(1, 'All permission', '*', '', '*', NULL, NULL),
(2, 'Dashboard', 'dashboard', 'GET', '/', NULL, NULL),
(3, 'Login', 'auth.login', '', '/auth/login\r\n/auth/logout', NULL, NULL),
(4, 'User setting', 'auth.setting', 'GET,PUT', '/auth/setting', NULL, NULL),
(5, 'Auth management', 'auth.management', '', '/auth/roles\r\n/auth/permissions\r\n/auth/menu\r\n/auth/logs', NULL, NULL),
(6, 'Media manager', 'ext.media-manager', '', '/media*', '2021-10-20 12:28:29', '2021-10-20 12:28:29');

-- --------------------------------------------------------

--
-- Table structure for table `admin_roles`
--

CREATE TABLE `admin_roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_roles`
--

INSERT INTO `admin_roles` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Super Admin', 'super-admin', '2021-10-20 08:50:00', '2021-10-20 12:56:12'),
(2, 'Admin', 'admin', '2021-10-20 12:53:35', '2021-10-20 12:53:35'),
(3, 'Basic User', 'basic-user', '2021-10-20 13:02:58', '2021-10-20 13:02:58'),
(4, 'Inspector', 'inspector', '2021-10-21 13:02:29', '2021-10-21 13:02:29'),
(5, 'doctor', 'doctor', '2021-10-23 15:51:39', '2021-10-23 15:51:39');

-- --------------------------------------------------------

--
-- Table structure for table `admin_role_menu`
--

CREATE TABLE `admin_role_menu` (
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_role_menu`
--

INSERT INTO `admin_role_menu` (`role_id`, `menu_id`, `created_at`, `updated_at`) VALUES
(1, 2, NULL, NULL),
(1, 8, NULL, NULL),
(2, 8, NULL, NULL),
(1, 16, NULL, NULL),
(2, 16, NULL, NULL),
(1, 17, NULL, NULL),
(2, 17, NULL, NULL),
(1, 18, NULL, NULL),
(2, 18, NULL, NULL),
(1, 20, NULL, NULL),
(2, 20, NULL, NULL),
(2, 2, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admin_role_permissions`
--

CREATE TABLE `admin_role_permissions` (
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_role_permissions`
--

INSERT INTO `admin_role_permissions` (`role_id`, `permission_id`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, NULL),
(2, 1, NULL, NULL),
(2, 2, NULL, NULL),
(2, 3, NULL, NULL),
(2, 4, NULL, NULL),
(2, 5, NULL, NULL),
(2, 6, NULL, NULL),
(3, 3, NULL, NULL),
(3, 2, NULL, NULL),
(3, 1, NULL, NULL),
(4, 1, NULL, NULL),
(4, 2, NULL, NULL),
(4, 3, NULL, NULL),
(4, 4, NULL, NULL),
(4, 5, NULL, NULL),
(4, 6, NULL, NULL),
(5, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admin_role_users`
--

CREATE TABLE `admin_role_users` (
  `role_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_role_users`
--

INSERT INTO `admin_role_users` (`role_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, NULL),
(2, 2, NULL, NULL),
(2, 1, NULL, NULL),
(4, 4, NULL, NULL),
(5, 5, NULL, NULL),
(4, 6, NULL, NULL),
(5, 7, NULL, NULL),
(5, 3, NULL, NULL),
(5, 8, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `password`, `name`, `avatar`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'super-admin', '$2y$10$H6GEBthh.w0f7hTAiIPGReseT8KJRsPqCE2AtGvvRczN2OGmawONa', 'Administrator', NULL, '7Y5is6tBD7QIBlKt1PLrUjjLo3oKhYkyj7ESkAPQfdBDZ0MoXyxwoQADuDro', '2021-10-20 08:50:00', '2021-10-22 02:20:54'),
(2, 'admin', '$2y$10$JnOG.x2fFxqp3g/sfxaQou7rr7QRrhhQxHF.JRgXyv6eAlecjtOiO', 'Muhindo Mubaraka', 'muhind mubaraka.jpeg', 'xhx3PPkxBOGsznQ1WGm3rmkJs7JYAksMMXelMs2T8iLhhGXcFZ5jXuj19BPV', '2021-10-20 13:09:43', '2021-10-20 13:20:46'),
(3, 'basic-user', '$2y$10$cBUNI05M8a7AUXSEgLr4cudiDW3nFZ2McpfuAQOf4HIfjUF.6Viha', 'Betty Namagembe', 'muhind mubaraka (1).jpeg', 'koXVaDR7qyqqYakOlR3qifKiwY2UHhMHYSRolDeGKqve4PXXZZTb7ctt26jP', '2021-10-20 13:21:48', '2021-10-21 11:10:00'),
(4, 'inspector', '$2y$10$gSUz/lav3jtzFkvuuDi8uOZgKBG5BaLdR3GjNoqnO47q5gewjazPC', 'Dr. Drake Mirembe', 'dr-drake-patrick-mirembe.jpeg', 't5QNXnNc0YMzmpbqlRCK7OMpyqkmFdW67CEaS0sXtciI1fcZl4Avg8j787tn', '2021-10-21 13:07:58', '2021-10-21 13:07:58'),
(5, 'doctor', '$2y$10$glaQ7Udf7hymmJcN3nXk3O3bZpxvzmnzgaAjPtYfgIjdOL/8Ic.qe', 'Kule John', 'public/anjane/052583fe679604f70ea343ab9bbd001a (1).jpeg', 'emHbEOnLMmUX60JY5bzh5DLs9K71Eebc8ml4LJImAkmEkDWarWRDc4rpcoNL', '2021-10-23 15:56:04', '2021-10-23 16:31:54'),
(6, 'inspector2', '$2y$10$pfmnSNxKV5Puvjy0TBwIouhNMJBlK4cloxOxQk.GHbhIZcDDjGunG', 'Biirah Halima', 'ac39e063610cb3a4aa8e7c87129176ba.jpeg', NULL, '2021-10-26 04:32:28', '2021-10-26 04:32:28'),
(7, 'doctor2', '$2y$10$xJgxuURJX3KcoTC/92i4Du2R.YVkQBlyTK4EucBhhZrp23/56CInO', 'Betty Namagembe', 'da7897ec1cd71439e874cde37a0d69de.jpeg', 'QyiTIZKlBp0u0rdXxOvPx5o30VDzZcstl40WS1VMb61VLFIdUboYr8v0nddQ', '2021-10-26 04:45:08', '2021-10-26 04:45:08'),
(8, 'doctor3', '$2y$10$oImx.8lxE/bg2qTppqqG/.BbWFgcU8RdPMkO5i9lBRw9fBpKUhCza', 'Joan Doe', '052583fe679604f70ea343ab9bbd001a (1).jpeg', 'bmxZnb8T90DWAvZErKYagOXSmlmJUZqJYtJg5xVAY9aS4s69SEuVHP1Zorju', '2021-10-29 17:30:06', '2021-10-29 17:30:06');

-- --------------------------------------------------------

--
-- Table structure for table `admin_user_permissions`
--

CREATE TABLE `admin_user_permissions` (
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `attributes`
--

CREATE TABLE `attributes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` text COLLATE utf8mb4_unicode_ci,
  `is_required` tinyint(4) DEFAULT NULL,
  `units` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `parent` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE `chats` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci,
  `sender` bigint(20) UNSIGNED NOT NULL,
  `receiver` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `thread` text COLLATE utf8mb4_unicode_ci,
  `received` tinyint(4) DEFAULT NULL,
  `seen` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `country_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `longitude` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `listed` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `longitude` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `listed` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE `districts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `administrator_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` text COLLATE utf8mb4_unicode_ci,
  `longitude` text COLLATE utf8mb4_unicode_ci,
  `latitude` text COLLATE utf8mb4_unicode_ci,
  `image` text COLLATE utf8mb4_unicode_ci,
  `details` text COLLATE utf8mb4_unicode_ci,
  `population` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`id`, `created_at`, `updated_at`, `administrator_id`, `name`, `location`, `longitude`, `latitude`, `image`, `details`, `population`) VALUES
(1, '2021-10-23 04:48:34', '2021-10-23 15:39:12', 2, 'Kasese', NULL, '29.7230851', '0.1183366', '052583fe679604f70ea343ab9bbd001a (1).jpeg', 'kampala', 2000000),
(2, '2021-10-26 04:34:31', '2021-10-26 04:35:30', 6, 'Kampala', NULL, '32.525040964081654', '0.3137585499384947', '032dada09428956873a8d4c6b1ab149f.png', 'Kampala is Uganda\'s national and commercial capital bordering Lake Victoria, Africa\'s largest lake. Hills covered with red-tile villas and trees surround an urban centre of contemporary skyscrapers. In this downtown area, the Uganda Museum explores the country\'s tribal heritage through an extensive collection of artefacts. On nearby Mengo Hill is Lubiri Palace, the former seat of the Buganda Kingdom. ― Google', 5000000),
(3, '2021-10-29 17:24:34', '2021-10-29 17:24:34', 5, 'Gulu', NULL, '32.335535428737266', '2.738940827520345', 'Cororna (1).png', 'details go here....', 1500000);

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `administrator_id` bigint(20) UNSIGNED NOT NULL,
  `lab_id` bigint(20) UNSIGNED NOT NULL,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` text COLLATE utf8mb4_unicode_ci,
  `address` text COLLATE utf8mb4_unicode_ci,
  `phone_number` text COLLATE utf8mb4_unicode_ci,
  `photo` text COLLATE utf8mb4_unicode_ci,
  `nin_number` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `created_at`, `updated_at`, `administrator_id`, `lab_id`, `full_name`, `age`, `gender`, `address`, `phone_number`, `photo`, `nin_number`) VALUES
(1, '2021-10-23 10:04:35', '2021-10-23 16:36:14', 1, 1, NULL, 29, 'Male', 'Kibuli, Kampala, Uganda', '+8801632257609', 'files/7b56fb797a1029136015ffcc0f2049ae.png', '10299100093'),
(2, '2021-10-26 04:46:34', '2021-10-26 05:06:53', 7, 2, NULL, 30, 'Female', 'Kibuli, Kampala, Uganda', '0123456789', 'files/052583fe679604f70ea343ab9bbd001a (1).jpeg', '10299100096'),
(3, '2021-10-29 17:31:18', '2021-10-29 17:31:18', 8, 4, NULL, 30, 'Female', 'Kibuli, Kampala, Uganda', '01234567894', 'files/4d93c2db-015e-457b-abd2-ff920eb0f93a.jpeg', '1029910009355');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `form_sr4s`
--

CREATE TABLE `form_sr4s` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `administrator_id` bigint(20) UNSIGNED NOT NULL,
  `name_of_applicant` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_initials` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `premises_location` text COLLATE utf8mb4_unicode_ci,
  `years_of_expirience` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expirience_in` text COLLATE utf8mb4_unicode_ci,
  `dealers_in` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `processing_of` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marketing_of` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `have_adequate_land` tinyint(4) DEFAULT NULL,
  `land_size` int(11) DEFAULT NULL,
  `eqipment` text COLLATE utf8mb4_unicode_ci,
  `have_adequate_equipment` tinyint(4) DEFAULT NULL,
  `have_contractual_agreement` tinyint(4) DEFAULT NULL,
  `have_adequate_field_officers` tinyint(4) DEFAULT NULL,
  `have_conversant_seed_matters` tinyint(4) DEFAULT NULL,
  `souce_of_seed` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `have_adequate_land_for_production` tinyint(4) DEFAULT NULL,
  `have_internal_quality_program` tinyint(4) DEFAULT NULL,
  `receipt` text COLLATE utf8mb4_unicode_ci,
  `accept_declaration` tinyint(4) DEFAULT NULL,
  `valid_from` timestamp NULL DEFAULT NULL,
  `valid_until` timestamp NULL DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_comment` text COLLATE utf8mb4_unicode_ci,
  `inspector` int(11) DEFAULT NULL,
  `dealers_in_other` varchar(225) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `processing_of_other` varchar(225) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marketing_of_other` varchar(225) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `souce_of_seed_other` varchar(225) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `form_sr4s`
--

INSERT INTO `form_sr4s` (`id`, `created_at`, `updated_at`, `administrator_id`, `name_of_applicant`, `address`, `company_initials`, `premises_location`, `years_of_expirience`, `expirience_in`, `dealers_in`, `processing_of`, `marketing_of`, `have_adequate_land`, `land_size`, `eqipment`, `have_adequate_equipment`, `have_contractual_agreement`, `have_adequate_field_officers`, `have_conversant_seed_matters`, `souce_of_seed`, `have_adequate_land_for_production`, `have_internal_quality_program`, `receipt`, `accept_declaration`, `valid_from`, `valid_until`, `status`, `status_comment`, `inspector`, `dealers_in_other`, `processing_of_other`, `marketing_of_other`, `souce_of_seed_other`) VALUES
(4, '2021-10-22 02:41:08', '2021-10-22 02:53:07', 3, 'Betty Namagembe', 'Bwera, Kasese, Uganda', 'Ugnews24', 'Bwera, Kasese, Uganda', '1', '5', 'Other', 'Horticulture crops', 'Agriculture crops', 1, 50, 'Tractor', 1, 1, 1, 1, 'Other', 1, 0, 'files/muhindo-mubaraka.png', 1, '2021-09-30 21:00:00', '2022-10-31 21:00:00', '5', 'submitted wrong receipt', 4, 'Floriculture', NULL, NULL, 'Bwambale Muhidin');

-- --------------------------------------------------------

--
-- Table structure for table `form_sr6s`
--

CREATE TABLE `form_sr6s` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `administrator_id` bigint(20) UNSIGNED NOT NULL,
  `name_of_applicant` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_initials` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `premises_location` text COLLATE utf8mb4_unicode_ci,
  `years_of_expirience` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dealers_in` text COLLATE utf8mb4_unicode_ci,
  `previous_grower_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cropping_histroy` text COLLATE utf8mb4_unicode_ci,
  `have_adequate_isolation` tinyint(4) DEFAULT NULL,
  `have_adequate_labor` tinyint(4) DEFAULT NULL,
  `aware_of_minimum_standards` tinyint(4) DEFAULT NULL,
  `signature_of_applicant` text COLLATE utf8mb4_unicode_ci,
  `grower_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registration_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valid_from` timestamp NULL DEFAULT NULL,
  `valid_until` timestamp NULL DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inspector` int(11) DEFAULT NULL,
  `status_comment` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `form_sr6s`
--

INSERT INTO `form_sr6s` (`id`, `created_at`, `updated_at`, `administrator_id`, `name_of_applicant`, `address`, `company_initials`, `premises_location`, `years_of_expirience`, `dealers_in`, `previous_grower_number`, `cropping_histroy`, `have_adequate_isolation`, `have_adequate_labor`, `aware_of_minimum_standards`, `signature_of_applicant`, `grower_number`, `registration_number`, `valid_from`, `valid_until`, `status`, `inspector`, `status_comment`) VALUES
(4, '2021-10-22 08:55:34', '2021-10-22 12:04:08', 3, '[{\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\"},{\"crop\":\"origin\",\"variety\":\"habskb\",\"ha\":\"origin\",\"origin\":\"origin\"}]', 'Bwera, Kasese, Uganda', 'Ugnews24', '[{\"crop\":\"11\",\"variety\":\"22\",\"ha\":\"33\",\"origin\":\"44\"},{\"crop\":\"Roina\",\"variety\":\"SOMALIA\",\"ha\":\"jUMAA\",\"origin\":\"kASESE\"}]', '21', '[]', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, '2021-10-22 08:54:53', '2021-10-22 08:54:53', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED DEFAULT NULL,
  `size` double(8,2) DEFAULT NULL,
  `width` double(8,2) DEFAULT NULL,
  `height` double(8,2) DEFAULT NULL,
  `src` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thumbnail` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `labs`
--

CREATE TABLE `labs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `administrator_id` bigint(20) UNSIGNED NOT NULL,
  `district_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `longitude` text COLLATE utf8mb4_unicode_ci,
  `latitude` text COLLATE utf8mb4_unicode_ci,
  `address` text COLLATE utf8mb4_unicode_ci,
  `image` text COLLATE utf8mb4_unicode_ci,
  `details` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `labs`
--

INSERT INTO `labs` (`id`, `created_at`, `updated_at`, `administrator_id`, `district_id`, `name`, `longitude`, `latitude`, `address`, `image`, `details`) VALUES
(1, '2021-10-23 05:46:20', '2021-10-23 05:46:20', 2, 1, 'Nansana lab', '32.52343644354454', '0.3679815408762197', 'lab full disrtict', '49142-1634636084-2.png', 'text'),
(2, '2021-10-26 04:37:53', '2021-10-26 04:37:53', 6, 2, 'Makerere University', '32.52653193701781', '0.3109262793055018', 'Kibuli, Kampala, Uganda', '5bc0d0cc43c8494f19d0b24af6d5d6ce.png', 'details....'),
(3, '2021-10-26 04:38:53', '2021-10-26 04:38:53', 6, 2, 'Case clinic', '32.541718385471064', '0.3107280497082879', 'Magdalene Lane Opposite Ndere Cultural Centre, Ntinda - Kisaasi Rd, Kampala', '51953ca31cab81d913cd4b33cb70b32b.png', 'case details...'),
(4, '2021-10-29 17:26:53', '2021-10-29 17:26:53', 2, 1, 'Bwera Hospital', '32.505522798078026', '0.3263535976706369', 'Bwera, Kasese, Uganda', '7b25be774b5ef80398cbc715368c45a9.png', 'lab details...');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2016_01_04_173148_create_admin_tables', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2021_09_05_180305_create_categories_table', 1),
(7, '2021_09_05_180411_create_attributes_table', 1),
(8, '2021_09_05_211930_create_products_table', 1),
(9, '2021_09_15_220048_create_profiles_table', 1),
(10, '2021_09_18_100139_create_images_table', 1),
(11, '2021_09_23_091308_create_countries_table', 1),
(12, '2021_09_23_092138_create_cities_table', 1),
(13, '2021_10_16_021622_create_chats_table', 1),
(15, '2021_10_20_172350_create_sr4s_table', 2),
(17, '2021_10_20_173006_create_form_sr4s_table', 3),
(18, '2021_10_22_061845_create_form_sr6s_table', 4),
(19, '2021_10_23_065106_create_form_districts_table', 5),
(20, '2021_10_23_070104_create_districts_table', 6),
(21, '2021_10_23_082639_create_labs_table', 7),
(22, '2021_10_23_090225_create_stock_records_table', 8),
(23, '2021_10_23_093541_create_vaccination_records_table', 9),
(24, '2021_10_23_123000_create_doctors_table', 10);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `country_id` bigint(20) UNSIGNED NOT NULL,
  `city_id` bigint(20) UNSIGNED NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `quantity` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `images` text COLLATE utf8mb4_unicode_ci,
  `thumbnail` text COLLATE utf8mb4_unicode_ci,
  `attributes` text COLLATE utf8mb4_unicode_ci,
  `sub_category_id` int(11) DEFAULT NULL,
  `fixed_price` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `about` text COLLATE utf8mb4_unicode_ci,
  `services` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `longitude` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `division` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opening_hours` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cover_photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linkedin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_seen` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stock_records`
--

CREATE TABLE `stock_records` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `administrator_id` bigint(20) UNSIGNED NOT NULL,
  `lab_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stock_records`
--

INSERT INTO `stock_records` (`id`, `created_at`, `updated_at`, `administrator_id`, `lab_id`, `name`, `type`, `amount`) VALUES
(1, '2021-10-23 06:26:25', '2021-10-23 06:26:25', 1, 1, 'Johnsonjons', 'First dose', 10),
(2, '2021-10-26 04:41:48', '2021-10-26 04:41:48', 2, 2, 'johnson and johnson vaccine', 'First dose', 1000000),
(3, '2021-10-26 04:42:20', '2021-10-26 04:42:20', 2, 3, 'johnson and johnson vaccine', 'First dose', 12000);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vaccination_records`
--

CREATE TABLE `vaccination_records` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `administrator_id` bigint(20) UNSIGNED NOT NULL,
  `lab_id` bigint(20) UNSIGNED NOT NULL,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` text COLLATE utf8mb4_unicode_ci,
  `address` text COLLATE utf8mb4_unicode_ci,
  `phone_number` text COLLATE utf8mb4_unicode_ci,
  `photo` text COLLATE utf8mb4_unicode_ci,
  `nin_number` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `next_vaccination` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `vaccination_records`
--

INSERT INTO `vaccination_records` (`id`, `created_at`, `updated_at`, `administrator_id`, `lab_id`, `full_name`, `age`, `gender`, `address`, `phone_number`, `photo`, `nin_number`, `type`, `next_vaccination`) VALUES
(1, '2021-10-23 10:22:01', '2021-10-23 10:22:01', 1, 1, 'Muhindo Mubaraka', 30, 'Male', 'Kibuli, Kampala, Uganda', '+256706638494', 'muhindo-mubaraka.png', '10299100093', 'First dose', '2021-10-25 10:20:45'),
(2, '2021-10-23 10:58:28', '2021-10-23 10:58:28', 1, 1, '1', NULL, NULL, NULL, NULL, NULL, NULL, 'Second dose', '2021-10-23 10:58:21'),
(3, '2021-10-26 05:09:03', '2021-10-26 05:09:03', 7, 2, 'Jane Doe', 26, 'Female', 'Kibuli, Kampala, Uganda', '+256706638494', 'bd3eff18da1adac2f7e69ef8d9f8d3f7.jpeg', '111222', 'First dose', '2021-11-24 05:07:31'),
(4, '2021-10-26 05:10:40', '2021-10-26 05:10:40', 7, 2, '3', NULL, NULL, NULL, NULL, NULL, NULL, 'Second dose', '2021-10-26 05:10:06'),
(5, '2021-10-29 17:36:20', '2021-10-29 17:36:20', 8, 4, 'Landus Peter', 26, 'Male', 'Kasangati, Kampala, Uganda', '+256706638494', '4d93c2db-015e-457b-abd2-ff920eb0f93a.jpeg', '111222333', 'First dose', '2021-10-29 17:35:05'),
(6, '2021-10-29 17:37:47', '2021-10-29 17:37:47', 8, 4, '5', NULL, NULL, NULL, NULL, NULL, NULL, 'Second dose', '2021-10-29 17:37:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_menu`
--
ALTER TABLE `admin_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_operation_log`
--
ALTER TABLE `admin_operation_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_operation_log_user_id_index` (`user_id`);

--
-- Indexes for table `admin_permissions`
--
ALTER TABLE `admin_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admin_permissions_name_unique` (`name`),
  ADD UNIQUE KEY `admin_permissions_slug_unique` (`slug`);

--
-- Indexes for table `admin_roles`
--
ALTER TABLE `admin_roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admin_roles_name_unique` (`name`),
  ADD UNIQUE KEY `admin_roles_slug_unique` (`slug`);

--
-- Indexes for table `admin_role_menu`
--
ALTER TABLE `admin_role_menu`
  ADD KEY `admin_role_menu_role_id_menu_id_index` (`role_id`,`menu_id`);

--
-- Indexes for table `admin_role_permissions`
--
ALTER TABLE `admin_role_permissions`
  ADD KEY `admin_role_permissions_role_id_permission_id_index` (`role_id`,`permission_id`);

--
-- Indexes for table `admin_role_users`
--
ALTER TABLE `admin_role_users`
  ADD KEY `admin_role_users_role_id_user_id_index` (`role_id`,`user_id`);

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admin_users_username_unique` (`username`);

--
-- Indexes for table `admin_user_permissions`
--
ALTER TABLE `admin_user_permissions`
  ADD KEY `admin_user_permissions_user_id_permission_id_index` (`user_id`,`permission_id`);

--
-- Indexes for table `attributes`
--
ALTER TABLE `attributes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `districts`
--
ALTER TABLE `districts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `form_sr4s`
--
ALTER TABLE `form_sr4s`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `form_sr6s`
--
ALTER TABLE `form_sr6s`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `labs`
--
ALTER TABLE `labs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock_records`
--
ALTER TABLE `stock_records`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `vaccination_records`
--
ALTER TABLE `vaccination_records`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_menu`
--
ALTER TABLE `admin_menu`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `admin_operation_log`
--
ALTER TABLE `admin_operation_log`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2288;

--
-- AUTO_INCREMENT for table `admin_permissions`
--
ALTER TABLE `admin_permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `admin_roles`
--
ALTER TABLE `admin_roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `attributes`
--
ALTER TABLE `attributes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chats`
--
ALTER TABLE `chats`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `districts`
--
ALTER TABLE `districts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `form_sr4s`
--
ALTER TABLE `form_sr4s`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `form_sr6s`
--
ALTER TABLE `form_sr6s`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `labs`
--
ALTER TABLE `labs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stock_records`
--
ALTER TABLE `stock_records`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vaccination_records`
--
ALTER TABLE `vaccination_records`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php

use App\Models\Lab;
use Encore\Admin\Auth\Database\Administrator;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateVaccinationRecordsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('vaccination_records', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
            $table->foreignIdFor(Administrator::class);
            $table->foreignIdFor(Lab::class);
            $table->string('full_name')->nullable();
            $table->integer('age')->nullable();
            $table->text('gender')->nullable();
            $table->text('address')->nullable();
            $table->text('phone_number')->nullable();
            $table->text('photo')->nullable();
            $table->text('nin_number')->nullable();
            $table->string('type')->nullable();
            $table->timestamp('next_vaccination')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('vaccination_records');
    }
}
